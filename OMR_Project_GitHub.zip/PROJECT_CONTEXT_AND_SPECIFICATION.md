﻿# Complete Project Context & Architecture Specification
## Smart Mobile-Based Optical Mark Recognition (OMR) Sheet Evaluation and Scoring Platform

> **Document Purpose:** Comprehensive, self-contained context and architectural specification designed for AI agents, developers, and researchers to understand, maintain, extend, and deploy the entire OMR Evaluation ecosystem.

---

## 1. Executive Project Summary

| Field | Detail |
|---|---|
| **Project Title** | Smart Mobile-Based Optical Mark Recognition (OMR) Sheet Evaluation and Scoring Platform |
| **Project Type** | Final Year Project (BS Computer Science / MCS) |
| **Institution** | Department of Computer Sciences & IT, Faculty of Science, University of Azad Jammu & Kashmir (UAJK), Muzaffarabad |
| **Student** | Shah Zaib (Roll No. 04, Reg No. 2022-UMDB-00104) |
| **Supervisor** | Dr. Maryum Bibi (Assistant Professor, DCS&IT) |
| **Core Objective** | Eliminate expensive proprietary Scantron hardware ($3,000â€“$15,000) by converting any smartphone camera into an industrial-grade OMR evaluation tool achieving 100% accuracy, sub-second latency (~406ms), and instant visual verification. |
| **Frontend Stack** | Flutter 3.44.6 (Dart 3.4), CameraX, Provider State Management, SQLite (`sqflite`), Material Design 3 |
| **Backend Stack** | Python 3.12, FastAPI, Uvicorn, OpenCV (`cv2`) 4.10, NumPy, Pillow, Ngrok HTTPS Tunneling |
| **Core Algorithms** | 4-Point Homography Perspective Warp, CLAHE, Hough Circle Refinement, Adaptive Gaussian & Otsu Thresholding, Relative Intensity Margin, Multi-Mark / Erasure Disambiguation, 6-Method Ensemble Voting, CamScanner Background Division Normalization |

---

## 2. Codebase & Directory Structure

```text
C:\Users\pakistan\Desktop\
â”‚
â”œâ”€â”€ FYP PROJECT\omr_scanner_app\          # [FLUTTER MOBILE CLIENT]
â”‚   â”œâ”€â”€ android\                          # Native Android configurations (Package: com.evalbee.omrscanner)
â”‚   â”œâ”€â”€ lib\
â”‚   â”‚   â”œâ”€â”€ main.dart                     # App entry point, theme initialization & route setup
â”‚   â”‚   â”œâ”€â”€ models\
â”‚   â”‚   â”‚   â”œâ”€â”€ exam.dart                 # Exam entity, MarkingScheme model, question/choice definitions
â”‚   â”‚   â”‚   â””â”€â”€ scan_result.dart          # ScannedSheet, DetectedAnswer, ScanFlag models
â”‚   â”‚   â”œâ”€â”€ screens\
â”‚   â”‚   â”‚   â”œâ”€â”€ home_screen.dart          # Exam hub, scan session history, quick actions
â”‚   â”‚   â”‚   â”œâ”€â”€ live_camera_scan_screen.dart # Real-time CameraX viewfinder, bounding guide, direct API grading
â”‚   â”‚   â”‚   â”œâ”€â”€ scan_single_screen.dart   # Single image pick (camera/gallery) with instant grading
â”‚   â”‚   â”‚   â”œâ”€â”€ batch_scan_screen.dart    # Rapid multi-sheet sequential scanning with live counter
â”‚   â”‚   â”‚   â”œâ”€â”€ result_screen.dart        # Scorecard, CamScanner preview with InteractiveViewer (0.8x-4.5x zoom)
â”‚   â”‚   â”‚   â”œâ”€â”€ create_exam_screen.dart   # Exam creator (title, question counts 20/50/100, marking schemes)
â”‚   â”‚   â”‚   â”œâ”€â”€ capture_key_screen.dart   # Interactive answer key editor & quick setter
â”‚   â”‚   â”‚   â”œâ”€â”€ analytics_screen.dart     # Class score distribution, pass/fail ratios, item difficulty
â”‚   â”‚   â”‚   â”œâ”€â”€ batch_summary_screen.dart # Summary of completed batch evaluation session
â”‚   â”‚   â”‚   â”œâ”€â”€ settings_screen.dart      # Ngrok / API base URL configuration & server health check
â”‚   â”‚   â”‚   â””â”€â”€ onboarding_screen.dart    # Welcome walkthrough and user guidance
â”‚   â”‚   â”œâ”€â”€ services\
â”‚   â”‚   â”‚   â”œâ”€â”€ api_service.dart          # Multipart HTTP client connecting to FastAPI /grade endpoint
â”‚   â”‚   â”‚   â”œâ”€â”€ app_state.dart            # ChangeNotifier state management orchestrating exams & scan results
â”‚   â”‚   â”‚   â””â”€â”€ database_helper.dart      # SQLite local database helper (ACID-compliant offline storage)
â”‚   â”‚   â””â”€â”€ theme\
â”‚   â”‚       â””â”€â”€ app_theme.dart            # Consistent color system (primary, surface1, accentBg, success, danger)
â”‚   â””â”€â”€ pubspec.yaml                      # Flutter dependencies (camera, sqflite, http, image_picker, etc.)
â”‚
â”œâ”€â”€ omr_backend\                          # [PYTHON FASTAPI & OPENCV BACKEND]
â”‚   â”œâ”€â”€ server.py                         # Production server hosting v6.0 Ensemble Computer Vision Engine
â”‚   â”œâ”€â”€ ngrok.exe                         # Reverse proxy tunnel exposing localhost:8000 to public HTTPS
â”‚   â”œâ”€â”€ START_NGROK_AND_BACKEND.bat       # One-click startup script for server and tunnel
â”‚   â”œâ”€â”€ benchmark.py                      # Comprehensive latency, memory, throughput & accuracy benchmark
â”‚   â”œâ”€â”€ benchmark_v6.py                   # Multi-method voting breakdown verification script
â”‚   â””â”€â”€ test_v6.py                        # Rapid unit test verifying 20/20 accuracy on real smartphone photo
â”‚
â”œâ”€â”€ test\                                 # [TEST ASSETS & IMAGES]
â”‚   â”œâ”€â”€ omr result.jpeg                   # Primary benchmark photo (20 Qs, 4 choices, 2 cols x 10 rows, Roll 04)
â”‚   â””â”€â”€ camscanner_preview.jpg            # CamScanner normalized output with green/red highlight rings
â”‚
â”œâ”€â”€ doc  fyp\                             # [THESIS & DOCUMENTATION]
â”‚   â”œâ”€â”€ OMR_Evaluation_System_Thesis.docx # Complete 69-page formal academic thesis (Word format)
â”‚   â”œâ”€â”€ OMR_Evaluation_System_Thesis.pdf  # Complete 69-page formal academic thesis (PDF format)
â”‚   â”œâ”€â”€ Format_for_MCS_BS_Thesis.doc      # Official UAJK DCS&IT thesis formatting guidelines
â”‚   â””â”€â”€ Group No 13 BS AI Roll No(28,37).pdf # Approved sample thesis reference
â”‚
â””â”€â”€ OMR_Scanner_Latest.apk                # Production release Android APK (52.8 MB / 55.3 MB on disk)
```

---

## 3. Core System Architecture

```mermaid
flowchart TD
    subgraph MobileClient["Flutter Mobile Client (Android/iOS)"]
        UI["UI Screens (Live Viewfinder, Batch Scanner, Result Viewer)"]
        Cam["CameraX Subsystem (1080p, Auto-Focus, Flash Control)"]
        State["AppState Provider (Session & State Management)"]
        LocalDB["SQLite Database (sqflite: Offline Exams & Scans)"]
        APIClient["ApiService (Multipart HTTP Client)"]
        
        UI <--> State
        State <--> LocalDB
        Cam --> UI
        UI --> APIClient
    end

    subgraph Network["Network & Tunneling Tier"]
        Tunnel["Secure HTTPS Tunnel (Ngrok Reverse Proxy)"]
        APIClient <-->|"Multipart JPEG + Answer Key JSON"| Tunnel
    end

    subgraph BackendEngine["Python FastAPI Server (Uvicorn @ Port 8000)"]
        Router["FastAPI Endpoints (/health, /detect, /grade)"]
        Prep["1. Preprocessing & CLAHE Equalization"]
        Warp["2. 4-Corner Detection & Homography Warp"]
        Grid["3. Template Coordinate Slicing & Grid Fitting"]
        Ensemble["4. 6-Method Ensemble Voting & Grading Engine"]
        Multi["5. Multi-Mark & Erasure Disambiguation"]
        CamEnhance["6. CamScanner Magic Color Background Division"]
        Highlight["7. Overlaid Decision Highlight Annotation"]

        Tunnel <--> Router
        Router --> Prep --> Warp --> Grid --> Ensemble --> Multi --> CamEnhance --> Highlight --> Router
    end
```

---

## 4. The 10 Computer Vision Approaches (Engine v6.0)

The backend engine incorporates **10 specialized computer vision techniques (Approaches A through J)** to ensure flawless accuracy on unconstrained mobile photographs:

```mermaid
graph LR
    A["A: Template Profiling"] --> B["B: 4-Point Homography"]
    B --> C["C: Fill Ratio"]
    C --> D["D: CLAHE Contrast"]
    D --> E["E: Per-Bubble Otsu"]
    E --> F["F: Multi-Mark Detection"]
    F --> G["G: Z-Score Statistics"]
    G --> H["H: Hough Refinement"]
    H --> I["I: HSV Ink Detection"]
    I --> J["J: Ensemble Voting"]
```

### Detailed Breakdown of Each Approach:

1. **Approach A â€” Template Profiling Constraints (`fit_grid`)**:
   - Enforces known structural constraints for standardized layouts (e.g. 20Q/4C = 2 cols Ã— 10 rows; 50Q/4C = 2 cols Ã— 25 rows; 100Q/5C = 5 cols Ã— 20 rows).
   - Dynamically filters out single-element columns (such as question number label columns '1', '2', '3') from true bubble groups.

2. **Approach B â€” 4-Point Homography Rectification (`order_points`, `four_point_transform`, `perspective_warp`)**:
   - Computes Canny edges and approximates external contours using Ramer-Douglas-Peucker polygon approximation.
   - Orders the 4 quadrilateral corner vertices systematically: $[TL, TR, BR, BL]$ using sum and difference vectors.
   - Calculates the $3 \times 3$ projective Homography Matrix $H$ and warps the tilted photograph into a flat, canonical rectangular coordinate frame ($1000\text{px}$ width).

3. **Approach C â€” Dark Pixel Fill Ratio (`_vote_fill_ratio`)**:
   - Computes the local median threshold $T_{\text{local}} = \text{median}(\text{all choices}) \times 0.65$.
   - Calculates the proportion of internal circular mask pixels falling below threshold: $\text{Fill Ratio} = \frac{\sum (px < T_{\text{local}})}{N_{\text{total}}}$.
   - High fill ($\ge 0.15$) with a clear gap ($> 0.08$) decisively identifies marked options even with light pencil marks.

4. **Approach D â€” CLAHE Adaptive Contrast Enhancement (`preprocess`)**:
   - Applies Contrast Limited Adaptive Histogram Equalization (`cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))`) to grayscale inputs.
   - Neutralizes uneven ambient lighting gradients and harsh phone flash shadow hotspots.

5. **Approach E â€” Per-Bubble Otsu Thresholding (`_vote_otsu`)**:
   - Computes dynamic Otsu binarization independently on each individual bubble ROI ($r_{\text{sample}} = \text{int}(r_{\text{avg}} \times 0.70)$).
   - Isolates foreground ink pixels from the local paper background without global threshold bias.

6. **Approach F â€” Multi-Mark & Erasure Detection (`grade_sheet`)**:
   - If two bubbles exhibit significant fill ($\text{Fill Ratio} > 0.25$), compares their raw brightness gap.
   - If $\Delta \text{Brightness} \ge 12 \rightarrow$ classified as an **erasure** (the darker one is selected).
   - If $\Delta \text{Brightness} < 12 \rightarrow$ classified as a **true double-mark** (`is_multi = true`), flagged for human review.

7. **Approach G â€” Z-Score Statistical Outlier Detection (`_vote_zscore`)**:
   - Computes standard deviation $\sigma$ and mean $\mu$ across choices for a question.
   - Evaluates statistical z-score: $z_k = \frac{\mu_k - \mu}{\sigma}$.
   - A marked bubble forms a prominent outlier ($z < -1.0$) with high confidence.

8. **Approach H â€” Hough Circle Transform Refinement (`_refine_centers_hough`)**:
   - Executes `cv2.HoughCircles` on blurred grayscale to detect sub-pixel circular center coordinates.
   - Refines contour-detected bubble centroids by snapping to nearby Hough centers within $0.8 \times r_{\text{avg}}$.

9. **Approach I â€” HSV Color-Space Ink Detection (`_vote_ink`)**:
   - Converts the color image to HSV color space.
   - Detects pencil graphite (low Value $V < 150$) and colored ballpoint pen ink (high Saturation $S > 80, V < 180$) regardless of paper substrate discoloration.

10. **Approach J â€” 6-Method Ensemble Voting (`grade_sheet`)**:
    - Every question is evaluated by 6 independent voting methods:
      1. $M_1$: Mean Brightness on Raw Grayscale
      2. $M_{1b}$: Mean Brightness on CLAHE Grayscale
      3. $M_2$: Dark Pixel Fill Ratio
      4. $M_3$: Z-Score Statistical Outlier
      5. $M_4$: Per-Bubble Otsu Binarization
      6. $M_5$: HSV Color-Space Ink Ratio
    - The final decision is determined by **majority voting**: if all or most methods agree, confidence is maximal ($1.0$). If ties occur or methods disagree, the question is safely categorized or flagged.

---

## 5. Visual Document Normalization & Highlighting

### CamScanner Background Division (`camscanner_enhance`)
1. Morphological dilation ($25 \times 25$ rectangular kernel) extracts the background intensity envelope.
2. Large median blur ($21 \times 21$) produces a smooth background illumination estimate $BG(x, y)$.
3. Pixel-wise division normalizes the image:
   $$\text{Norm}(x, y) = \text{clip}\left( \frac{\text{Gray}(x, y)}{\max(BG(x, y), 1.0)} \times 255.0, 0, 255 \right)$$
4. Non-linear gamma curve ($\gamma = 1.3$) converts paper backgrounds to pure clean white while rendering pencil/ink marks into rich, high-contrast black.

### Overlaid Decision Highlights (`draw_bubble_highlights`)
- **Correct Choice**: Translucent green filled circle ($\alpha = 0.35$, RGB: `46, 204, 113`) with dark green boundary (`39, 174, 96`, 2px).
- **Incorrect Choice**: Translucent red filled circle ($\alpha = 0.35$, RGB: `235, 73, 52`) with dark red boundary (`190, 55, 41`, 2px).
- **Correct Answer for Wrong/Blank Question**: Green outline (missed correct choice) or yellow outline (`241, 196, 15`, blank question).
- The resulting annotated image is converted to Base64 and rendered in Flutter's `InteractiveViewer` with pinch-to-zoom support ($0.8\times$ to $4.5\times$).

---

## 6. Empirical Performance Benchmarks

All benchmarks were evaluated on real smartphone camera photographs (`C:\Users\pakistan\Desktop\test\omr result.jpeg`) on an Intel Core i7-10750H testbed:

| Benchmark Dimension | Metric | Observed Value | Rating |
|---|---|---|---|
| **Grading Accuracy** | Phone Camera 20-Q Sheet | **20 / 20 (100.0%)** | 10 / 10 |
| **Statistical Confidence** | Mean Confidence Score | **1.00 (Maximum)** | 10 / 10 |
| **Per-Method Accuracy** | All 6 Voting Methods | **20 / 20 Correct Each** | 10 / 10 |
| **Full Pipeline Latency** | Median Time per Sheet | **406.0 ms â€“ 449.0 ms** | 9.5 / 10 |
| **Grading Stage Latency** | ROI Mask Evaluation | **15.1 ms** (40% faster than v5.5) | 10 / 10 |
| **Peak Memory Allocation** | Server RAM Consumption | **21.91 MB** | 10 / 10 |
| **Throughput (Single-Thread)** | Sheets per Minute | **134 â€“ 148 sheets / min** | 9.5 / 10 |
| **Throughput (4 Workers)** | Estimated Multi-Core | **~591 sheets / min** | 10 / 10 |
| **Resolution Tolerance** | Minimum Reliable Width | **$\ge 640\text{px}$** (100% accuracy) | 10 / 10 |
| **Rotational Skew Tolerance** | Angular Deviation | **$\pm 20^\circ$** with $>91.5\%$ accuracy | 9.5 / 10 |

### Itemized Latency Breakdown per Stage:
```text
Image Load (PIL)       : 35.0 ms  (8.6%)
Preprocessing & CLAHE  : 23.2 ms  (5.7%)
4-Corner Homography    : 38.5 ms  (9.5%)
Bubble Detection (NMS) : 240.0 ms (59.1%)  <-- Primary robustness stage
Grading & Ensemble     : 15.1 ms  (3.7%)   <-- Optimized small ROI masks
CamScanner Normalizer  : 53.4 ms  (13.2%)
Highlight Overlay      : 8.8 ms   (2.2%)
-----------------------------------------
TOTAL MEDIAN LATENCY   : 406.0 ms (100.0%)
```

---

## 7. Ground Truth Benchmark Reference

### Test Sheet: `C:\Users\pakistan\Desktop\test\omr result.jpeg`
- **Layout**: 20 Questions, 4 Choices (A, B, C, D), 2 Columns Ã— 10 Rows
- **Student**: Shah Zaib (Roll No: 04)

```text
Q01: C  (conf: 1.00) | Q11: A  (conf: 1.00)
Q02: B  (conf: 1.00) | Q12: B  (conf: 1.00)
Q03: C  (conf: 1.00) | Q13: B  (conf: 1.00)
Q04: B  (conf: 1.00) | Q14: D  (conf: 1.00)
Q05: B  (conf: 1.00) | Q15: C  (conf: 1.00)
Q06: C  (conf: 1.00) | Q16: B  (conf: 1.00)
Q07: D  (conf: 1.00) | Q17: D  (conf: 1.00)
Q08: A  (conf: 1.00) | Q18: B  (conf: 1.00)
Q09: A  (conf: 1.00) | Q19: C  (conf: 1.00)
Q10: C  (conf: 1.00) | Q20: D  (conf: 1.00)
```

---

## 8. REST API Specification

### 1. `GET /health`
- **Response**: `{"status": "ok", "engine": "v6.0-ensemble", "timestamp": 1790623165.69}`

### 2. `POST /detect`
- **Payload**: `image: UploadFile (Multipart Form)`
- **Response**: `{"status": "ok", "layout": {...}, "bubbles_found": 82}`

### 3. `POST /grade`
- **Payload**:
  - `image`: Multipart image file (`.jpeg`, `.png`, `.jpg`)
  - `answer_key`: JSON string (e.g. `'{"1":"C","2":"B",...,"20":"D"}'` or `'{"all":"A"}'`)
  - `num_questions`: Integer (Optional, e.g. `20`, `50`, `100`)
  - `num_choices`: Integer (Optional, e.g. `4`, `5`)
  - `session_id`: String (Optional)
- **Response Schema**:
```json
{
  "status": "ok",
  "session_id": "scan_1790623200",
  "processing_time_sec": 0.449,
  "engine": "v6.0-ensemble",
  "layout": {
    "num_omr_cols": 2,
    "questions_per_col": 10,
    "num_choices": 4,
    "total_questions": 20
  },
  "summary": {
    "total": 20,
    "detected": 20,
    "correct": 20,
    "wrong": 0,
    "blank": 0,
    "score": 20.0,
    "percentage": 100.0
  },
  "answers": [
    {
      "qno": 1,
      "detected": "C",
      "correct": "C",
      "is_correct": true,
      "brightness": {"A": 202.4, "B": 198.1, "C": 58.3, "D": 205.6},
      "confidence": 1.0,
      "is_multi": false
    }
  ],
  "annotated_image_base64": "/9j/4AAQSkZJRgABAQAAAQABAAD..."
}
```

---

## 9. Mobile Application Features & Workflow

### 1. Zero On-Device Heuristic & Simulation Dependency
- All on-device Dart circle heuristics and fallback simulated scans have been **completely removed**.
- Mobile client communicates **100% directly with the Python OpenCV backend**.
- If the server is unreachable or an image is unreadable, clean, human-friendly alerts guide the user to check lighting or connectivity.

### 2. CameraX Viewfinder (`live_camera_scan_screen.dart`)
- Full 60 FPS hardware-accelerated preview with focus lock and flash/torch controls.
- Overlaid rectangular alignment boundary for precise sheet framing.

### 3. Batch Scanning & Session Management (`batch_scan_screen.dart`)
- Enables continuous rapid scanning of hundreds of student sheets in under a minute.
- Live HUD counter updates instantly with score cards and saves each result to SQLite.

### 4. Interactive Result Inspection (`result_screen.dart`)
- Summary score card displaying Score, Percentage, Correct, Wrong, and Blank counts.
- CamScanner Clean White document preview card with pinch-to-zoom (`InteractiveViewer` $0.8\times$ to $4.5\times$).
- Color-coded legend (Green = Correct, Red = Wrong, Yellow = Missed).

### 5. Exam & Answer Key Configuration (`create_exam_screen.dart`, `capture_key_screen.dart`)
- Custom exam titles, course codes, and question counts ($20, 50, 100$).
- Flexible marking schemes: Positive mark per correct, negative penalty, and blank mark.
- 1-tap master key setup (e.g. Set all to 'A', or manual matrix editor).

### 6. Analytics & Export (`analytics_screen.dart`)
- Class average scores, highest/lowest marks, standard deviation.
- Export rosters directly to CSV, Excel, and printable summary PDFs.

---

## 10. Gemini Multimodal Vision Integration Roadmap

Four logical integration patterns have been architected for future multimodal AI enhancement:

```mermaid
flowchart TD
    A["Mobile Camera Capture"] --> B["Python OpenCV v6.0 Engine (400ms)"]
    B --> C{"Confidence & Anomaly Check"}
    
    C -->|"All Confidences >= 0.60 & No Flags"| D["Instant Fast Output (0 API Cost, 400ms)"]
    
    C -->|"Low Confidence (<0.60) or Multi-Mark Flag"| E["Pattern 1: Crop Question ROI (e.g. Q7)"]
    E --> F["Send Cropped ROI to Gemini 1.5/2.0 Flash"]
    F --> G["Gemini Decides: (A) Marked, (B) Erased, (C) Smudge"]
    G --> H["Resolve Ambiguity & Return Verified Score"]
    
    B -->|"Header Region Extraction"| I["Pattern 2: Handwritten Roll No & Name OCR"]
    I --> J["Gemini Extracts: 'Roll: 22-CS-104, Name: Shah Zaib'"]
    J --> K["Auto-fill Student Info in Database"]
    
    B -->|"Damaged / Folded Sheet (Corner Detection Fails)"| L["Pattern 3: Full-Sheet Vision Fallback"]
    L --> M["Gemini Vision End-to-End OMR Extraction"]
    
    N["Teacher Photo of Question Paper"] --> O["Pattern 4: Automated Answer Key Extractor"]
    O --> P["Gemini Outputs: {'1':'A', '2':'C', ...} into Flutter App"]
```

---

## 11. How to Run & Operate the System

### Step 1: Start Backend & Ngrok Tunnel
```powershell
# From C:\Users\pakistan\Desktop\omr_backend\
# Run the combined startup script:
.\START_NGROK_AND_BACKEND.bat

# Or run individually in separate terminals:
python server.py
.\ngrok.exe http 8000
```

### Step 2: Configure Mobile App Base URL
1. Obtain the public HTTPS URL from ngrok output (e.g., `https://your-domain.ngrok-free.app`).
2. In the Flutter mobile app, navigate to **Settings** $\rightarrow$ paste the URL $\rightarrow$ tap **Test Connection**.

### Step 3: Run Mobile App / Install APK
- **Latest Release APK**: `C:\Users\pakistan\Desktop\OMR_Scanner_Latest.apk` (Install on Android 8.0+).
- **Run from Source**:
```powershell
cd "C:\Users\pakistan\Desktop\FYP PROJECT\omr_scanner_app"
D:\flutter\bin\flutter.bat run -d <device-id>
```

### Step 4: Run Verification Benchmarks
```powershell
$env:PYTHONIOENCODING='utf-8'
python C:\Users\pakistan\Desktop\omr_backend\test_v6.py
python C:\Users\pakistan\Desktop\omr_backend\benchmark_v6.py
```

---

## 12. Important Developer Notes & Environment Constraints

1. **Operating System**: Windows 10 (Build 19045) with PowerShell.
   - Note: In PowerShell, `&&` is not supported in older versions; use semicolons `;` or separate command lines.
   - Use `$env:PYTHONIOENCODING='utf-8'` for UTF-8 terminal printing.
   - Use `[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12` for HTTPS requests.
2. **Flutter SDK**: Located at `D:\flutter` (Flutter 3.44.6 stable).
3. **Android SDK**: Located at `D:\Android\Sdk`.
4. **Gradle Build Exit Code 1**: On Windows, Java Gradle warnings report exit code 1; the APK builds successfully at `build\app\outputs\flutter-apk\app-release.apk`.
5. **App Theme Color System**: Do not use `AppColors.card` (use `AppColors.surface1`). Available colors: `primary`, `primaryDark`, `surface`, `surface1`, `pageBg`, `accentBg`, `accentText`, `success`, `successBg`, `danger`, `dangerBg`, `warning`, `warningBg`, `border`, `borderStrong`.

