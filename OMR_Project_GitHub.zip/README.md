# Smart Mobile-Based OMR Sheet Evaluation and Scoring Platform

An enterprise-grade, high-precision Optical Mark Recognition (OMR) system featuring a dual-architecture:
1. **Python FastAPI + OpenCV Backend**: Powered by an advanced v6.0 Ensemble Computer Vision Engine for rapid, robust, and 100% accurate bubble detection, perspective correction, and CamScanner-grade image enhancements.
2. **Flutter Mobile Application**: A cross-platform mobile client featuring real-time camera scanning, SQLite local storage, customizable answer keys, and instant grading breakdown.

---

## 🌟 Key Features

- **v6.0 Ensemble Computer Vision Engine**:
  - Multi-stage pipeline: CLAHE contrast enhancement, bilateral filtering, adaptive bubble contour detection, and strict aspect-ratio validation.
  - Multi-mark detection & blank bubble recognition.
  - Sub-second grading latency (~500ms per sheet).
- **CamScanner-Grade Enhancement**:
  - Automatically sharpens, cleans, and enhances scanned sheets with visual green (correct) and red (wrong) overlays.
- **Cross-Platform Mobile App (Flutter)**:
  - Clean Material Design 3 UI.
  - Offline-first architecture with SQLite caching.
  - Configurable backend server URL (local network, emulator, or secure public cloud/ngrok tunnel).
  - Excel and PDF export ready.
- **Docker Ready**:
  - Containerized deployment ready for Render, Railway, AWS, or local Docker containers.

---

## 📂 Project Structure

```
├── backend/
│   ├── server.py                  # Core FastAPI backend & v6.0 OpenCV engine
│   ├── test_v6.py                 # Automated verification test (100% accuracy check)
│   ├── benchmark_v6.py            # Latency and throughput benchmark script
│   ├── requirements.txt           # Python dependencies
│   ├── Dockerfile                 # Production Docker configuration
│   ├── run_server.bat             # One-click local server startup (Windows)
│   ├── start_with_ngrok.bat       # Startup script with ngrok reverse proxy
│   └── omr result.jpeg            # Sample reference sheet for tests
├── frontend/
│   ├── lib/
│   │   ├── main.dart              # Application entrypoint
│   │   ├── models/                # Exam and ScanResult data models
│   │   ├── screens/               # Scan, Results, Exams, and Settings screens
│   │   └── services/              # API and SQLite database services
│   ├── android/                   # Native Android configuration
│   ├── ios/                       # Native iOS configuration
│   ├── pubspec.yaml               # Flutter package dependencies
│   └── ...
├── test_sheets/                   # Sample test sheets and reference captures
│   ├── omr result.jpeg
│   └── camscanner_preview.jpg
└── README.md
```

---

## 🚀 Getting Started

### 1. Backend Setup (Python 3.10+)

Navigate to the `backend` directory:
```bash
cd backend
```

Create a virtual environment (recommended):
```bash
python -m venv venv
# On Windows:
.\venv\Scripts\activate
# On Linux/macOS:
source venv/bin/activate
```

Install dependencies:
```bash
pip install -r requirements.txt
```

Run the backend server:
```bash
# Using uvicorn:
uvicorn server:app --host 0.0.0.0 --port 8000 --reload

# Or on Windows, simply double-click:
run_server.bat
```

The API documentation is accessible at:
- Swagger UI: `http://localhost:8000/docs`
- Health check: `http://localhost:8000/`

---

### 2. Exposing Backend to Mobile App (ngrok / Local Network)

When testing on a physical mobile device, the app needs access to your backend server:

#### Option A: Using ngrok (Recommended for Remote / Physical Devices)
1. Install [ngrok](https://ngrok.com/) and authenticate your account.
2. Start the tunnel:
   ```bash
   ngrok http 8000
   ```
3. Copy the public HTTPS forwarding URL (e.g., `https://your-domain.ngrok-free.app`).
4. In the mobile app, go to **Settings** > **Server URL** and paste your URL.

#### Option B: Local Wi-Fi Network
1. Find your computer's local IP address (e.g., `http://192.168.1.50:8000`).
2. Make sure your phone is connected to the same Wi-Fi.
3. In the mobile app, set the Server URL to `http://192.168.1.50:8000`.

#### Option C: Android Emulator
- If running on the standard Android Emulator, the default host alias is:
  `http://10.0.2.2:8000`

---

### 3. Frontend Setup (Flutter)

Navigate to the `frontend` directory:
```bash
cd frontend
```

Fetch Flutter dependencies:
```bash
flutter pub get
```

Run the application:
```bash
flutter run
```

---

### 4. Running Accuracy Tests & Benchmarks

Verify 100% accuracy of the OpenCV engine on sample sheets:
```bash
cd backend
python test_v6.py
```

Run latency and method-level performance benchmarks:
```bash
python benchmark_v6.py
```

---

### 5. Docker Deployment

Build and run using Docker:
```bash
cd backend
docker build -t omr-backend .
docker run -p 8000:8000 omr-backend
```

---

## 📜 API Endpoints

- `GET /` - Health check & server status.
- `POST /grade` - Grades an OMR sheet against an answer key:
  - Form Fields:
    - `file`: Scanned sheet image (`image/jpeg` or `image/png`).
    - `answer_key`: JSON string mapping question number to correct option (e.g. `{"1":"A","2":"B",...}`).
  - Returns: Detailed scoring, detected bubbles, confidence metrics, and enhanced visualization overlay.

---

## 🔒 Security Note
No credentials, private tunneling tokens, or personal configuration files are committed to this repository. All tunnel endpoints and server URLs can be configured dynamically in the app's Settings screen.
