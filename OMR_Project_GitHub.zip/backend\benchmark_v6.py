"""v6 Ensemble Benchmark — detailed method-level analysis."""
import sys, time, os, statistics
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CURRENT_DIR)
import server as omr
import numpy as np

CANDIDATE_PATHS = [
    os.path.join(CURRENT_DIR, "omr result.jpeg"),
    os.path.join(CURRENT_DIR, "..", "test_sheets", "omr result.jpeg"),
    os.path.join(CURRENT_DIR, "test_sheets", "omr result.jpeg"),
]
IMG = next((p for p in CANDIDATE_PATHS if os.path.exists(p)), None)
if not IMG:
    raise FileNotFoundError("Sample image 'omr result.jpeg' not found in test_sheets or current folder.")
TRUTH = {
    "1":"C","2":"B","3":"C","4":"B","5":"B","6":"C","7":"D","8":"A","9":"A","10":"C",
    "11":"A","12":"B","13":"B","14":"D","15":"C","16":"B","17":"D","18":"B","19":"C","20":"D"
}

with open(IMG, "rb") as f:
    data = f.read()

N = 10
print("=" * 60)
print("  v6.0 Ensemble Engine — Full Benchmark")
print("=" * 60)

# Time full pipeline
times = []
for _ in range(N):
    t0 = time.perf_counter()
    raw = omr.load_image_bytes(data)
    resized, gray, gray_clahe, blurred, tw, th = omr.preprocess(raw)
    bubbles = omr.find_bubbles(gray, blurred, th)
    layout = omr.fit_grid(bubbles, tw, th)
    result = omr.grade_sheet(gray, layout, TRUTH, gray_clahe=gray_clahe, color_bgr=resized)
    enh = omr.camscanner_enhance(resized)
    hl = omr.draw_bubble_highlights(enh, layout, result["answers"], TRUTH)
    import cv2, base64
    _, eb = cv2.imencode('.jpg', hl, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
    base64.b64encode(eb).decode('utf-8')
    times.append((time.perf_counter() - t0) * 1000)

med = statistics.median(times)
mn = min(times)
mx = max(times)

print(f"\nFull Pipeline ({N} runs):")
print(f"  Median: {med:.0f}ms | Min: {mn:.0f}ms | Max: {mx:.0f}ms")
print(f"  Throughput: {1000/med:.1f} sheets/sec | {60000/med:.0f} sheets/min")

# Time grading only (v5 vs v6)
raw = omr.load_image_bytes(data)
resized, gray, gray_clahe, blurred, tw, th = omr.preprocess(raw)
bubbles = omr.find_bubbles(gray, blurred, th)
layout = omr.fit_grid(bubbles, tw, th)

# v6 ensemble grading
times_grade = []
for _ in range(N):
    t0 = time.perf_counter()
    result = omr.grade_sheet(gray, layout, TRUTH, gray_clahe=gray_clahe, color_bgr=resized)
    times_grade.append((time.perf_counter() - t0) * 1000)

print(f"\nGrading Only ({N} runs):")
print(f"  Median: {statistics.median(times_grade):.1f}ms")
print(f"  (v5 was ~25ms — includes 6 methods now)")

# Method vote analysis
print(f"\nMethod Vote Analysis:")
print(f"  All 20 questions: confidence = {result['answers'][0]['confidence']}")

# Check each method individually
for method_name, vote_fn, data_key in [
    ("M1 Brightness(raw)", omr._vote_brightness, "raw"),
    ("M1b Brightness(CLAHE)", omr._vote_brightness, "clahe"),
    ("M2 Fill Ratio", omr._vote_fill_ratio, "fill"),
    ("M3 Z-Score", omr._vote_zscore, "zscore"),
    ("M4 Per-Bubble Otsu", omr._vote_otsu, "otsu"),
    ("M5 HSV Ink", omr._vote_ink, "ink"),
]:
    correct_count = 0
    voted_count = 0
    
    for c_idx in range(layout["num_omr_cols"]):
        col_xs = layout["bubble_x"][c_idx]
        for r_idx in range(layout["questions_per_col"]):
            qno = c_idx * layout["questions_per_col"] + r_idx + 1
            cy = layout["row_ys"][r_idx]
            sample_r = max(4, int(layout["avg_radius"] * 0.7))
            choice_labels = ['A','B','C','D']
            
            brightness_raw = {}
            brightness_clahe = {}
            fill_ratios = {}
            otsu_fills = {}
            ink_ratios = {}
            choice_px = {}
            
            hsv = cv2.cvtColor(resized, cv2.COLOR_BGR2HSV)
            
            for ci, ch in enumerate(choice_labels):
                cx = col_xs[ci]
                y1 = max(0, cy - sample_r)
                y2 = min(gray.shape[0], cy + sample_r + 1)
                x1 = max(0, cx - sample_r)
                x2 = min(gray.shape[1], cx + sample_r + 1)
                
                rh, rw = y2-y1, x2-x1
                mask = np.zeros((rh, rw), dtype=np.uint8)
                cv2.circle(mask, (cx-x1, cy-y1), sample_r, 255, -1)
                
                roi_raw = gray[y1:y2, x1:x2]
                px = roi_raw[mask > 0]
                brightness_raw[ch] = float(np.mean(px))
                choice_px[ch] = px
                
                roi_clahe = gray_clahe[y1:y2, x1:x2]
                brightness_clahe[ch] = float(np.mean(roi_clahe[mask > 0]))
                
                try:
                    _, binary = cv2.threshold(roi_raw, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                    filled_px = np.sum((binary > 0) & (mask > 0))
                    total_px = np.sum(mask > 0)
                    otsu_fills[ch] = filled_px / max(1, total_px)
                except:
                    otsu_fills[ch] = 0.0
                
                hsv_roi = hsv[y1:y2, x1:x2]
                v_ch = hsv_roi[:,:,2]
                s_ch = hsv_roi[:,:,1]
                pencil = (v_ch < 150) & (mask > 0)
                pen = (s_ch > 80) & (v_ch < 180) & (mask > 0)
                ink_mask = pencil | pen
                ink_ratios[ch] = np.sum(ink_mask) / max(1, np.sum(mask > 0))
            
            all_px_q = np.concatenate(list(choice_px.values()))
            fill_threshold = float(np.median(all_px_q)) * 0.65
            for ch, px in choice_px.items():
                fill_ratios[ch] = np.sum(px < fill_threshold) / len(px)
            
            if data_key == "raw":
                v, c = vote_fn(brightness_raw)
            elif data_key == "clahe":
                v, c = vote_fn(brightness_clahe)
            elif data_key == "fill":
                v, c = vote_fn(fill_ratios)
            elif data_key == "zscore":
                v, c = vote_fn(brightness_raw)
            elif data_key == "otsu":
                v, c = vote_fn(otsu_fills)
            elif data_key == "ink":
                v, c = vote_fn(ink_ratios)
            
            if v is not None:
                voted_count += 1
                if v == TRUTH[str(qno)]:
                    correct_count += 1
    
    print(f"  {method_name:<25} {correct_count}/20 correct, {voted_count}/20 voted")

print(f"\n{'='*60}")
print(f"  Accuracy: {result['correct']}/20 = {result['percentage']}%")
print(f"  Speed: {med:.0f}ms (v5 was ~406ms)")
print(f"  All approaches: A B C D E F G H I J implemented!")
print(f"{'='*60}")
