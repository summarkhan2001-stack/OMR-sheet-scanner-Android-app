@echo off
title OMR Scanner Backend (FastAPI + OpenCV)
echo ====================================================
echo   Starting OMR Scanner Backend Server
echo ====================================================
echo.
python -m uvicorn server:app --host 0.0.0.0 --port 8000 --reload
pause
