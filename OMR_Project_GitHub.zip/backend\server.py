"""
OMR Scanner Backend — v6.0 ENSEMBLE Engine
============================================
All 10 approaches implemented for maximum accuracy:

  A. Template Profiling Constraints
  B. 4-Point Homography Rectification
  C. Dark Pixel Fill Ratio
  D. CLAHE Adaptive Contrast Enhancement
  E. Per-Bubble Otsu Thresholding
  F. Multi-Mark & Erasure Detection
  G. Z-Score Statistical Detection
  H. Hough Circle Transform Refinement
  I. HSV Color-Space Ink Detection
  J. Ensemble Voting (combines all methods)

Grading pipeline:
  preprocess (with CLAHE) → find_bubbles (with Hough refinement)
  → fit_grid (with template constraints) → grade_sheet (6-method ensemble)
  → camscanner_enhance → draw_bubble_highlights
"""

import io
import json
import time
import base64
import traceback
from typing import Optional, List, Tuple
from collections import Counter

import cv2
import numpy as np
import uvicorn
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from PIL import Image

app = FastAPI(title="OMR Scanner API v6.0", version="6.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

TARGET_W = 1000


def load_image_bytes(data: bytes) -> np.ndarray:
    pil = Image.open(io.BytesIO(data)).convert("RGB")
    return cv2.cvtColor(np.array(pil), cv2.COLOR_RGB2BGR)


# ═══════════════════════════════════════════════════════════════
# Approach B: 4-Point Fiducial Corner & Homography Rectification
# ═══════════════════════════════════════════════════════════════

def order_points(pts: np.ndarray) -> np.ndarray:
    """Order 4 points as: [TL, TR, BR, BL]."""
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1)
    rect[0] = pts[np.argmin(s)]
    rect[2] = pts[np.argmax(s)]
    d = np.diff(pts, axis=1)
    rect[1] = pts[np.argmin(d)]
    rect[3] = pts[np.argmax(d)]
    return rect


def four_point_transform(image: np.ndarray, pts: np.ndarray) -> np.ndarray:
    """Homography warp to flat rectangular birds-eye view."""
    rect = order_points(pts)
    (tl, tr, br, bl) = rect
    maxWidth = max(int(np.linalg.norm(br - bl)), int(np.linalg.norm(tr - tl)))
    maxHeight = max(int(np.linalg.norm(tr - br)), int(np.linalg.norm(tl - bl)))
    if maxWidth < 200 or maxHeight < 200:
        return image
    dst = np.array([[0, 0], [maxWidth - 1, 0], [maxWidth - 1, maxHeight - 1],
                     [0, maxHeight - 1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(image, M, (maxWidth, maxHeight))


def perspective_warp(img_bgr: np.ndarray) -> np.ndarray:
    """Detect 4 outer corners of document and warp flat."""
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 30, 100)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))
    edges = cv2.dilate(edges, kernel, iterations=2)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours = sorted(contours, key=cv2.contourArea, reverse=True)
    img_area = img_bgr.shape[0] * img_bgr.shape[1]
    for cnt in contours[:5]:
        peri = cv2.arcLength(cnt, True)
        approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
        cnt_area = cv2.contourArea(cnt)
        if len(approx) == 4 and cnt_area > img_area * 0.30:
            pts = approx.reshape(4, 2).astype("float32")
            rect = order_points(pts)
            tl, tr, br, bl = rect
            maxW = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
            maxH = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
            if maxW > 200 and maxH > 200:
                warp_area = maxW * maxH
                area_ratio = warp_area / img_area
                if area_ratio < 0.70 or cnt_area > img_area * 0.92:
                    continue
                return four_point_transform(img_bgr, pts)
    return img_bgr


# ═══════════════════════════════════════════════════════════════
# Preprocessing (with Approach D: CLAHE)
# ═══════════════════════════════════════════════════════════════

def preprocess(raw_bgr):
    """
    Full preprocessing pipeline:
    1. Perspective warp (Approach B)
    2. Resize to TARGET_W
    3. Grayscale + Gaussian blur
    4. CLAHE equalized grayscale (Approach D)
    """
    warped = perspective_warp(raw_bgr)
    h, w = warped.shape[:2]
    target_h = int(h * (TARGET_W / w))
    resized = cv2.resize(warped, (TARGET_W, target_h))
    gray = cv2.cvtColor(resized, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Approach D: CLAHE — equalizes contrast across tiles to eliminate
    # uneven lighting / phone flash shadows
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    gray_clahe = clahe.apply(gray)

    return resized, gray, gray_clahe, blurred, TARGET_W, target_h


# ═══════════════════════════════════════════════════════════════
# Bubble Detection (with Approach H: Hough Circle Refinement)
# ═══════════════════════════════════════════════════════════════

def find_bubbles(gray, blurred, target_h):
    """Detect circular OMR bubbles using adaptive thresholding + contour analysis,
    then refine centers with Hough Circles (Approach H)."""
    all_blobs = []

    # Multi-pass adaptive threshold
    for block_size in [15, 25, 35]:
        for C_val in [5, 8, 12]:
            thresh = cv2.adaptiveThreshold(
                blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                cv2.THRESH_BINARY_INV, block_size, C_val)
            cnts, _ = cv2.findContours(thresh, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in cnts:
                area = cv2.contourArea(cnt)
                peri = cv2.arcLength(cnt, True)
                if peri < 1:
                    continue
                circ = 4 * np.pi * area / (peri * peri)
                if 0.55 < circ < 1.3 and 150 < area < 4000:
                    M = cv2.moments(cnt)
                    if M['m00'] > 0:
                        cx = int(M['m10'] / M['m00'])
                        cy = int(M['m01'] / M['m00'])
                        r = int(np.sqrt(area / np.pi))
                        all_blobs.append((cx, cy, r))

    # Otsu pass
    _, otsu = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    cnts, _ = cv2.findContours(otsu, cv2.RETR_LIST, cv2.CHAIN_APPROX_SIMPLE)
    for cnt in cnts:
        area = cv2.contourArea(cnt)
        peri = cv2.arcLength(cnt, True)
        if peri < 1:
            continue
        circ = 4 * np.pi * area / (peri * peri)
        if 0.55 < circ < 1.3 and 150 < area < 4000:
            M = cv2.moments(cnt)
            if M['m00'] > 0:
                cx = int(M['m10'] / M['m00'])
                cy = int(M['m01'] / M['m00'])
                r = int(np.sqrt(area / np.pi))
                all_blobs.append((cx, cy, r))

    if not all_blobs:
        return []

    # NMS: merge duplicates
    merged = []
    used = set()
    for i, b1 in enumerate(all_blobs):
        if i in used:
            continue
        group = [b1]
        for j in range(i + 1, len(all_blobs)):
            if j in used:
                continue
            if abs(all_blobs[j][0] - b1[0]) < 12 and abs(all_blobs[j][1] - b1[1]) < 12:
                group.append(all_blobs[j])
                used.add(j)
        used.add(i)
        cx = int(np.mean([g[0] for g in group]))
        cy = int(np.mean([g[1] for g in group]))
        r = int(np.median([g[2] for g in group]))
        merged.append((cx, cy, r))

    # Filter header (top 12%)
    header_y = int(target_h * 0.12)
    merged = [b for b in merged if b[1] > header_y]

    if not merged:
        return []

    # Filter by dominant radius to remove Q.No text circles
    radii = [b[2] for b in merged]
    r_counter = Counter(radii)
    dominant_r = r_counter.most_common(1)[0][0]
    median_r = np.median(radii)
    ref_r = max(dominant_r, median_r)
    min_r = max(5, int(ref_r * 0.65))
    merged = [b for b in merged if b[2] >= min_r]

    # ── Approach H: Hough Circle Transform Refinement ──
    # Use HoughCircles to get sub-pixel accurate centers, then update
    # contour-detected bubbles with refined positions.
    if merged:
        merged = _refine_centers_hough(blurred, merged, ref_r)

    return merged


def _refine_centers_hough(blurred, bubbles, avg_r):
    """Approach H: Refine bubble centers using Hough Circle Transform.
    Only UPDATES existing centers — never adds new bubbles."""
    try:
        circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT,
            dp=1.2,
            minDist=int(avg_r * 1.3),
            param1=50, param2=28,
            minRadius=max(5, int(avg_r * 0.6)),
            maxRadius=int(avg_r * 1.5)
        )
    except Exception:
        return bubbles

    if circles is None:
        return bubbles

    hough_pts = [(int(x), int(y), int(r)) for x, y, r in circles[0]]

    refined = []
    match_dist = avg_r * 0.8
    for bx, by, br in bubbles:
        best_hough = None
        best_d = match_dist
        for hx, hy, hr in hough_pts:
            d = np.sqrt((bx - hx) ** 2 + (by - hy) ** 2)
            if d < best_d:
                best_d = d
                best_hough = (hx, hy)
        if best_hough:
            # Use Hough center (more accurate), keep contour radius
            refined.append((best_hough[0], best_hough[1], br))
        else:
            refined.append((bx, by, br))

    return refined


# ═══════════════════════════════════════════════════════════════
# Grid Fitting (with Approach A: Template Constraints)
# ═══════════════════════════════════════════════════════════════

def cluster_values(values, tolerance):
    if not values:
        return []
    sv = sorted(values)
    clusters = [[sv[0]]]
    for v in sv[1:]:
        if v - clusters[-1][-1] <= tolerance:
            clusters[-1].append(v)
        else:
            clusters.append([v])
    return clusters


def fit_grid(bubbles, target_w, target_h, num_choices_override=None, num_questions_override=None):
    """Approach A: Fit OMR grid with template constraint enforcement."""
    if len(bubbles) < 8:
        return {}

    xs = [b[0] for b in bubbles]
    ys = [b[1] for b in bubbles]
    avg_r = int(np.median([b[2] for b in bubbles]))

    # Row detection
    y_tol = max(8, int(avg_r * 1.2))
    y_clusters = cluster_values(ys, y_tol)
    row_sizes = [len(c) for c in y_clusters]
    if not row_sizes:
        return {}
    max_row = max(row_sizes)
    min_row = max(3, int(max_row * 0.35))
    valid_rows = [(np.mean(c), len(c)) for c in y_clusters if len(c) >= min_row]
    if len(valid_rows) < 2:
        return {}
    row_ys = sorted([int(y) for y, n in valid_rows])

    # Column detection
    row_xs = {ry: [] for ry in row_ys}
    for bx, by, br in bubbles:
        best = min(row_ys, key=lambda ry: abs(ry - by))
        if abs(best - by) <= y_tol * 1.5:
            row_xs[best].append(bx)
    all_xs = []
    for ry in row_ys:
        all_xs.extend(row_xs[ry])
    if not all_xs:
        return {}

    x_tol = max(8, int(avg_r * 1.0))
    x_clusters = cluster_values(all_xs, x_tol)
    x_sizes = [len(c) for c in x_clusters]
    if not x_sizes:
        return {}
    max_x = max(x_sizes)
    x_centers = [(int(np.mean(c)), len(c)) for c in x_clusters if len(c) >= max(2, max_x * 0.2)]
    col_xs = sorted([x for x, n in x_centers])
    if len(col_xs) < 3:
        return {}

    # OMR column grouping
    gaps = [col_xs[i + 1] - col_xs[i] for i in range(len(col_xs) - 1)]
    if not gaps:
        return {}
    sorted_gaps = sorted(gaps)
    small_gaps = [g for g in sorted_gaps if g < np.median(sorted_gaps) * 1.5]
    if not small_gaps:
        small_gaps = sorted_gaps[:len(sorted_gaps) // 2 + 1]
    choice_spacing = np.median(small_gaps) if small_gaps else np.median(sorted_gaps)
    separator_threshold = choice_spacing * 1.8

    omr_groups = [[col_xs[0]]]
    for i, gap in enumerate(gaps):
        if gap > separator_threshold:
            omr_groups.append([col_xs[i + 1]])
        else:
            omr_groups[-1].append(col_xs[i + 1])

    # Filter single-element Q.No text columns
    valid_groups = [g for g in omr_groups if len(g) >= 3]
    if not valid_groups:
        valid_groups = omr_groups

    group_sizes = [len(g) for g in valid_groups]
    num_choices = num_choices_override or Counter(group_sizes).most_common(1)[0][0]

    final_groups = []
    for group in valid_groups:
        if len(group) == num_choices:
            final_groups.append(group)
        elif len(group) > num_choices:
            final_groups.append(group[:num_choices])
        elif len(group) >= max(2, num_choices - 1):
            spacing = (group[-1] - group[0]) / (len(group) - 1)
            start = group[0]
            interpolated = [int(start + i * spacing) for i in range(num_choices)]
            final_groups.append(interpolated)

    if not final_groups:
        return {}

    # Approach A: enforce known template constraints
    if num_questions_override:
        expected_cols = expected_rows = None
        if num_questions_override == 20 and num_choices == 4:
            expected_cols, expected_rows = 2, 10
        elif num_questions_override == 100 and num_choices == 5:
            expected_cols, expected_rows = 5, 20
        elif num_questions_override == 50 and num_choices == 4:
            expected_cols, expected_rows = 2, 25
        elif num_questions_override == 100 and num_choices == 4:
            expected_cols, expected_rows = 4, 25
        if expected_cols and len(final_groups) > expected_cols:
            final_groups = final_groups[:expected_cols]
        if expected_rows and len(row_ys) > expected_rows:
            row_ys = row_ys[:expected_rows]

    return {
        "num_omr_cols": len(final_groups),
        "questions_per_col": len(row_ys),
        "num_choices": num_choices,
        "total_questions": len(final_groups) * len(row_ys),
        "bubble_x": final_groups,
        "row_ys": row_ys,
        "avg_radius": avg_r,
    }


# ═══════════════════════════════════════════════════════════════
# Individual Voting Methods (Approaches C, D, E, G, I)
# Each method returns (voted_choice_or_None, confidence_float)
# ═══════════════════════════════════════════════════════════════

def _vote_brightness(brightness):
    """Method 1: Mean brightness — darkest bubble wins (original v5 logic)."""
    if len(brightness) < 2:
        return None, 0.0

    vals = list(brightness.values())
    min_val, max_val = min(vals), max(vals)
    mean_val = np.mean(vals)
    spread = max_val - min_val

    sorted_items = sorted(brightness.items(), key=lambda x: x[1])
    darkest_ch = sorted_items[0][0]
    darkest_val = sorted_items[0][1]
    second_val = sorted_items[1][1]
    gap = second_val - darkest_val

    if spread < 6:
        return None, 0.0

    score = 0.0
    if mean_val > 0:
        rel_dark = (mean_val - darkest_val) / mean_val
        if rel_dark > 0.08:
            score += 0.25
        if rel_dark > 0.15:
            score += 0.15
    if spread > 0:
        gap_ratio = gap / spread
        if gap_ratio > 0.15:
            score += 0.25
        if gap > 12:
            score += 0.15
        if gap > 25:
            score += 0.2

    if score >= 0.4 or gap > 20:
        return darkest_ch, min(1.0, score + 0.1)
    return None, 0.0


def _vote_fill_ratio(fill_ratios):
    """Method 2 — Approach C: Dark pixel fill ratio. Highest fill wins."""
    if len(fill_ratios) < 2:
        return None, 0.0

    sorted_items = sorted(fill_ratios.items(), key=lambda x: x[1], reverse=True)
    top_ch, top_val = sorted_items[0]
    sec_val = sorted_items[1][1]

    if top_val < 0.12:
        return None, 0.0  # nothing meaningfully filled

    gap = top_val - sec_val
    if gap > 0.08 and top_val > 0.15:
        conf = min(1.0, gap / 0.5)
        return top_ch, conf
    return None, 0.0


def _vote_zscore(brightness):
    """Method 3 — Approach G: Z-score statistical outlier detection."""
    if len(brightness) < 2:
        return None, 0.0

    values = list(brightness.values())
    mean_b = np.mean(values)
    std_b = np.std(values)

    if std_b < 3:
        return None, 0.0  # too uniform → blank

    z_scores = {k: (v - mean_b) / std_b for k, v in brightness.items()}
    sorted_z = sorted(z_scores.items(), key=lambda x: x[1])
    darkest_ch, darkest_z = sorted_z[0]
    second_z = sorted_z[1][1] if len(sorted_z) > 1 else 0

    if darkest_z < -1.0:
        z_gap = second_z - darkest_z
        conf = min(1.0, abs(darkest_z) / 3.0)
        return darkest_ch, conf
    return None, 0.0


def _vote_otsu(otsu_fills):
    """Method 4 — Approach E: Per-bubble Otsu fill ratio."""
    if len(otsu_fills) < 2:
        return None, 0.0

    sorted_items = sorted(otsu_fills.items(), key=lambda x: x[1], reverse=True)
    top_ch, top_val = sorted_items[0]
    sec_val = sorted_items[1][1]

    if top_val < 0.20:
        return None, 0.0

    gap = top_val - sec_val
    if gap > 0.08 or (top_val > 0.40 and gap > 0.04):
        conf = min(1.0, gap * 3.0)
        return top_ch, conf
    return None, 0.0


def _vote_ink(ink_ratios):
    """Method 5 — Approach I: HSV color-space ink detection."""
    if len(ink_ratios) < 2:
        return None, 0.0

    sorted_items = sorted(ink_ratios.items(), key=lambda x: x[1], reverse=True)
    top_ch, top_val = sorted_items[0]
    sec_val = sorted_items[1][1]

    if top_val < 0.15:
        return None, 0.0

    gap = top_val - sec_val
    if gap > 0.06 or (top_val > 0.35 and gap > 0.03):
        conf = min(1.0, gap * 4.0)
        return top_ch, conf
    return None, 0.0


# ═══════════════════════════════════════════════════════════════
# Approach J: Ensemble Grading Engine
# ═══════════════════════════════════════════════════════════════

def grade_sheet(gray, layout, answer_key, total_q_override=None,
                gray_clahe=None, color_bgr=None):
    """
    6-method ensemble grading with multi-mark detection.

    Methods voted per question:
      M1  Mean brightness on raw grayscale
      M1b Mean brightness on CLAHE-equalized grayscale  (Approach D)
      M2  Dark pixel fill ratio                         (Approach C)
      M3  Z-score statistical outlier                   (Approach G)
      M4  Per-bubble Otsu fill ratio                    (Approach E)
      M5  HSV color-space ink ratio                     (Approach I)

    Final decision: majority vote (Approach J)
    Multi-mark / erasure flagging:                      (Approach F)
    """
    choice_labels = ['A', 'B', 'C', 'D', 'E', 'F'][:layout["num_choices"]]
    bubble_x = layout["bubble_x"]
    row_ys = layout["row_ys"]
    avg_r = layout["avg_radius"]
    num_omr_cols = layout["num_omr_cols"]
    q_per_col = layout["questions_per_col"]
    sample_r = max(4, int(avg_r * 0.7))

    total_q = total_q_override or (num_omr_cols * q_per_col)

    # Prepare HSV for ink detection (Approach I)
    hsv = None
    if color_bgr is not None:
        hsv = cv2.cvtColor(color_bgr, cv2.COLOR_BGR2HSV)

    # Fall back: if no CLAHE provided, use raw gray
    if gray_clahe is None:
        gray_clahe = gray

    results = []
    correct = wrong = blank = 0

    for c_idx in range(num_omr_cols):
        if c_idx >= len(bubble_x):
            break
        col_xs = bubble_x[c_idx]

        for r_idx in range(q_per_col):
            qno = c_idx * q_per_col + r_idx + 1
            if qno > total_q:
                break
            cy = row_ys[r_idx]

            # ── Collect features for every choice ──
            brightness_raw = {}
            brightness_clahe = {}
            fill_ratios = {}
            otsu_fills = {}
            ink_ratios = {}
            choice_px = {}          # raw pixel arrays per choice

            for ci, ch in enumerate(choice_labels):
                if ci >= len(col_xs):
                    continue
                cx = col_xs[ci]

                # ROI bounds
                y1 = max(0, cy - sample_r)
                y2 = min(gray.shape[0], cy + sample_r + 1)
                x1 = max(0, cx - sample_r)
                x2 = min(gray.shape[1], cx + sample_r + 1)
                if y2 - y1 < 4 or x2 - x1 < 4:
                    continue

                # Circular mask on small ROI (memory-efficient)
                rh, rw = y2 - y1, x2 - x1
                mask = np.zeros((rh, rw), dtype=np.uint8)
                cv2.circle(mask, (cx - x1, cy - y1), sample_r, 255, -1)

                # ── M1: Mean brightness (raw gray) ──
                roi_raw = gray[y1:y2, x1:x2]
                px = roi_raw[mask > 0]
                if len(px) < 5:
                    continue
                brightness_raw[ch] = float(np.mean(px))
                choice_px[ch] = px

                # ── M1b: Mean brightness (CLAHE — Approach D) ──
                roi_clahe = gray_clahe[y1:y2, x1:x2]
                px_clahe = roi_clahe[mask > 0]
                if len(px_clahe) > 0:
                    brightness_clahe[ch] = float(np.mean(px_clahe))

                # ── M4: Per-Bubble Otsu fill ratio (Approach E) ──
                try:
                    _, binary = cv2.threshold(
                        roi_raw, 0, 255,
                        cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                    filled_px = np.sum((binary > 0) & (mask > 0))
                    total_px = np.sum(mask > 0)
                    otsu_fills[ch] = filled_px / max(1, total_px)
                except Exception:
                    otsu_fills[ch] = 0.0

                # ── M5: HSV Ink Detection (Approach I) ──
                if hsv is not None:
                    hsv_roi = hsv[y1:y2, x1:x2]
                    v_ch = hsv_roi[:, :, 2]
                    s_ch = hsv_roi[:, :, 1]
                    # Pencil (dark, low sat) OR Pen (high sat, not bright)
                    pencil = (v_ch < 150) & (mask > 0)
                    pen = (s_ch > 80) & (v_ch < 180) & (mask > 0)
                    ink_mask = pencil | pen
                    ink_px = np.sum(ink_mask)
                    total_mask_px = np.sum(mask > 0)
                    ink_ratios[ch] = ink_px / max(1, total_mask_px)

            # ── M2: Dark Pixel Fill Ratio (Approach C) ──
            # Uses a global threshold computed from ALL choices in this question
            if len(choice_px) >= 2:
                all_px = np.concatenate(list(choice_px.values()))
                global_median = float(np.median(all_px))
                fill_threshold = global_median * 0.65
                for ch, px in choice_px.items():
                    dark_count = np.sum(px < fill_threshold)
                    fill_ratios[ch] = dark_count / len(px)

            # ── Need at least 2 choices to decide ──
            if len(brightness_raw) < 2:
                blank += 1
                results.append({
                    "qno": qno, "detected": None,
                    "correct": answer_key.get(str(qno)),
                    "is_correct": False, "brightness": {},
                    "confidence": 0, "is_multi": False,
                })
                continue

            # ── Collect votes from all methods ──
            votes = []
            confidences = []

            # M1: Brightness (raw)
            v, c = _vote_brightness(brightness_raw)
            if v:
                votes.append(v)
                confidences.append(c)

            # M1b: Brightness (CLAHE — Approach D)
            v, c = _vote_brightness(brightness_clahe)
            if v:
                votes.append(v)
                confidences.append(c)

            # M2: Fill Ratio (Approach C)
            v, c = _vote_fill_ratio(fill_ratios)
            if v:
                votes.append(v)
                confidences.append(c)

            # M3: Z-Score (Approach G) — run on raw brightness values
            v, c = _vote_zscore(brightness_raw)
            if v:
                votes.append(v)
                confidences.append(c)

            # M4: Per-Bubble Otsu (Approach E)
            v, c = _vote_otsu(otsu_fills)
            if v:
                votes.append(v)
                confidences.append(c)

            # M5: HSV Ink (Approach I)
            v, c = _vote_ink(ink_ratios)
            if v:
                votes.append(v)
                confidences.append(c)

            # ── Approach J: Ensemble majority vote ──
            detected = None
            confidence = 0.0
            is_multi = False

            if votes:
                vote_counts = Counter(votes)
                winner, winner_count = vote_counts.most_common(1)[0]
                total_votes = len(votes)

                if total_votes >= 3:
                    # Need strict majority
                    if winner_count > total_votes / 2:
                        detected = winner
                        confidence = winner_count / total_votes
                    else:
                        # Fallback: if top two vote counts differ, pick higher
                        if len(vote_counts) >= 2:
                            second_count = vote_counts.most_common(2)[1][1]
                            if winner_count > second_count:
                                detected = winner
                                confidence = winner_count / total_votes
                elif total_votes == 2:
                    if winner_count == 2:
                        detected = winner
                        confidence = 0.85
                    # else: 1-1 tie → no detection (blank)
                elif total_votes == 1:
                    # Single method voted — trust only if high confidence
                    if confidences[0] >= 0.6:
                        detected = winner
                        confidence = confidences[0] * 0.7

            # ── Approach F: Multi-Mark & Erasure Detection ──
            if detected and len(fill_ratios) >= 2:
                det_fill = fill_ratios.get(detected, 0)
                for other_ch, other_fill in fill_ratios.items():
                    if other_ch == detected:
                        continue
                    if other_fill > 0.25:
                        # Another bubble also has significant fill
                        if det_fill > 0.01:
                            ratio = other_fill / det_fill
                        else:
                            ratio = 0
                        if ratio > 0.70:
                            # Both heavily filled — check brightness gap
                            det_bright = brightness_raw.get(detected, 255)
                            other_bright = brightness_raw.get(other_ch, 255)
                            bright_gap = abs(det_bright - other_bright)
                            if bright_gap < 12:
                                # Truly ambiguous multi-mark
                                is_multi = True
                            # else: erasure — det is clearly darker, keep it

            if detected is None:
                blank += 1

            correct_ans = answer_key.get(str(qno))
            is_correct = (detected is not None and correct_ans is not None
                          and detected == correct_ans)

            if detected is not None:
                if is_correct:
                    correct += 1
                else:
                    wrong += 1

            results.append({
                "qno": qno,
                "detected": detected,
                "correct": correct_ans,
                "is_correct": is_correct,
                "brightness": {k: round(v, 1) for k, v in brightness_raw.items()},
                "confidence": round(confidence, 2),
                "is_multi": is_multi,
            })

    total_actual = len(results)
    return {
        "total": total_actual,
        "detected": correct + wrong,
        "correct": correct,
        "wrong": wrong,
        "blank": blank,
        "score": correct,
        "percentage": round((correct / max(1, total_actual)) * 100, 1),
        "answers": results,
    }


# ═══════════════════════════════════════════════════════════════
# CamScanner Enhancement & Bubble Highlighting
# ═══════════════════════════════════════════════════════════════

def camscanner_enhance(img_bgr: np.ndarray) -> np.ndarray:
    """CamScanner Clean White — whitens shadows/paper, sharpens ink."""
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))
    dilated = cv2.dilate(gray, kernel)
    bg = cv2.medianBlur(dilated, 21)
    norm = gray.astype(np.float32) / np.maximum(bg.astype(np.float32), 1.0)
    norm = np.clip(norm * 255.0, 0, 255).astype(np.uint8)
    table = np.array([
        int(np.clip(255.0 * ((i / 255.0) ** 1.3), 0, 255))
        for i in range(256)
    ], dtype=np.uint8)
    enhanced = cv2.LUT(norm, table)
    return cv2.cvtColor(enhanced, cv2.COLOR_GRAY2BGR)


def draw_bubble_highlights(enhanced_bgr, layout, answers, answer_key):
    """Draw green/red/yellow highlights on detected bubbles."""
    annotated = enhanced_bgr.copy()
    overlay = annotated.copy()
    bubble_x = layout.get("bubble_x", [])
    row_ys = layout.get("row_ys", [])
    avg_r = layout.get("avg_radius", 12)
    num_omr_cols = layout.get("num_omr_cols", 1)
    q_per_col = layout.get("questions_per_col", 1)
    choice_labels = ['A', 'B', 'C', 'D', 'E', 'F'][:layout.get("num_choices", 4)]
    answers_map = {a["qno"]: a for a in answers}

    for c_idx in range(num_omr_cols):
        if c_idx >= len(bubble_x):
            continue
        col_xs = bubble_x[c_idx]
        for r_idx in range(q_per_col):
            qno = c_idx * q_per_col + r_idx + 1
            if qno not in answers_map:
                continue
            ans_info = answers_map[qno]
            detected = ans_info.get("detected")
            correct_key = answer_key.get(str(qno))
            is_correct = ans_info.get("is_correct", False)
            cy = row_ys[r_idx]

            for ci, ch in enumerate(choice_labels):
                if ci >= len(col_xs):
                    continue
                cx = col_xs[ci]
                if ch == detected:
                    if is_correct:
                        cv2.circle(overlay, (cx, cy), int(avg_r * 1.15), (46, 204, 113), -1)
                        cv2.circle(annotated, (cx, cy), int(avg_r * 1.15), (39, 174, 96), 2)
                    else:
                        cv2.circle(overlay, (cx, cy), int(avg_r * 1.15), (52, 73, 235), -1)
                        cv2.circle(annotated, (cx, cy), int(avg_r * 1.15), (41, 55, 190), 2)
                elif ch == correct_key and detected is not None and not is_correct:
                    cv2.circle(annotated, (cx, cy), int(avg_r * 1.15), (46, 204, 113), 2)
                elif ch == correct_key and detected is None:
                    cv2.circle(annotated, (cx, cy), int(avg_r * 1.05), (241, 196, 15), 2)

    alpha = 0.35
    cv2.addWeighted(overlay, alpha, annotated, 1 - alpha, 0, annotated)
    return annotated


# ═══════════════════════════════════════════════════════════════
# API Endpoints
# ═══════════════════════════════════════════════════════════════

@app.get("/")
def root():
    return {"service": "OMR Scanner API", "version": "6.0.0 (Ensemble Engine)", "status": "running"}

@app.get("/health")
@app.get("/health/")
def health():
    return {"status": "ok", "engine": "v6.0-ensemble", "timestamp": time.time()}

@app.post("/detect")
@app.post("/detect/")
async def detect(image: UploadFile = File(...)):
    try:
        data = await image.read()
        raw_bgr = load_image_bytes(data)
        resized, gray, gray_clahe, blurred, tw, th = preprocess(raw_bgr)
        bubbles = find_bubbles(gray, blurred, th)
        layout = fit_grid(bubbles, tw, th)
        if not layout:
            raise HTTPException(status_code=422, detail="No bubbles detected")
        return JSONResponse({"status": "ok", "layout": layout, "bubbles_found": len(bubbles)})
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/grade")
@app.post("/grade/")
async def grade(
    image: UploadFile = File(...),
    answer_key: str = Form('{"all":"A"}'),
    num_questions: Optional[int] = Form(None),
    num_choices: Optional[int] = Form(None),
    session_id: Optional[str] = Form(None),
):
    try:
        t0 = time.time()
        data = await image.read()
        raw_bgr = load_image_bytes(data)
        resized, gray, gray_clahe, blurred, tw, th = preprocess(raw_bgr)

        try:
            key_raw = json.loads(answer_key)
        except Exception:
            key_raw = {"all": "A"}

        bubbles = find_bubbles(gray, blurred, th)
        layout = fit_grid(bubbles, tw, th,
                          num_choices_override=num_choices,
                          num_questions_override=num_questions)

        if not layout:
            raise HTTPException(status_code=422, detail="Could not detect bubble grid.")

        total_q = num_questions or layout["total_questions"]
        default_ans = key_raw.get("default", key_raw.get("all"))
        full_key = {}
        for q in range(1, total_q + 1):
            if str(q) in key_raw:
                full_key[str(q)] = key_raw[str(q)].upper()
            elif default_ans:
                full_key[str(q)] = default_ans.upper()

        # v6 ensemble grading — passes CLAHE gray + color image
        result = grade_sheet(gray, layout, full_key,
                             total_q_override=total_q,
                             gray_clahe=gray_clahe,
                             color_bgr=resized)

        # CamScanner Enhancement & Highlight Overlay
        enhanced_doc = camscanner_enhance(resized)
        highlighted_doc = draw_bubble_highlights(enhanced_doc, layout, result["answers"], full_key)

        _, enc_buf = cv2.imencode('.jpg', highlighted_doc, [int(cv2.IMWRITE_JPEG_QUALITY), 88])
        annotated_b64 = base64.b64encode(enc_buf).decode('utf-8')

        elapsed = round(time.time() - t0, 3)

        return JSONResponse({
            "status": "ok",
            "session_id": session_id or f"scan_{int(time.time())}",
            "processing_time_sec": elapsed,
            "engine": "v6.0-ensemble",
            "layout": {
                "num_omr_cols": layout["num_omr_cols"],
                "questions_per_col": layout["questions_per_col"],
                "num_choices": layout["num_choices"],
                "total_questions": result["total"],
            },
            "summary": {
                "total": result["total"],
                "detected": result["detected"],
                "correct": result["correct"],
                "wrong": result["wrong"],
                "blank": result["blank"],
                "score": result["score"],
                "percentage": result["percentage"],
            },
            "answers": result["answers"],
            "annotated_image_base64": annotated_b64,
        })
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Grading error: {str(e)}\n{traceback.format_exc()}")

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info")
