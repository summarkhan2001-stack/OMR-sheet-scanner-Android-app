@echo off
title OMR Scanner Backend + ngrok Tunnel
echo ====================================================
echo   Starting OMR Scanner Backend (FastAPI + OpenCV)
echo ====================================================
echo.

:: Start python backend server in background
start /B "" python -m uvicorn server:app --host 0.0.0.0 --port 8000

echo Waiting for backend server to initialize...
timeout /t 3 /nobreak >nul

echo.
echo ====================================================
echo   Starting ngrok Tunnel on port 8000
echo   (Ensure ngrok is installed and added to your PATH)
echo ====================================================
echo.

ngrok http 8000
