"""Test v6.0 Ensemble Engine accuracy + timing."""
import sys, time, os

CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CURRENT_DIR)
import server as omr

# Search for sample image relative to script
CANDIDATE_PATHS = [
    os.path.join(CURRENT_DIR, "omr result.jpeg"),
    os.path.join(CURRENT_DIR, "..", "test_sheets", "omr result.jpeg"),
    os.path.join(CURRENT_DIR, "test_sheets", "omr result.jpeg"),
]
IMG = next((p for p in CANDIDATE_PATHS if os.path.exists(p)), None)
if not IMG:
    raise FileNotFoundError("Sample image 'omr result.jpeg' not found in test_sheets or current folder.")
TRUTH = {
    "1":"C","2":"B","3":"C","4":"B","5":"B","6":"C","7":"D","8":"A","9":"A","10":"C",
    "11":"A","12":"B","13":"B","14":"D","15":"C","16":"B","17":"D","18":"B","19":"C","20":"D"
}

with open(IMG, "rb") as f:
    data = f.read()

# Run full pipeline
t0 = time.perf_counter()
raw = omr.load_image_bytes(data)
resized, gray, gray_clahe, blurred, tw, th = omr.preprocess(raw)
bubbles = omr.find_bubbles(gray, blurred, th)
layout = omr.fit_grid(bubbles, tw, th)
result = omr.grade_sheet(gray, layout, TRUTH, gray_clahe=gray_clahe, color_bgr=resized)
elapsed = (time.perf_counter() - t0) * 1000

print(f"Engine: v6.0 Ensemble")
print(f"Bubbles found: {len(bubbles)}")
print(f"Layout: {layout['num_omr_cols']} cols x {layout['questions_per_col']} rows x {layout['num_choices']} choices")
print(f"Time: {elapsed:.0f}ms")
print(f"\nResults: {result['correct']}/{result['total']} correct, {result['wrong']} wrong, {result['blank']} blank")
print(f"Accuracy: {result['percentage']}%")

# Detail
print(f"\nPer-question breakdown:")
for a in result["answers"]:
    status = "OK" if a["is_correct"] else ("WRONG" if a["detected"] else "BLANK")
    multi = " [MULTI-MARK]" if a.get("is_multi") else ""
    print(f"  Q{a['qno']:>2}: detected={a['detected']} expected={a['correct']} conf={a['confidence']:.2f} {status}{multi}")

# Verify 100% accuracy
if result["correct"] == 20 and result["wrong"] == 0 and result["blank"] == 0:
    print(f"\n{'='*50}")
    print(f"  PASS: 20/20 = 100% accuracy maintained!")
    print(f"{'='*50}")
else:
    print(f"\n{'='*50}")
    print(f"  FAIL: Accuracy dropped — {result['correct']}/20")
    print(f"{'='*50}")
