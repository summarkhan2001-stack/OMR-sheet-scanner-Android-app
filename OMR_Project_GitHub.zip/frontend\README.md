# OMR Scanner App — Local Setup & Run Guide

## Architecture

```
omr_scanner_app/
├── backend/           ← FastAPI Python server (OMR grading engine)
│   ├── app.py         ← REST API endpoints
│   ├── omr_engine.py  ← Udayraj-style OpenCV bubble detection
│   └── requirements.txt
├── lib/               ← Flutter app (web/Windows)
│   ├── main.dart
│   ├── screens/       ← All UI screens
│   ├── services/      ← API service + SharedPreferences storage
│   └── models/        ← Exam, ScannedSheet, DetectedAnswer
├── start_backend.bat  ← Launch backend server only
└── start_app.bat      ← Launch both backend + Flutter web app
```

## Quick Start

### Step 1 — Start the Backend
Double-click `start_backend.bat` **or** run:
```powershell
cd backend
python -m uvicorn app:app --host 127.0.0.1 --port 8000 --reload
```
- API docs: http://127.0.0.1:8000/docs
- Health: http://127.0.0.1:8000/api/v1/health

### Step 2 — Start the Flutter App
In a NEW terminal:
```powershell
flutter run -d chrome --web-port 8080
```
App opens at **http://localhost:8080**

**Or use the master launcher:**
```
start_app.bat   ← starts both together
```

## Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.10+ |
| pip packages | `pip install -r backend/requirements.txt` |
| Flutter | 3.10+ |
| Chrome | any |

## How to Use

1. **Create an exam** — tap "New Exam", fill in title, question count, marking scheme
2. **Set answer key** — tap "Set up" → enter answers manually per question
3. **Scan a sheet** — tap "Scan sheet" → select file → "Grade Sheet"
4. **Demo mode** — tap "Use Demo Mode" to see results without a real sheet
5. **Batch scan** — tap "Batch scan" to grade multiple sheets in a session
6. **Analytics** — view pass rate, score distribution, question analysis
7. **Export** — go to Batch tab → "Export all (CSV)"

## Supported Exam Templates (Backend)

| Template | Questions | Marking |
|----------|-----------|---------|
| JEE Main | 90 | +4 / -1 |
| NEET | 180 | +4 / -1 |
| MDCAT | 210 | +5 / -1.25 |
| SAT | 60 | +1 / 0 |
| Custom 20 | 20 | +1 / 0 |
| Custom 40 | 40 | +1 / 0 |

## Troubleshooting

### "Failed to grade sheet. Is the backend running?"
→ Start the backend first: `cd backend && python -m uvicorn app:app --port 8000`

### CORS error in browser
→ The backend already has `allow_origins=["*"]` so this should not happen. Make sure backend is on port 8000.

### "Building with plugins requires symlink support" (Windows)
→ This only affects native Windows `.exe` build — enable Developer Mode in Settings → System → For Developers → Developer Mode = ON. The **web build** works without this.

### Flutter web port conflict
→ Change port: `flutter run -d chrome --web-port 9090`
