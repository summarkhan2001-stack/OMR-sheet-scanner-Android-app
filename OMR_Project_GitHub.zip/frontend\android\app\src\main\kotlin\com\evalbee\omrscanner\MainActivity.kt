package com.evalbee.omrscanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
