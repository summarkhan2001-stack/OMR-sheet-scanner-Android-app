package com.example.omr_scanner_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
