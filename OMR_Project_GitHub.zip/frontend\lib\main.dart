import 'package:flutter/material.dart';
import 'models/exam.dart';
import 'models/scan_result.dart';
import 'screens/analytics_screen.dart';
import 'screens/batch_summary_screen.dart';
import 'screens/capture_key_screen.dart';
import 'screens/create_exam_screen.dart';
import 'screens/home_screen.dart';
import 'screens/onboarding_screen.dart';
import 'screens/result_screen.dart';
import 'screens/live_camera_scan_screen.dart';
import 'screens/settings_screen.dart';
import 'services/app_state.dart';
import 'services/api_service.dart';
import 'theme/app_theme.dart';

final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
    debugPrint('Flutter Error: ${details.exception}');
  };
  runApp(const OmrApp());
}

class OmrApp extends StatefulWidget {
  const OmrApp({super.key});

  @override
  State<OmrApp> createState() => _OmrAppState();
}

class _OmrAppState extends State<OmrApp> {
  final AppState _appState = AppState();
  int _currentTab = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _initApp();
  }

  Future<void> _initApp() async {
    try {
      await ApiService.loadBaseUrl();
      await _appState.init();
    } catch (e, stack) {
      debugPrint('Init error: $e\n$stack');
    } finally {
      if (mounted) {
        _appState.addListener(() {
          if (mounted) setState(() {});
        });
        setState(() => _loading = false);
      }
    }
  }

  void _openCreateExam([BuildContext? ctx]) {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.push(
      MaterialPageRoute(
        builder: (context) => CreateExamScreen(
          onSubmit: (newExam) {
            _appState.addExam(newExam);
            _openCaptureKey(newExam);
          },
        ),
      ),
    );
  }

  void _openCaptureKey(Exam exam, [BuildContext? ctx]) {
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.push(
      MaterialPageRoute(
        builder: (context) => CaptureKeyScreen(
          exam: exam,
          onSaveKey: (key) {
            _appState.updateAnswerKey(exam.id, key);
          },
        ),
      ),
    );
  }

  void _openSingleScan([BuildContext? ctx]) {
    var exam = _appState.selectedExam;
    if (exam == null) {
      if (_appState.exams.isNotEmpty) {
        exam = _appState.exams.first;
        _appState.selectExam(exam);
      } else {
        _openCreateExam();
        return;
      }
    }
    if (!exam.hasAnswerKey) {
      final defaultKey = <int, String>{};
      final choices = ['A', 'B', 'C', 'D', 'E'].sublist(0, exam.choicesPerQuestion);
      for (int i = 1; i <= exam.numQuestions; i++) {
        defaultKey[i] = choices[(i - 1) % choices.length];
      }
      _appState.updateAnswerKey(exam.id, defaultKey);
      exam = _appState.selectedExam;
    }

    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.push(
      MaterialPageRoute(
        builder: (context) => LiveCameraScanScreen(
          exam: exam!,
          sessionId: 'session_${DateTime.now().millisecondsSinceEpoch}',
          appState: _appState,
          isBatch: false,
        ),
      ),
    );
  }

  void _openBatchScan([BuildContext? ctx]) {
    var exam = _appState.selectedExam;
    if (exam == null) {
      if (_appState.exams.isNotEmpty) {
        exam = _appState.exams.first;
        _appState.selectExam(exam);
      } else {
        _openCreateExam();
        return;
      }
    }
    if (!exam.hasAnswerKey) {
      final defaultKey = <int, String>{};
      final choices = ['A', 'B', 'C', 'D', 'E'].sublist(0, exam.choicesPerQuestion);
      for (int i = 1; i <= exam.numQuestions; i++) {
        defaultKey[i] = choices[(i - 1) % choices.length];
      }
      _appState.updateAnswerKey(exam.id, defaultKey);
      exam = _appState.selectedExam;
    }

    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.push(
      MaterialPageRoute(
        builder: (context) => LiveCameraScanScreen(
          exam: exam!,
          sessionId: 'batch_${DateTime.now().millisecondsSinceEpoch}',
          appState: _appState,
          isBatch: true,
        ),
      ),
    );
  }

  void _openResult(ScannedSheet sheet, [BuildContext? ctx]) {
    final exam = _appState.exams.cast<Exam?>().firstWhere(
      (e) => e?.id == sheet.examId,
      orElse: () => _appState.selectedExam,
    );
    if (exam == null) return;
    final nav = navigatorKey.currentState;
    if (nav == null) return;
    nav.push(
      MaterialPageRoute(
        builder: (context) => ResultScreen(sheet: sheet, exam: exam),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      navigatorKey: navigatorKey,
      title: 'OMR Scanner',
      theme: AppTheme.lightTheme,
      debugShowCheckedModeBanner: false,
      home: Builder(
        builder: (innerContext) {
          if (_loading) {
            return const Scaffold(
              body: Center(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    CircularProgressIndicator(),
                    SizedBox(height: 16),
                    Text('Loading...', style: TextStyle(fontSize: 14)),
                  ],
                ),
              ),
            );
          }

          if (!_appState.isOnboarded) {
            return OnboardingScreen(
              onFinish: () => _appState.completeOnboarding(),
            );
          }

          final List<Widget> pages = [
            HomeScreen(
              state: _appState,
              onTabSelected: (index) => setState(() => _currentTab = index),
              onStartSingleScan: () => _openSingleScan(innerContext),
              onStartBatchScan: () => _openBatchScan(innerContext),
              onCreateExam: () => _openCreateExam(innerContext),
              onSelectResult: (sheet) => _openResult(sheet, innerContext),
              onSetupAnswerKey: () {
                if (_appState.selectedExam != null) {
                  _openCaptureKey(_appState.selectedExam!, innerContext);
                } else {
                  _openCreateExam(innerContext);
                }
              },
            ),
            BatchSummaryScreen(
              state: _appState,
              onSelectSheet: (sheet) => _openResult(sheet, innerContext),
            ),
            AnalyticsScreen(state: _appState),
            SettingsScreen(state: _appState),
          ];

          return Scaffold(
            body: IndexedStack(
              index: _currentTab,
              children: pages,
            ),
            floatingActionButton: FloatingActionButton(
              onPressed: () => _openSingleScan(innerContext),
              backgroundColor: AppColors.primary,
              elevation: 4,
              shape: const CircleBorder(),
              child: const Icon(Icons.camera_alt, color: Colors.white, size: 28),
            ),
            floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
            bottomNavigationBar: BottomNavigationBar(
              currentIndex: _currentTab,
              onTap: (index) => setState(() => _currentTab = index),
              type: BottomNavigationBarType.fixed,
              selectedItemColor: AppColors.primary,
              unselectedItemColor: AppColors.textMuted,
              items: const [
                BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
                BottomNavigationBarItem(icon: Icon(Icons.format_list_bulleted), label: 'Batch'),
                BottomNavigationBarItem(icon: Icon(Icons.bar_chart_outlined), label: 'Analytics'),
                BottomNavigationBarItem(icon: Icon(Icons.settings_outlined), label: 'Settings'),
              ],
            ),
          );
        },
      ),
    );
  }
}
