enum ChoiceOption { A, B, C, D, E }

extension ChoiceOptionX on ChoiceOption {
  String get label => name;
}

class MarkingScheme {
  final double correctMark;
  final double blankMark;
  final bool negativeMarking;
  final double wrongMark;

  const MarkingScheme({
    this.correctMark = 1.0,
    this.blankMark = 0.0,
    this.negativeMarking = false,
    this.wrongMark = 0.0,
  });

  Map<String, dynamic> toJson() => {
    'correct_mark': correctMark,
    'blank_mark': blankMark,
    'negative_marking': negativeMarking,
    'wrong_mark': wrongMark,
  };

  factory MarkingScheme.fromJson(Map<String, dynamic> json) {
    return MarkingScheme(
      correctMark: (json['correct_mark'] as num?)?.toDouble() ?? 1.0,
      blankMark: (json['blank_mark'] as num?)?.toDouble() ?? 0.0,
      negativeMarking: json['negative_marking'] as bool? ?? false,
      wrongMark: (json['wrong_mark'] as num?)?.toDouble() ?? 0.0,
    );
  }
}

class Exam {
  final String id;
  final String title;
  final int numQuestions;
  final int choicesPerQuestion;
  final bool hasRollNumber;
  final int rollNumberDigits;
  final MarkingScheme markingScheme;
  final Map<int, String> answerKey;
  final DateTime createdAt;

  Exam({
    required this.id,
    required this.title,
    required this.numQuestions,
    this.choicesPerQuestion = 4,
    this.hasRollNumber = true,
    this.rollNumberDigits = 5,
    this.markingScheme = const MarkingScheme(),
    Map<int, String>? answerKey,
    DateTime? createdAt,
  })  : answerKey = answerKey ?? {},
        createdAt = createdAt ?? DateTime.now();

  bool get hasAnswerKey => answerKey.length == numQuestions;

  double get maxPossibleScore => numQuestions * markingScheme.correctMark;

  Map<String, dynamic> toJson() => {
    'id': id,
    'title': title,
    'num_questions': numQuestions,
    'choices_per_question': choicesPerQuestion,
    'has_roll_number': hasRollNumber,
    'roll_number_digits': rollNumberDigits,
    'marking_scheme': markingScheme.toJson(),
    'answer_key': answerKey.map((k, v) => MapEntry(k.toString(), v)),
    'created_at': createdAt.toIso8601String(),
  };

  factory Exam.fromJson(Map<String, dynamic> json) {
    final rawKey = json['answer_key'] as Map<String, dynamic>? ?? {};
    final answerKey = rawKey.map((k, v) => MapEntry(int.parse(k), v as String));
    return Exam(
      id: json['id'] as String,
      title: json['title'] as String,
      numQuestions: json['num_questions'] as int,
      choicesPerQuestion: json['choices_per_question'] as int? ?? 4,
      hasRollNumber: json['has_roll_number'] as bool? ?? true,
      rollNumberDigits: json['roll_number_digits'] as int? ?? 5,
      markingScheme: json['marking_scheme'] != null
          ? MarkingScheme.fromJson(json['marking_scheme'] as Map<String, dynamic>)
          : const MarkingScheme(),
      answerKey: answerKey,
      createdAt: json['created_at'] != null
          ? DateTime.parse(json['created_at'] as String)
          : DateTime.now(),
    );
  }

  Exam copyWith({
    String? id,
    String? title,
    int? numQuestions,
    int? choicesPerQuestion,
    bool? hasRollNumber,
    int? rollNumberDigits,
    MarkingScheme? markingScheme,
    Map<int, String>? answerKey,
    DateTime? createdAt,
  }) {
    return Exam(
      id: id ?? this.id,
      title: title ?? this.title,
      numQuestions: numQuestions ?? this.numQuestions,
      choicesPerQuestion: choicesPerQuestion ?? this.choicesPerQuestion,
      hasRollNumber: hasRollNumber ?? this.hasRollNumber,
      rollNumberDigits: rollNumberDigits ?? this.rollNumberDigits,
      markingScheme: markingScheme ?? this.markingScheme,
      answerKey: answerKey ?? Map.from(this.answerKey),
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
