enum FlagReason { doubleMark, lightMark, offGrid }

class ScanFlag {
  final int questionNo;
  final FlagReason reason;

  ScanFlag({required this.questionNo, required this.reason});

  String get description {
    switch (reason) {
      case FlagReason.doubleMark:
        return 'Multiple choices marked';
      case FlagReason.lightMark:
        return 'Light / low confidence mark';
      case FlagReason.offGrid:
        return 'Alignment shift near bubble';
    }
  }

  Map<String, dynamic> toJson() => {
    'question_no': questionNo,
    'reason': reason.name,
  };

  factory ScanFlag.fromJson(Map<String, dynamic> json) {
    FlagReason reason = FlagReason.lightMark;
    final reasonStr = json['reason'] as String? ?? '';
    if (reasonStr == 'doubleMark' || reasonStr == 'double_mark') reason = FlagReason.doubleMark;
    if (reasonStr == 'offGrid' || reasonStr == 'off_grid') reason = FlagReason.offGrid;
    if (reasonStr == 'lightMark' || reasonStr == 'light_mark') reason = FlagReason.lightMark;
    return ScanFlag(questionNo: json['question_no'] as int, reason: reason);
  }
}

class DetectedAnswer {
  final int questionNo;
  final String? markedChoice;
  final double confidence;
  final bool isCorrect;

  DetectedAnswer({
    required this.questionNo,
    this.markedChoice,
    this.confidence = 1.0,
    required this.isCorrect,
  });

  DetectedAnswer copyWith({
    int? questionNo,
    String? markedChoice,
    double? confidence,
    bool? isCorrect,
  }) {
    return DetectedAnswer(
      questionNo: questionNo ?? this.questionNo,
      markedChoice: markedChoice ?? this.markedChoice,
      confidence: confidence ?? this.confidence,
      isCorrect: isCorrect ?? this.isCorrect,
    );
  }

  Map<String, dynamic> toJson() => {
    'question_no': questionNo,
    'marked_choice': markedChoice,
    'confidence': confidence,
    'is_correct': isCorrect,
  };

  factory DetectedAnswer.fromJson(Map<String, dynamic> json) {
    return DetectedAnswer(
      questionNo: json['question_no'] as int,
      markedChoice: json['marked_choice'] as String?,
      confidence: (json['confidence'] as num?)?.toDouble() ?? 1.0,
      isCorrect: json['is_correct'] as bool? ?? false,
    );
  }
}

enum SheetStatus { clean, flagged, unreadable }

class ScannedSheet {
  final String id;
  final String sessionId;
  final String examId;
  final String? rollNumber;
  final String? imageUri;
  final String? annotatedImageBase64;
  final Map<int, DetectedAnswer> detectedAnswers;
  final double score;
  final int totalQuestions;
  final int correctCount;
  final int wrongCount;
  final int blankCount;
  final List<ScanFlag> flags;
  final bool reviewed;
  final DateTime createdAt;

  ScannedSheet({
    required this.id,
    required this.sessionId,
    required this.examId,
    this.rollNumber,
    this.imageUri,
    this.annotatedImageBase64,
    required this.detectedAnswers,
    required this.score,
    required this.totalQuestions,
    required this.correctCount,
    required this.wrongCount,
    required this.blankCount,
    this.flags = const [],
    this.reviewed = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  SheetStatus get status {
    if (correctCount == 0 && wrongCount == 0 && blankCount == totalQuestions) {
      return SheetStatus.unreadable;
    }
    // FIX: Only flagged if there are flags AND not yet reviewed
    if (flags.isNotEmpty && !reviewed) {
      return SheetStatus.flagged;
    }
    return SheetStatus.clean;
  }

  double get percentage => totalQuestions > 0 ? (score / totalQuestions) * 100 : 0;

  Map<String, dynamic> toJson() => {
    'id': id,
    'session_id': sessionId,
    'exam_id': examId,
    'roll_number': rollNumber,
    'image_uri': imageUri,
    'annotated_image_base64': annotatedImageBase64,
    'detected_answers': detectedAnswers.map((k, v) => MapEntry(k.toString(), v.toJson())),
    'score': score,
    'total_questions': totalQuestions,
    'correct_count': correctCount,
    'wrong_count': wrongCount,
    'blank_count': blankCount,
    'flags': flags.map((f) => f.toJson()).toList(),
    'reviewed': reviewed,
    'created_at': createdAt.toIso8601String(),
  };

  factory ScannedSheet.fromJson(Map<String, dynamic> json) {
    final rawAnswers = json['detected_answers'] as Map<String, dynamic>? ?? {};
    final answers = rawAnswers.map((k, v) => MapEntry(int.parse(k), DetectedAnswer.fromJson(v as Map<String, dynamic>)));
    final rawFlags = json['flags'] as List<dynamic>? ?? [];
    final flags = rawFlags.map((f) => ScanFlag.fromJson(f as Map<String, dynamic>)).toList();
    return ScannedSheet(
      id: json['id'] as String,
      sessionId: json['session_id'] as String,
      examId: json['exam_id'] as String,
      rollNumber: json['roll_number'] as String?,
      imageUri: json['image_uri'] as String?,
      annotatedImageBase64: json['annotated_image_base64'] as String?,
      detectedAnswers: answers,
      score: (json['score'] as num).toDouble(),
      totalQuestions: json['total_questions'] as int,
      correctCount: json['correct_count'] as int,
      wrongCount: json['wrong_count'] as int,
      blankCount: json['blank_count'] as int,
      flags: flags,
      reviewed: json['reviewed'] as bool? ?? false,
      createdAt: json['created_at'] != null ? DateTime.parse(json['created_at'] as String) : DateTime.now(),
    );
  }

  ScannedSheet copyWith({
    String? id,
    String? sessionId,
    String? examId,
    String? rollNumber,
    String? imageUri,
    String? annotatedImageBase64,
    Map<int, DetectedAnswer>? detectedAnswers,
    double? score,
    int? totalQuestions,
    int? correctCount,
    int? wrongCount,
    int? blankCount,
    List<ScanFlag>? flags,
    bool? reviewed,
    DateTime? createdAt,
  }) {
    return ScannedSheet(
      id: id ?? this.id,
      sessionId: sessionId ?? this.sessionId,
      examId: examId ?? this.examId,
      rollNumber: rollNumber ?? this.rollNumber,
      imageUri: imageUri ?? this.imageUri,
      annotatedImageBase64: annotatedImageBase64 ?? this.annotatedImageBase64,
      detectedAnswers: detectedAnswers ?? this.detectedAnswers,
      score: score ?? this.score,
      totalQuestions: totalQuestions ?? this.totalQuestions,
      correctCount: correctCount ?? this.correctCount,
      wrongCount: wrongCount ?? this.wrongCount,
      blankCount: blankCount ?? this.blankCount,
      flags: flags ?? this.flags,
      reviewed: reviewed ?? this.reviewed,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
