import 'dart:math';
import 'package:flutter/material.dart';
import '../models/exam.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class AnalyticsScreen extends StatelessWidget {
  final AppState state;

  const AnalyticsScreen({super.key, required this.state});

  @override
  Widget build(BuildContext context) {
    final selectedExam = state.selectedExam;
    final filteredScans = state.recentScans.where((s) => s.examId == (selectedExam?.id ?? '')).toList();
    final scores = filteredScans.map((s) => s.score).toList();

    final double avg = scores.isEmpty ? 0 : scores.reduce((a, b) => a + b) / scores.length;
    final double highest = scores.isEmpty ? 0 : scores.reduce(max);
    final double lowest = scores.isEmpty ? 0 : scores.reduce(min);

    // Score distribution: 5 bins
    final int totalQ = selectedExam?.numQuestions ?? 1;
    final double maxScore = selectedExam?.maxPossibleScore ?? totalQ.toDouble();
    final double binSize = maxScore > 0 ? maxScore / 5 : 1;
    final List<int> bins = List.filled(5, 0);
    for (final s in scores) {
      int binIdx = (s / binSize).floor().clamp(0, 4);
      bins[binIdx]++;
    }
    final int maxBin = bins.isEmpty ? 1 : bins.reduce(max).clamp(1, 999);

    // Hardest questions
    final Map<int, List<bool>> questionResults = {};
    for (final scan in filteredScans) {
      scan.detectedAnswers.forEach((qNo, ans) {
        questionResults.putIfAbsent(qNo, () => []);
        questionResults[qNo]!.add(ans.isCorrect);
      });
    }
    final hardest = questionResults.entries
        .map((e) {
          final correctRate = e.value.where((b) => b).length / e.value.length;
          return {'qNo': e.key, 'rate': correctRate};
        })
        .toList()
      ..sort((a, b) => (a['rate'] as double).compareTo(b['rate'] as double));
    final top3Hardest = hardest.take(5).toList();

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(title: const Text('Analytics')),
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Dropdown selector
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.borderStrong),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<Exam>(
                    value: selectedExam,
                    isExpanded: true,
                    hint: const Text('Select an exam'),
                    items: state.exams.map((exam) {
                      return DropdownMenuItem<Exam>(
                        value: exam,
                        child: Text(exam.title, style: const TextStyle(fontSize: 14)),
                      );
                    }).toList(),
                    onChanged: (exam) => state.selectExam(exam),
                  ),
                ),
              ),
            ),

            if (filteredScans.isEmpty)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.bar_chart_outlined, size: 48, color: AppColors.textMuted),
                      const SizedBox(height: 12),
                      Text('No scans yet for this exam', style: TextStyle(color: AppColors.textMuted, fontSize: 14)),
                      const SizedBox(height: 4),
                      Text('Scan some sheets to see analytics', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
              )
            else ...[
              // 3 quick stats row
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Row(
                  children: [
                    Expanded(child: _buildMetricCard('Average', avg.toStringAsFixed(1))),
                    const SizedBox(width: 8),
                    Expanded(child: _buildMetricCard('Highest', highest.toStringAsFixed(1))),
                    const SizedBox(width: 8),
                    Expanded(child: _buildMetricCard('Lowest', lowest.toStringAsFixed(1))),
                  ],
                ),
              ),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                child: Row(
                  children: [
                    Expanded(child: _buildMetricCard('Scanned', '${filteredScans.length}')),
                    const SizedBox(width: 8),
                    Expanded(child: _buildMetricCard('Pass Rate', '${(filteredScans.where((s) => s.score / (selectedExam?.numQuestions ?? 1) >= 0.5).length / filteredScans.length * 100).round()}%')),
                    const SizedBox(width: 8),
                    Expanded(child: _buildMetricCard('Max Marks', maxScore.toStringAsFixed(0))),
                  ],
                ),
              ),

              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text('Score distribution', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              ),

              // Histogram bar chart
              Container(
                height: 140,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: List.generate(5, (i) {
                    final rangeStart = (binSize * i).round();
                    final rangeEnd = (binSize * (i + 1)).round();
                    final heightPct = bins[i] / maxBin;
                    return _BarItem(
                      label: '$rangeStart-$rangeEnd',
                      heightPct: heightPct.clamp(0.02, 1.0),
                      isHighlight: i == 2 || i == 3,
                      count: bins[i],
                    );
                  }),
                ),
              ),

              const Padding(
                padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: Text('Hardest questions', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
              ),

              Expanded(
                child: top3Hardest.isEmpty
                    ? const Center(child: Text('No data', style: TextStyle(color: AppColors.textMuted)))
                    : ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        children: top3Hardest.map((q) {
                          final qNo = q['qNo'] as int;
                          final rate = q['rate'] as double;
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text('Q$qNo', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                                Text('${(rate * 100).round()}% correct', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMetricCard(String label, String val) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppColors.surface1,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          const SizedBox(height: 4),
          Text(val, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}

class _BarItem extends StatelessWidget {
  final String label;
  final double heightPct;
  final bool isHighlight;
  final int count;

  const _BarItem({required this.label, required this.heightPct, required this.isHighlight, required this.count});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text('$count', style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
          const SizedBox(height: 2),
          Expanded(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: FractionallySizedBox(
                heightFactor: heightPct,
                widthFactor: 0.6,
                child: Container(
                  decoration: BoxDecoration(
                    color: isHighlight ? AppColors.primary : AppColors.accentBg,
                    borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 9, color: AppColors.textMuted)),
        ],
      ),
    );
  }
}
