import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/scan_result.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class BatchScanScreen extends StatefulWidget {
  final AppState state;
  final VoidCallback onFinishBatch;

  const BatchScanScreen({super.key, required this.state, required this.onFinishBatch});

  @override
  State<BatchScanScreen> createState() => _BatchScanScreenState();
}

class _BatchScanScreenState extends State<BatchScanScreen> {
  final ImagePicker _picker = ImagePicker();
  final List<ScannedSheet> _sessionScans = [];
  bool _isProcessing = false;
  XFile? _lastCaptured;
  int _scannedCount = 0;

  Future<void> _captureAndGrade(ImageSource source) async {
    final exam = widget.state.selectedExam;
    if (exam == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No exam selected')),
      );
      return;
    }

    try {
      if (!kIsWeb && source == ImageSource.camera) {
        final status = await Permission.camera.request();
        if (status.isPermanentlyDenied) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Camera permission permanently denied. Enable it in App Settings.'),
              action: SnackBarAction(label: 'Settings', onPressed: () => openAppSettings()),
            ),
          );
          return;
        } else if (!status.isGranted) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Camera permission required for batch capture.')),
          );
          return;
        }
      }

      final XFile? picked = await _picker.pickImage(
        source: source,
        imageQuality: 92,
        maxWidth: 1800,
        maxHeight: 1800,
      );
      if (picked == null) return;

      setState(() {
        _isProcessing = true;
        _lastCaptured = picked;
      });

      // Grade via Python Backend
      final ScannedSheet? result = await ApiService.gradeSheet(
        imageFile: picked,
        exam: exam,
        sessionId: 'batch_${DateTime.now().millisecondsSinceEpoch}',
      );

      if (result == null) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to grade sheet. Please ensure backend is reachable and image is clear.'),
            backgroundColor: AppColors.danger,
          ),
        );
        return;
      }

      if (!mounted) return;

      widget.state.addScanResult(result);
      setState(() {
        _sessionScans.insert(0, result);
        _scannedCount++;
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  Future<void> _pickMultipleFromGallery() async {
    final exam = widget.state.selectedExam;
    if (exam == null) return;

    try {
      final List<XFile> picked = await _picker.pickMultiImage(
        imageQuality: 92,
        maxWidth: 1800,
        maxHeight: 1800,
      );
      if (picked.isEmpty) return;

      setState(() => _isProcessing = true);

      for (final xfile in picked) {
        if (!mounted) break;

        final ScannedSheet? result = await ApiService.gradeSheet(
          imageFile: xfile,
          exam: exam,
          sessionId: 'batch_${DateTime.now().millisecondsSinceEpoch}',
        );

        if (result != null) {
          widget.state.addScanResult(result);
          setState(() {
            _sessionScans.insert(0, result);
            _lastCaptured = xfile;
            _scannedCount++;
          });
        }
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error importing photos: $e')),
      );
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final exam = widget.state.selectedExam;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text(exam?.title ?? 'Batch Scan'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 12),
            child: TextButton(
              onPressed: _sessionScans.isEmpty ? null : widget.onFinishBatch,
              child: const Text('Finish', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.accentBg,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text('📱 $_scannedCount sheets graded on-device',
                        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.accentText)),
                  ),
                  const Spacer(),
                  if (_sessionScans.isNotEmpty)
                    TextButton.icon(
                      onPressed: widget.onFinishBatch,
                      icon: const Icon(Icons.arrow_forward, size: 16),
                      label: const Text('View All'),
                    ),
                ],
              ),
            ),

            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: Colors.grey[100],
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border, width: 2),
                  ),
                  child: Stack(
                    children: [
                      Center(
                        child: _isProcessing
                            ? const Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  CircularProgressIndicator(color: AppColors.primary),
                                  SizedBox(height: 12),
                                  Text('Grading sheet on mobile...', style: TextStyle(color: AppColors.textMuted)),
                                ],
                              )
                            : _lastCaptured != null
                                ? ClipRRect(
                                    borderRadius: BorderRadius.circular(14),
                                    child: FutureBuilder<List<int>>(
                                      future: _lastCaptured!.readAsBytes().then((b) => b.toList()),
                                      builder: (ctx, snap) {
                                        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                                        return Image.memory(
                                          Uint8List.fromList(snap.data!),
                                          fit: BoxFit.contain,
                                        );
                                      },
                                    ),
                                  )
                                : const Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Icon(Icons.document_scanner_outlined, color: AppColors.textMuted, size: 48),
                                      SizedBox(height: 8),
                                      Text('Capture sheets one by one', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                                      Text('or import multiple from gallery', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                                    ],
                                  ),
                      ),
                      if (_scannedCount > 0)
                        Positioned(
                          top: 12,
                          left: 12,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                            decoration: BoxDecoration(
                              color: Colors.black54,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              '$_scannedCount scanned',
                              style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),

            if (_sessionScans.isNotEmpty) ...[
              const Padding(
                padding: EdgeInsets.fromLTRB(16, 4, 16, 6),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Session Scans', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.textSecondary)),
                ),
              ),
              SizedBox(
                height: 72,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: _sessionScans.length,
                  itemBuilder: (context, index) {
                    final scan = _sessionScans[index];
                    final isClean = scan.status == SheetStatus.clean;
                    return Container(
                      width: 90,
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: isClean ? AppColors.successBg : AppColors.warningBg,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: isClean ? AppColors.success : AppColors.warning),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(scan.rollNumber ?? '#${index + 1}',
                              style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold), maxLines: 1),
                          Text('${scan.score.toStringAsFixed(0)}/${scan.totalQuestions}',
                              style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: isClean ? AppColors.success : AppColors.warning)),
                        ],
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 8),
            ],

            Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: SizedBox(
                      height: 52,
                      child: ElevatedButton.icon(
                        onPressed: _isProcessing ? null : () => _captureAndGrade(ImageSource.camera),
                        icon: const Icon(Icons.camera_alt, size: 22),
                        label: const Text('Capture Sheet', style: TextStyle(fontWeight: FontWeight.bold)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary,
                          foregroundColor: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: SizedBox(
                      height: 52,
                      child: OutlinedButton.icon(
                        onPressed: _isProcessing ? null : _pickMultipleFromGallery,
                        icon: const Icon(Icons.photo_library_outlined, size: 18),
                        label: const Text('Import'),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
