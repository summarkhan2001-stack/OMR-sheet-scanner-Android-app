import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../models/scan_result.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class BatchSummaryScreen extends StatelessWidget {
  final AppState state;
  final Function(ScannedSheet) onSelectSheet;

  const BatchSummaryScreen(
      {super.key, required this.state, required this.onSelectSheet});

  Future<void> _exportCsv(BuildContext context) async {
    final scans = state.recentScans;
    if (scans.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('No scans to export')),
      );
      return;
    }

    final buffer = StringBuffer();
    buffer.writeln('Roll Number,Score,Total,Correct,Wrong,Blank,Status');
    for (final scan in scans) {
      buffer.writeln(
          '${scan.rollNumber ?? "Unknown"},${scan.score},${scan.totalQuestions},${scan.correctCount},${scan.wrongCount},${scan.blankCount},${scan.status.name}');
    }

    try {
      final csvBytes =
          Uint8List.fromList(buffer.toString().codeUnits);
      final examTitle = state.selectedExam?.title ?? 'batch';
      final safeTitle = examTitle.replaceAll(RegExp(r'[^a-zA-Z0-9]'), '_');
      final fileName = '${safeTitle}_results.csv';

      final xfile = XFile.fromData(
        csvBytes,
        name: fileName,
        mimeType: 'text/csv',
      );
      await Share.shareXFiles([xfile], subject: '$examTitle — Results');
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Export error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final scans = List<ScannedSheet>.from(state.recentScans)
      ..sort((a, b) => b.score.compareTo(a.score));
    final flaggedCount =
        scans.where((s) => s.status == SheetStatus.flagged).length;
    final examTitle = state.selectedExam?.title ?? 'Batch';

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text(examTitle),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.accentBg,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                '${scans.length} sheets',
                style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: AppColors.accentText),
              ),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (scans.isEmpty)
              Expanded(
                child: Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.format_list_bulleted,
                          size: 48, color: AppColors.textMuted),
                      const SizedBox(height: 12),
                      Text('No scans yet',
                          style: TextStyle(
                              color: AppColors.textMuted, fontSize: 14)),
                      const SizedBox(height: 4),
                      Text('Scan some sheets to see results here',
                          style: TextStyle(
                              color: AppColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
              )
            else ...[
              if (flaggedCount > 0)
                Padding(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 8),
                  child: SizedBox(
                    width: double.infinity,
                    height: 38,
                    child: OutlinedButton.icon(
                      onPressed: () {
                        final firstFlagged = scans.firstWhere(
                            (s) => s.status == SheetStatus.flagged);
                        onSelectSheet(firstFlagged);
                      },
                      icon: const Icon(Icons.warning_amber_rounded,
                          size: 16, color: AppColors.warning),
                      label: Text('Review $flaggedCount flagged',
                          style: const TextStyle(fontSize: 13)),
                    ),
                  ),
                ),

              const Padding(
                padding: EdgeInsets.fromLTRB(16, 12, 16, 6),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text('Sorted by score (highest first)',
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textPrimary)),
                ),
              ),

              Expanded(
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: scans.length,
                  separatorBuilder: (context, index) =>
                      const Divider(height: 1),
                  itemBuilder: (context, index) {
                    final sheet = scans[index];
                    final isClean = sheet.status == SheetStatus.clean;
                    final isFlagged =
                        sheet.status == SheetStatus.flagged;

                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      onTap: () => onSelectSheet(sheet),
                      title: Row(
                        children: [
                          Expanded(
                            child: Text(
                                sheet.rollNumber ?? 'Sheet ${index + 1}',
                                style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600)),
                          ),
                          Text(
                              '${sheet.correctCount}/${sheet.totalQuestions}',
                              style: const TextStyle(
                                  fontSize: 12,
                                  color: AppColors.textMuted)),
                          const SizedBox(width: 12),
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(
                              color: isClean
                                  ? AppColors.successBg
                                  : isFlagged
                                      ? AppColors.warningBg
                                      : AppColors.dangerBg,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Text(
                              isClean
                                  ? 'Clean'
                                  : isFlagged
                                      ? 'Flagged'
                                      : 'Error',
                              style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: isClean
                                    ? AppColors.success
                                    : isFlagged
                                        ? AppColors.warning
                                        : AppColors.danger,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                ),
              ),
            ],

            Padding(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                height: 44,
                child: OutlinedButton.icon(
                  onPressed: () => _exportCsv(context),
                  icon: const Icon(Icons.download_outlined, size: 16),
                  label: const Text('Export all (CSV)'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
