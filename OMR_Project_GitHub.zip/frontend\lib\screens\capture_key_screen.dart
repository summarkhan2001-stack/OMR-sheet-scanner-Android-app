import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/exam.dart';
import '../theme/app_theme.dart';

class CaptureKeyScreen extends StatefulWidget {
  final Exam exam;
  final Function(Map<int, String>) onSaveKey;

  const CaptureKeyScreen({super.key, required this.exam, required this.onSaveKey});

  @override
  State<CaptureKeyScreen> createState() => _CaptureKeyScreenState();
}

class _CaptureKeyScreenState extends State<CaptureKeyScreen> {
  bool _manualMode = false;
  late Map<int, String> _manualKey;
  final ImagePicker _picker = ImagePicker();
  XFile? _capturedImage;

  @override
  void initState() {
    super.initState();
    _manualKey = Map.from(widget.exam.answerKey);
    if (_manualKey.isEmpty) {
      final choices = ['A', 'B', 'C', 'D', 'E'].sublist(0, widget.exam.choicesPerQuestion);
      for (int i = 1; i <= widget.exam.numQuestions; i++) {
        _manualKey[i] = choices[(i - 1) % choices.length];
      }
    }
  }

  Future<void> _captureKeyPhoto(ImageSource source) async {
    try {
      if (!kIsWeb && source == ImageSource.camera) {
        final status = await Permission.camera.request();
        if (status.isPermanentlyDenied) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Camera permission permanently denied. Enable it in App Settings.'),
              action: SnackBarAction(label: 'Settings', onPressed: () => openAppSettings()),
            ),
          );
          return;
        } else if (!status.isGranted) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Camera permission required.')),
          );
          return;
        }
      }

      final XFile? picked = await _picker.pickImage(
        source: source,
        imageQuality: 90,
        maxWidth: 1600,
        maxHeight: 1600,
      );
      if (picked != null) {
        setState(() => _capturedImage = picked);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not access ${source == ImageSource.camera ? "camera" : "gallery"}: $e')),
      );
    }
  }


  void _saveKeyFromPhoto() {
    widget.onSaveKey(_manualKey);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Answer key saved successfully!')),
    );
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text('Answer key'),
      ),
      body: SafeArea(
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: AppColors.accentBg,
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.key, size: 14, color: AppColors.accentText),
                  SizedBox(width: 6),
                  Text(
                    'Set up answer key',
                    style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: AppColors.accentText),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _manualMode ? _buildManualGrid() : _buildCameraCapture(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCameraCapture() {
    return Column(
      children: [
        Expanded(
          child: Container(
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Colors.grey[100],
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: AppColors.border, width: 2),
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(14),
              child: _capturedImage != null
                  ? FutureBuilder<Uint8List>(
                      future: _capturedImage!.readAsBytes(),
                      builder: (ctx, snap) {
                        if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                        return Image.memory(snap.data!, fit: BoxFit.contain);
                      },
                    )
                  : Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.center_focus_weak, color: AppColors.textMuted, size: 48),
                          const SizedBox(height: 12),
                          Text('Take a photo of the answer key sheet',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text('or enter answers manually below',
                              style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                        ],
                      ),
                    ),
            ),
          ),
        ),
        // Camera & Gallery buttons
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: [
              Expanded(
                child: SizedBox(
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: () => _captureKeyPhoto(ImageSource.camera),
                    icon: const Icon(Icons.camera_alt, size: 20),
                    label: const Text('Camera'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: SizedBox(
                  height: 48,
                  child: OutlinedButton.icon(
                    onPressed: () => _captureKeyPhoto(ImageSource.gallery),
                    icon: const Icon(Icons.photo_library_outlined, size: 20),
                    label: const Text('Gallery'),
                  ),
                ),
              ),
            ],
          ),
        ),
        if (_capturedImage != null)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: SizedBox(
              width: double.infinity,
              height: 48,
              child: ElevatedButton(
                onPressed: _saveKeyFromPhoto,
                child: const Text('Save Answer Key'),
              ),
            ),
          ),
        const SizedBox(height: 8),
        TextButton(
          onPressed: () => setState(() => _manualMode = true),
          child: const Text('Enter answers manually', style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold, fontSize: 12)),
        ),
        const SizedBox(height: 12),
      ],
    );
  }

  Widget _buildManualGrid() {
    final choices = ['A', 'B', 'C', 'D', 'E'].sublist(0, widget.exam.choicesPerQuestion);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Tap to set correct option', style: TextStyle(fontSize: 13, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
              TextButton(
                onPressed: () => setState(() => _manualMode = false),
                child: const Text('Use Camera'),
              ),
            ],
          ),
        ),
        Expanded(
          child: ListView.separated(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: widget.exam.numQuestions,
            separatorBuilder: (context, index) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final qNo = index + 1;
              final selectedChoice = _manualKey[qNo];

              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 8),
                child: Row(
                  children: [
                    SizedBox(
                      width: 44,
                      child: Text('Q$qNo', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                    ),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: choices.map((c) {
                          final isSelected = selectedChoice == c;
                          return GestureDetector(
                            onTap: () => setState(() => _manualKey[qNo] = c),
                            child: CircleAvatar(
                              radius: 16,
                              backgroundColor: isSelected ? AppColors.primary : AppColors.surface1,
                              child: Text(
                                c,
                                style: TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: isSelected ? Colors.white : AppColors.textPrimary,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(16),
          child: SizedBox(
            width: double.infinity,
            height: 48,
            child: ElevatedButton(
              onPressed: () {
                widget.onSaveKey(_manualKey);
                Navigator.pop(context);
              },
              child: const Text('Save Answer Key'),
            ),
          ),
        ),
      ],
    );
  }
}
