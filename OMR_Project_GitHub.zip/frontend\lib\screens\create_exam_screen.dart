import 'package:flutter/material.dart';
import '../models/exam.dart';
import '../theme/app_theme.dart';

class CreateExamScreen extends StatefulWidget {
  final Function(Exam)? onSubmit;
  const CreateExamScreen({super.key, this.onSubmit});

  @override
  State<CreateExamScreen> createState() => _CreateExamScreenState();
}

class _CreateExamScreenState extends State<CreateExamScreen> {
  final _titleController = TextEditingController();
  int _numQuestions = 50;
  int _choicesPerQuestion = 4;
  bool _hasRollNumber = true;
  String _selectedTemplate = 'Custom';
  
  double _correctMark = 1.0;
  bool _negativeMarking = false;
  double _wrongMark = -0.25;
  
  final _correctMarkController = TextEditingController(text: '1.0');
  final _wrongMarkController = TextEditingController(text: '-0.25');

  @override
  void initState() {
    super.initState();
    _correctMarkController.addListener(() {
      setState(() {
        _correctMark = double.tryParse(_correctMarkController.text) ?? 1.0;
      });
    });
    _wrongMarkController.addListener(() {
      setState(() {
        _wrongMark = double.tryParse(_wrongMarkController.text) ?? 0.0;
      });
    });
  }
  
  @override
  void dispose() {
    _titleController.dispose();
    _correctMarkController.dispose();
    _wrongMarkController.dispose();
    super.dispose();
  }

  void _applyTemplate(String template) {
    setState(() {
      _selectedTemplate = template;
      switch (template) {
        case 'JEE':
          _numQuestions = 90;
          _choicesPerQuestion = 4;
          _correctMarkController.text = '4.0';
          _wrongMarkController.text = '-1.0';
          _negativeMarking = true;
          break;
        case 'NEET':
          _numQuestions = 180;
          _choicesPerQuestion = 4;
          _correctMarkController.text = '4.0';
          _wrongMarkController.text = '-1.0';
          _negativeMarking = true;
          break;
        case 'MDCAT':
          _numQuestions = 210;
          _choicesPerQuestion = 5;
          _correctMarkController.text = '5.0';
          _wrongMarkController.text = '-1.25';
          _negativeMarking = true;
          break;
        case 'SAT':
          _numQuestions = 60;
          _choicesPerQuestion = 4;
          _correctMarkController.text = '1.0';
          _wrongMarkController.text = '0.0';
          _negativeMarking = false;
          break;
        case 'Custom':
          // Keep current
          break;
      }
    });
  }

  void _submit() {
    if (_titleController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter an exam title')),
      );
      return;
    }

    final exam = Exam(
      id: 'exam_${DateTime.now().millisecondsSinceEpoch}',
      title: _titleController.text,
      numQuestions: _numQuestions,
      choicesPerQuestion: _choicesPerQuestion,
      hasRollNumber: _hasRollNumber,
      markingScheme: MarkingScheme(
        correctMark: _correctMark,
        blankMark: 0.0,
        negativeMarking: _negativeMarking,
        wrongMark: _negativeMarking ? _wrongMark : 0.0,
      ),
      answerKey: {},
    );

    if (widget.onSubmit != null) {
      widget.onSubmit!(exam);
      // Pop this screen so CaptureKeyScreen appears on top cleanly.
      // The main.dart onSubmit callback pushes CaptureKeyScreen after this.
      if (context.mounted) Navigator.pop(context);
    } else {
      // Standalone: pop with exam result
      Navigator.pop(context, exam);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: const Text('Create Exam'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _titleController,
            decoration: const InputDecoration(
              labelText: 'Exam Title',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 24),
          
          const Text('Templates', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['Custom', 'JEE', 'NEET', 'MDCAT', 'SAT'].map((t) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: ChoiceChip(
                    label: Text(t),
                    selected: _selectedTemplate == t,
                    onSelected: (selected) {
                      if (selected) _applyTemplate(t);
                    },
                    selectedColor: AppColors.primary.withValues(alpha: 0.2),
                  ),
                );
              }).toList(),
            ),
          ),
          const SizedBox(height: 24),

          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Number of Questions', style: TextStyle(fontWeight: FontWeight.bold)),
              Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.remove_circle_outline),
                    onPressed: () {
                      if (_numQuestions > 5) setState(() => _numQuestions -= 5);
                    },
                  ),
                  Text('$_numQuestions', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  IconButton(
                    icon: const Icon(Icons.add_circle_outline),
                    onPressed: () {
                      setState(() => _numQuestions += 5);
                    },
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Choices per Question', style: TextStyle(fontWeight: FontWeight.bold)),
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment(value: 4, label: Text('4 (A-D)')),
                  ButtonSegment(value: 5, label: Text('5 (A-E)')),
                ],
                selected: {_choicesPerQuestion},
                onSelectionChanged: (set) {
                  setState(() => _choicesPerQuestion = set.first);
                },
              ),
            ],
          ),
          const SizedBox(height: 16),
          
          SwitchListTile(
            title: const Text('Include Roll Number field', style: TextStyle(fontWeight: FontWeight.bold)),
            value: _hasRollNumber,
            onChanged: (v) => setState(() => _hasRollNumber = v),
            contentPadding: EdgeInsets.zero,
          ),
          const SizedBox(height: 24),
          
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: AppColors.primary.withValues(alpha: 0.2)),
            ),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Marking Scheme', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  const SizedBox(height: 16),
                  
                  Row(
                    children: [
                      const Expanded(child: Text('Marks per correct answer:')),
                      SizedBox(
                        width: 80,
                        child: TextField(
                          controller: _correctMarkController,
                          keyboardType: const TextInputType.numberWithOptions(decimal: true),
                          textAlign: TextAlign.center,
                          decoration: const InputDecoration(
                            isDense: true,
                            border: OutlineInputBorder(),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  SwitchListTile(
                    title: const Text('Negative Marking'),
                    value: _negativeMarking,
                    onChanged: (v) => setState(() => _negativeMarking = v),
                    contentPadding: EdgeInsets.zero,
                  ),
                  
                  if (_negativeMarking) ...[
                    Row(
                      children: [
                        const Expanded(child: Text('Marks per wrong answer:')),
                        SizedBox(
                          width: 80,
                          child: TextField(
                            controller: _wrongMarkController,
                            keyboardType: const TextInputType.numberWithOptions(decimal: true, signed: true),
                            textAlign: TextAlign.center,
                            decoration: const InputDecoration(
                              isDense: true,
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 16),
                  
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('Marks per blank answer:'),
                      Text('0.0', style: TextStyle(fontWeight: FontWeight.bold)),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(height: 32),
          ElevatedButton(
            onPressed: _submit,
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
            ),
            child: const Text('Continue to answer key'),
          ),
        ],
      ),
    );
  }
}
