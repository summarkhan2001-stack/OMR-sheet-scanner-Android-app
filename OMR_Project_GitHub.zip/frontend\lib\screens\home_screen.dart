import 'package:flutter/material.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class HomeScreen extends StatelessWidget {
  final AppState state;
  final Function(int) onTabSelected;
  final VoidCallback onStartSingleScan;
  final VoidCallback onStartBatchScan;
  final VoidCallback onCreateExam;
  final Function(ScannedSheet) onSelectResult;
  final VoidCallback onSetupAnswerKey;

  const HomeScreen({
    super.key,
    required this.state,
    required this.onTabSelected,
    required this.onStartSingleScan,
    required this.onStartBatchScan,
    required this.onCreateExam,
    required this.onSelectResult,
    required this.onSetupAnswerKey,
  });

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inMinutes < 1) return 'Just now';
    if (diff.inMinutes < 60) return '${diff.inMinutes}m ago';
    if (diff.inHours < 24) return '${diff.inHours}h ago';
    return '${diff.inDays}d ago';
  }

  @override
  Widget build(BuildContext context) {
    final selectedExam = state.selectedExam;
    final hasKey = selectedExam?.hasAnswerKey ?? false;

    return Scaffold(
      backgroundColor: AppColors.surface,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Top Bar
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_greeting(), style: const TextStyle(fontSize: 11, color: AppColors.textMuted)),
                      const SizedBox(height: 2),
                      const Text('OMR Scanner', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textPrimary)),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.notifications_none_outlined, color: AppColors.textSecondary),
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('No new notifications')),
                      );
                    },
                  ),
                ],
              ),
            ),

            // Exam Dropdown Selector
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: AppColors.surface,
                  border: Border.all(color: AppColors.borderStrong),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<Exam>(
                    value: selectedExam,
                    isExpanded: true,
                    hint: const Text('No exams — create one', style: TextStyle(fontSize: 14, color: AppColors.textMuted)),
                    icon: const Icon(Icons.keyboard_arrow_down, color: AppColors.textSecondary),
                    items: state.exams.map((exam) {
                      return DropdownMenuItem<Exam>(
                        value: exam,
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                '${exam.title} (${exam.numQuestions} Q)',
                                style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                              ),
                            ),
                            if (!exam.hasAnswerKey)
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  color: AppColors.warningBg,
                                  borderRadius: BorderRadius.circular(4),
                                ),
                                child: const Text('No key', style: TextStyle(fontSize: 10, color: AppColors.warning, fontWeight: FontWeight.bold)),
                              ),
                          ],
                        ),
                      );
                    }).toList(),
                    onChanged: (exam) => state.selectExam(exam),
                  ),
                ),
              ),
            ),

            // Action Buttons Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Column(
                children: [
                  if (!hasKey && selectedExam != null) ...[
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.only(bottom: 12),
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.warningBg,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AppColors.warning.withValues(alpha: 0.3)),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.warning_amber_rounded, color: AppColors.warning, size: 20),
                          const SizedBox(width: 10),
                          const Expanded(
                            child: Text(
                              'Answer key required before scanning.',
                              style: TextStyle(fontSize: 12, color: AppColors.warning, fontWeight: FontWeight.w600),
                            ),
                          ),
                          InkWell(
                            onTap: onSetupAnswerKey,
                            child: const Text(
                              'Set up',
                              style: TextStyle(fontSize: 12, color: AppColors.primary, fontWeight: FontWeight.bold, decoration: TextDecoration.underline),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],

                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: onStartSingleScan,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.primary,
                        foregroundColor: Colors.white,
                      ),
                      icon: const Icon(Icons.camera_alt_outlined, size: 22),
                      label: const Text(
                        'Scan Sheet',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),

                  const SizedBox(height: 10),

                  Row(
                    children: [
                      Expanded(
                        child: SizedBox(
                          height: 46,
                          child: OutlinedButton.icon(
                            onPressed: onStartBatchScan,
                            icon: const Icon(Icons.layers_outlined, size: 20),
                            label: const Text('Batch scan', style: TextStyle(fontWeight: FontWeight.bold)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      SizedBox(
                        height: 46,
                        child: OutlinedButton.icon(
                          onPressed: onCreateExam,
                          icon: const Icon(Icons.add, size: 20),
                          label: const Text('New Exam', style: TextStyle(fontWeight: FontWeight.bold)),
                        ),
                      ),
                    ],
                  ),

                ],
              ),
            ),

            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Text(
                'Recent scans',
                style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.textPrimary),
              ),
            ),

            // Recent Scans List
            Expanded(
              child: state.recentScans.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.document_scanner_outlined, size: 40, color: AppColors.textMuted),
                          const SizedBox(height: 8),
                          Text('No scans yet', style: TextStyle(color: AppColors.textMuted, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text('Scan a sheet to see results here', style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                        ],
                      ),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: state.recentScans.length,
                      separatorBuilder: (context, index) => const Divider(height: 1, color: AppColors.border),
                      itemBuilder: (context, index) {
                        final scan = state.recentScans[index];
                        final isClean = scan.status == SheetStatus.clean;
                        final isFlagged = scan.status == SheetStatus.flagged;

                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          onTap: () => onSelectResult(scan),
                          leading: Container(
                            width: 36,
                            height: 36,
                            decoration: BoxDecoration(
                              color: isClean
                                  ? AppColors.successBg
                                  : isFlagged
                                      ? AppColors.warningBg
                                      : AppColors.dangerBg,
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              isClean ? Icons.check : isFlagged ? Icons.warning_amber_rounded : Icons.close,
                              color: isClean ? AppColors.success : isFlagged ? AppColors.warning : AppColors.danger,
                              size: 18,
                            ),
                          ),
                          title: Text(
                            scan.rollNumber ?? 'Sheet ${index + 1}',
                            style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                          ),
                          subtitle: Text(
                            isFlagged ? '${scan.flags.length} flags' : _timeAgo(scan.createdAt),
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                          trailing: Text(
                            '${scan.correctCount}/${scan.totalQuestions}',
                            style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
