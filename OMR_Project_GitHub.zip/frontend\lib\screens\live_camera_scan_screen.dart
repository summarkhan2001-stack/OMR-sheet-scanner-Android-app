import 'dart:math';
import 'package:camera/camera.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import 'result_screen.dart';

/// Live Camera OMR Sheet Scanner
/// Supports both CameraX real-time viewfinder and native camera fallback.
class LiveCameraScanScreen extends StatefulWidget {
  final Exam exam;
  final String sessionId;
  final AppState appState;
  final bool isBatch;

  const LiveCameraScanScreen({
    super.key,
    required this.exam,
    required this.sessionId,
    required this.appState,
    this.isBatch = false,
  });

  @override
  State<LiveCameraScanScreen> createState() => _LiveCameraScanScreenState();
}

class _LiveCameraScanScreenState extends State<LiveCameraScanScreen> with WidgetsBindingObserver {
  CameraController? _controller;
  List<CameraDescription> _cameras = [];
  int _selectedCameraIndex = 0;
  bool _isCameraInitialized = false;
  bool _isProcessing = false;
  FlashMode _flashMode = FlashMode.off;
  String _statusMessage = '';

  // Batch stats
  int _batchCount = 0;
  final List<ScannedSheet> _batchScans = [];

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _initializeCamera();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller?.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (_controller == null || !_controller!.value.isInitialized) return;
    if (state == AppLifecycleState.inactive) {
      _controller?.dispose();
    } else if (state == AppLifecycleState.resumed) {
      _initializeCamera();
    }
  }

  Future<void> _initializeCamera() async {
    try {
      if (!kIsWeb) {
        final status = await Permission.camera.request();
        if (!status.isGranted) {
          if (mounted) setState(() => _isCameraInitialized = false);
          return;
        }
      }

      _cameras = await availableCameras();
      if (_cameras.isEmpty) {
        if (mounted) setState(() => _isCameraInitialized = false);
        return;
      }

      // Default to back camera
      _selectedCameraIndex = _cameras.indexWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
      );
      if (_selectedCameraIndex == -1) _selectedCameraIndex = 0;

      await _startCameraController(_cameras[_selectedCameraIndex]);
    } catch (e) {
      debugPrint('Live camera initialization error: $e');
      if (mounted) setState(() => _isCameraInitialized = false);
    }
  }

  Future<void> _startCameraController(CameraDescription cameraDescription) async {
    final prevController = _controller;
    final controller = CameraController(
      cameraDescription,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );

    await prevController?.dispose();

    try {
      await controller.initialize();
      await controller.setFlashMode(_flashMode);
      if (mounted) {
        setState(() {
          _controller = controller;
          _isCameraInitialized = true;
        });
      }
    } catch (e) {
      debugPrint('Camera controller start error: $e');
      if (mounted) setState(() => _isCameraInitialized = false);
    }
  }

  Future<void> _toggleFlash() async {
    if (_controller == null || !_controller!.value.isInitialized) return;
    try {
      final nextMode = _flashMode == FlashMode.off ? FlashMode.torch : FlashMode.off;
      await _controller!.setFlashMode(nextMode);
      if (mounted) setState(() => _flashMode = nextMode);
    } catch (e) {
      debugPrint('Flash toggle error: $e');
    }
  }

  Future<void> _switchCamera() async {
    if (_cameras.length < 2) return;
    _selectedCameraIndex = (_selectedCameraIndex + 1) % _cameras.length;
    await _startCameraController(_cameras[_selectedCameraIndex]);
  }

  /// Capture frame from live camera or launch native camera if preview is inactive
  Future<void> _captureAndGrade() async {
    if (_isProcessing) return;

    if (_controller != null && _controller!.value.isInitialized) {
      try {
        setState(() {
          _isProcessing = true;
          _statusMessage = 'Capturing frame...';
        });
        final capturedFile = await _controller!.takePicture();
        await _processImageFile(capturedFile);
        return;
      } catch (e) {
        debugPrint('Error taking picture with live controller: $e');
      }
    }

    // Fallback: Launch native phone camera app
    await _pickFromNativeCamera();
  }

  /// Launch native camera via ImagePicker (100% compatible on all Android devices)
  Future<void> _pickFromNativeCamera() async {
    try {
      setState(() {
        _isProcessing = true;
        _statusMessage = 'Opening camera...';
      });

      final XFile? picked = await _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 92,
        maxWidth: 1800,
        maxHeight: 1800,
      );

      if (picked != null) {
        await _processImageFile(picked);
      } else {
        if (mounted) setState(() => _isProcessing = false);
      }
    } catch (e) {
      if (mounted) setState(() => _isProcessing = false);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Camera error: $e')),
      );
    }
  }

  /// Pick an existing sheet from gallery
  Future<void> _pickFromGallery() async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 92,
        maxWidth: 1800,
        maxHeight: 1800,
      );
      if (picked != null) {
        setState(() {
          _isProcessing = true;
          _statusMessage = 'Reading image from gallery...';
        });
        await _processImageFile(picked);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not open gallery: $e')),
      );
    }
  }

  /// Core image processing execution
  Future<void> _processImageFile(XFile file) async {
    try {
      setState(() => _statusMessage = 'Connecting to OMR Backend...');
      final backendOnline = await ApiService.checkHealth();

      if (!backendOnline) {
        if (!mounted) return;
        setState(() => _isProcessing = false);
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.wifi_off_rounded, color: AppColors.danger),
                SizedBox(width: 8),
                Text('Backend Offline'),
              ],
            ),
            content: Text(
              'Could not connect to the backend server at:\n${ApiService.baseUrl}\n\nPlease check your server or ngrok tunnel.',
              style: const TextStyle(fontSize: 13),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        return;
      }

      setState(() => _statusMessage = 'Analyzing & grading sheet on backend...');
      final ScannedSheet? result = await ApiService.gradeSheet(
        imageFile: file,
        exam: widget.exam,
        sessionId: widget.sessionId,
      );

      if (result == null) {
        if (!mounted) return;
        setState(() => _isProcessing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not grade sheet. Ensure bubbles and corners are clearly visible.'),
            backgroundColor: AppColors.danger,
            duration: Duration(seconds: 4),
          ),
        );
        return;
      }

      if (!mounted) return;

      widget.appState.addScanResult(result);

      if (widget.isBatch) {
        // In Batch mode: update counter, show brief HUD, and stay ready for next sheet
        setState(() {
          _batchCount++;
          _batchScans.insert(0, result);
          _isProcessing = false;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(
              children: [
                const Icon(Icons.check_circle, color: Colors.white, size: 20),
                const SizedBox(width: 8),
                Text('Sheet #$_batchCount: Score ${result.score.toStringAsFixed(1)}/${result.totalQuestions}'),
              ],
            ),
            backgroundColor: AppColors.success,
            duration: const Duration(seconds: 2),
          ),
        );
      } else {
        // In Single mode: navigate directly to ResultScreen
        setState(() => _isProcessing = false);
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(
            builder: (_) => ResultScreen(sheet: result, exam: widget.exam),
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => _isProcessing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Processing error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // ── 1. Live Camera Preview or Native Camera Prompt ───────────────
          if (_isCameraInitialized && _controller != null)
            Center(
              child: CameraPreview(_controller!),
            )
          else
            _buildCameraFallback(),

          // ── 2. OMR Viewfinder Alignment Overlay ─────────────────────────
          if (_isCameraInitialized) _buildViewfinderOverlay(),

          // ── 3. Top Header Bar ───────────────────────────────────────────
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.black87, Colors.transparent],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Row(
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white, size: 28),
                      onPressed: () => Navigator.pop(context),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Text(
                            widget.exam.title,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            widget.isBatch
                                ? 'Batch mode · $_batchCount scanned'
                                : 'Align sheet inside the frame',
                            style: const TextStyle(color: Colors.white70, fontSize: 12),
                          ),
                        ],
                      ),
                    ),
                    if (_isCameraInitialized) ...[
                      IconButton(
                        icon: Icon(
                          _flashMode == FlashMode.torch ? Icons.flash_on : Icons.flash_off,
                          color: _flashMode == FlashMode.torch ? Colors.amber : Colors.white,
                          size: 26,
                        ),
                        onPressed: _toggleFlash,
                      ),
                      if (_cameras.length > 1)
                        IconButton(
                          icon: const Icon(Icons.flip_camera_ios, color: Colors.white, size: 26),
                          onPressed: _switchCamera,
                        ),
                    ],
                  ],
                ),
              ),
            ),
          ),

          // ── 4. Bottom Controls Bar ──────────────────────────────────────
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: SafeArea(
              child: Container(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 20),
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Colors.black87, Colors.black],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    // Gallery button
                    IconButton(
                      icon: const Icon(Icons.photo_library_outlined, color: Colors.white, size: 30),
                      onPressed: _isProcessing ? null : _pickFromGallery,
                    ),

                    // Big Shutter Button
                    GestureDetector(
                      onTap: _isProcessing ? null : _captureAndGrade,
                      child: Container(
                        width: 76,
                        height: 76,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 4),
                          color: Colors.transparent,
                        ),
                        padding: const EdgeInsets.all(4),
                        child: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: _isProcessing ? AppColors.border : AppColors.primary,
                          ),
                          child: Icon(
                            _isProcessing ? Icons.hourglass_top : Icons.camera_alt,
                            color: Colors.white,
                            size: 32,
                          ),
                        ),
                      ),
                    ),

                    // Finish / Switch mode button
                    if (widget.isBatch)
                      TextButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Finish', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                      )
                    else
                      IconButton(
                        icon: const Icon(Icons.camera_enhance_outlined, color: Colors.white, size: 28),
                        onPressed: _isProcessing ? null : _pickFromNativeCamera,
                      ),
                  ],
                ),
              ),
            ),
          ),

          // ── 5. Processing HUD ───────────────────────────────────────────
          if (_isProcessing)
            Container(
              color: Colors.black54,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(color: AppColors.primary),
                      const SizedBox(height: 16),
                      Text(
                        _statusMessage,
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      const SizedBox(height: 6),
                      const Text(
                        'Grading sheet on mobile...',
                        style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  /// Camera fallback screen with large primary capture buttons
  Widget _buildCameraFallback() {
    return Container(
      color: Colors.grey[900],
      child: Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.camera_alt_outlined, color: Colors.white70, size: 64),
              const SizedBox(height: 16),
              const Text(
                'Scan OMR Sheet',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              const Text(
                'Take a photo of your OMR sheet to grade it instantly with the built-in engine.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white70, fontSize: 13),
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton.icon(
                  onPressed: _pickFromNativeCamera,
                  icon: const Icon(Icons.camera_alt, size: 22),
                  label: const Text('Open Camera', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: _pickFromGallery,
                  icon: const Icon(Icons.photo_library, color: Colors.white),
                  label: const Text('Choose from Gallery', style: TextStyle(color: Colors.white, fontSize: 14)),
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: Colors.white54),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                ),
              ),
              const SizedBox(height: 16),
              TextButton.icon(
                onPressed: _initializeCamera,
                icon: const Icon(Icons.refresh, color: Colors.white60, size: 18),
                label: const Text('Try Live Viewfinder Mode', style: TextStyle(color: Colors.white60, fontSize: 13)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// OMR Viewfinder alignment frame (Evalbee style)
  Widget _buildViewfinderOverlay() {
    return IgnorePointer(
      child: LayoutBuilder(
        builder: (context, constraints) {
          final double frameWidth = constraints.maxWidth * 0.85;
          final double frameHeight = min(constraints.maxHeight * 0.65, frameWidth * 1.35);

          return Center(
            child: SizedBox(
              width: frameWidth,
              height: frameHeight,
              child: Stack(
                children: [
                  // Outer border with subtle glow
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.white.withValues(alpha: 0.6), width: 1.5),
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),

                  // 4 Corner Brackets (Evalbee style)
                  Positioned(top: 0, left: 0, child: _cornerBracket(isTop: true, isLeft: true)),
                  Positioned(top: 0, right: 0, child: _cornerBracket(isTop: true, isLeft: false)),
                  Positioned(bottom: 0, left: 0, child: _cornerBracket(isTop: false, isLeft: true)),
                  Positioned(bottom: 0, right: 0, child: _cornerBracket(isTop: false, isLeft: false)),

                  // Center alignment hint
                  Align(
                    alignment: Alignment.center,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withValues(alpha: 0.45),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: const Text(
                        'Align OMR Sheet Here',
                        style: TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _cornerBracket({required bool isTop, required bool isLeft}) {
    const double length = 28;
    const double thickness = 4;
    const Color color = AppColors.primary;

    return SizedBox(
      width: length,
      height: length,
      child: CustomPaint(
        painter: _CornerPainter(
          isTop: isTop,
          isLeft: isLeft,
          color: color,
          length: length,
          thickness: thickness,
        ),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final bool isTop;
  final bool isLeft;
  final Color color;
  final double length;
  final double thickness;

  _CornerPainter({
    required this.isTop,
    required this.isLeft,
    required this.color,
    required this.length,
    required this.thickness,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = thickness
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;

    final path = Path();
    if (isTop && isLeft) {
      path.moveTo(0, length);
      path.lineTo(0, 0);
      path.lineTo(length, 0);
    } else if (isTop && !isLeft) {
      path.moveTo(size.width - length, 0);
      path.lineTo(size.width, 0);
      path.lineTo(size.width, length);
    } else if (!isTop && isLeft) {
      path.moveTo(0, size.height - length);
      path.lineTo(0, size.height);
      path.lineTo(length, size.height);
    } else {
      path.moveTo(size.width - length, size.height);
      path.lineTo(size.width, size.height);
      path.lineTo(size.width, size.height - length);
    }

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
