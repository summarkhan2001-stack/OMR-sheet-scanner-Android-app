import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';
import '../theme/app_theme.dart';

class ResultScreen extends StatefulWidget {
  final ScannedSheet sheet;
  final Exam exam;

  const ResultScreen({super.key, required this.sheet, required this.exam});

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late ScannedSheet _sheet;

  @override
  void initState() {
    super.initState();
    _sheet = widget.sheet;
  }

  Color _scoreColor(double pct) {
    if (pct >= 60) return AppColors.success;
    if (pct >= 40) return AppColors.warning;
    return AppColors.danger;
  }

  @override
  Widget build(BuildContext context) {
    final sheet = _sheet;
    final exam = widget.exam;
    final maxScore = exam.maxPossibleScore;
    final pct = maxScore > 0 ? (sheet.score / maxScore) * 100 : 0.0;

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        title: Text(sheet.rollNumber ?? 'Result'),
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: _showExportSheet,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _buildScoreCard(sheet, exam, pct),
          const SizedBox(height: 16),
          if (sheet.annotatedImageBase64 != null && sheet.annotatedImageBase64!.isNotEmpty) ...[
            _buildCamScannerPreviewCard(sheet),
            const SizedBox(height: 16),
          ],
          if (sheet.flags.isNotEmpty) _buildFlagsCard(sheet),
          const SizedBox(height: 16),
          _buildAnswerBreakdown(sheet, exam),
        ],
      ),
    );
  }

  Widget _buildCamScannerPreviewCard(ScannedSheet sheet) {
    final imageBytes = base64Decode(sheet.annotatedImageBase64!);

    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.document_scanner, color: AppColors.primary, size: 20),
                const SizedBox(width: 8),
                const Expanded(
                  child: Text(
                    'CamScanner Clean View & Highlights',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                  ),
                ),
                TextButton.icon(
                  icon: const Icon(Icons.fullscreen, size: 18),
                  label: const Text('Zoom'),
                  onPressed: () => _showFullScreenImage(imageBytes),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text(
              'Paper whitened & bubbles highlighted (🟢 Correct, 🔴 Wrong, 🟡 Expected)',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 12),
            GestureDetector(
              onTap: () => _showFullScreenImage(imageBytes),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Container(
                  constraints: const BoxConstraints(maxHeight: 280),
                  width: double.infinity,
                  color: Colors.black12,
                  child: Stack(
                    alignment: Alignment.center,
                    children: [
                      Image.memory(
                        imageBytes,
                        fit: BoxFit.contain,
                        width: double.infinity,
                      ),
                      Positioned(
                        bottom: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.black.withValues(alpha: 0.65),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: const Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.zoom_in, color: Colors.white, size: 14),
                              SizedBox(width: 4),
                              Text('Tap to inspect', style: TextStyle(color: Colors.white, fontSize: 11)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showFullScreenImage(Uint8List imageBytes) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: Colors.black,
        insetPadding: EdgeInsets.zero,
        child: Stack(
          children: [
            InteractiveViewer(
              minScale: 0.8,
              maxScale: 4.5,
              child: Center(
                child: Image.memory(
                  imageBytes,
                  fit: BoxFit.contain,
                ),
              ),
            ),
            Positioned(
              top: 40,
              right: 16,
              child: IconButton(
                icon: const Icon(Icons.close, color: Colors.white, size: 28),
                onPressed: () => Navigator.pop(context),
              ),
            ),
            Positioned(
              bottom: 20,
              left: 20,
              right: 20,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withValues(alpha: 0.75),
                  borderRadius: BorderRadius.circular(24),
                ),
                child: const Text(
                  '🟢 Correct  •  🔴 Wrong  •  🟡 Expected (Blank)\nPinch to zoom in/out',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: Colors.white, fontSize: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildScoreCard(ScannedSheet sheet, Exam exam, double pct) {
    final color = _scoreColor(pct);
    final maxScore = exam.maxPossibleScore;
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: color.withValues(alpha: 0.08),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            Text(
              sheet.rollNumber ?? 'Unknown Roll No.',
              style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 8),
            Text(
              sheet.score.toStringAsFixed(1),
              style: TextStyle(fontSize: 56, fontWeight: FontWeight.bold, color: color),
            ),
            Text(
              '/ ${maxScore.toStringAsFixed(0)}  •  ${pct.toStringAsFixed(1)}%',
              style: const TextStyle(fontSize: 14, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _pill('${sheet.correctCount} correct', AppColors.success),
                _pill('${sheet.wrongCount} wrong', AppColors.danger),
                _pill('${sheet.blankCount} blank', AppColors.textSecondary),
              ],
            ),
            if (exam.markingScheme.negativeMarking) ...[
              const SizedBox(height: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.warning.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  'Negative marking: ${exam.markingScheme.wrongMark} per wrong',
                  style: const TextStyle(fontSize: 11, color: AppColors.warning),
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _pill(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
    );
  }

  Widget _buildFlagsCard(ScannedSheet sheet) {
    return Card(
      color: AppColors.warning.withValues(alpha: 0.08),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.flag_rounded, color: AppColors.warning, size: 18),
                const SizedBox(width: 6),
                Text('${sheet.flags.length} flag${sheet.flags.length > 1 ? "s" : ""} need review',
                  style: const TextStyle(fontWeight: FontWeight.w600, color: AppColors.warning)),
              ],
            ),
            const SizedBox(height: 8),
            ...sheet.flags.map((f) => Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(
                children: [
                  const SizedBox(width: 4),
                  const Icon(Icons.circle, size: 6, color: AppColors.warning),
                  const SizedBox(width: 8),
                  Text('Q${f.questionNo}: ${f.description}',
                    style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            )),
          ],
        ),
      ),
    );
  }

  Widget _buildAnswerBreakdown(ScannedSheet sheet, Exam exam) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Answer Breakdown', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 12),
            ...List.generate(exam.numQuestions, (idx) {
              final qNo = idx + 1;
              final ans = sheet.detectedAnswers[qNo];
              final correct = exam.answerKey[qNo];
              final isCorrect = ans?.isCorrect ?? false;
              final isBlank = ans?.markedChoice == null;
              final hasFlag = sheet.flags.any((f) => f.questionNo == qNo);

              return Container(
                margin: const EdgeInsets.only(bottom: 4),
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: hasFlag
                    ? AppColors.warning.withValues(alpha: 0.06)
                    : isCorrect
                      ? AppColors.success.withValues(alpha: 0.04)
                      : AppColors.danger.withValues(alpha: 0.04),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    SizedBox(width: 28, child: Text('Q$qNo', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary))),
                    const SizedBox(width: 8),
                    Container(
                      width: 28, height: 28,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isBlank
                          ? AppColors.textSecondary.withValues(alpha: 0.15)
                          : isCorrect
                            ? AppColors.success.withValues(alpha: 0.15)
                            : AppColors.danger.withValues(alpha: 0.15),
                      ),
                      alignment: Alignment.center,
                      child: Text(
                        ans?.markedChoice ?? '-',
                        style: TextStyle(
                          fontSize: 12, fontWeight: FontWeight.bold,
                          color: isBlank ? AppColors.textSecondary : isCorrect ? AppColors.success : AppColors.danger,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        isBlank ? 'Blank' : isCorrect ? 'Correct' : 'Wrong (key: ${correct ?? "?"})',
                        style: TextStyle(
                          fontSize: 12,
                          color: isBlank ? AppColors.textSecondary : isCorrect ? AppColors.success : AppColors.danger,
                        ),
                      ),
                    ),
                    if (hasFlag) const Icon(Icons.flag, size: 14, color: AppColors.warning),
                    if (ans != null && ans.confidence < 0.5 && !isBlank)
                      Padding(
                        padding: const EdgeInsets.only(left: 4),
                        child: Text('${(ans.confidence * 100).round()}%',
                          style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                      ),
                  ],
                ),
              );
            }),
          ],
        ),
      ),
    );
  }

  void _showExportSheet() {
    final sheet = _sheet;
    final exam = widget.exam;
    final maxScore = exam.maxPossibleScore;
    final pct = maxScore > 0 ? (sheet.score / maxScore) * 100 : 0.0;

    final text = '''
OMR Scan Result
═══════════════
Roll No: ${sheet.rollNumber ?? 'N/A'}
Exam: ${exam.title}
Score: ${sheet.score.toStringAsFixed(1)} / ${maxScore.toStringAsFixed(0)}
Percentage: ${pct.toStringAsFixed(1)}%
Correct: ${sheet.correctCount}
Wrong: ${sheet.wrongCount}
Blank: ${sheet.blankCount}
${exam.markingScheme.negativeMarking ? 'Negative marking: ${exam.markingScheme.wrongMark} per wrong' : ''}
''';

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Export Results', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            const SizedBox(height: 16),
            ListTile(
              leading: const Icon(Icons.share),
              title: const Text('Share'),
              onTap: () {
                Navigator.pop(context);
                Share.share(text, subject: 'OMR Result — ${sheet.rollNumber ?? exam.title}');
              },
            ),
            ListTile(
              leading: const Icon(Icons.copy),
              title: const Text('Copy to clipboard'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: text));
                Navigator.pop(context);
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Results copied to clipboard!')),
                );
              },
            ),
            ListTile(
              leading: const Icon(Icons.text_snippet),
              title: const Text('View as text'),
              onTap: () {
                Navigator.pop(context);
                showDialog(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('Result Summary'),
                    content: SingleChildScrollView(child: Text(text, style: const TextStyle(fontFamily: 'monospace'))),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
