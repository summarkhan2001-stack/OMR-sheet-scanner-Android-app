import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';
import 'result_screen.dart';

class ScanSingleScreen extends StatefulWidget {
  final Exam exam;
  final String sessionId;
  final AppState appState;

  const ScanSingleScreen({
    super.key,
    required this.exam,
    required this.sessionId,
    required this.appState,
  });

  @override
  State<ScanSingleScreen> createState() => _ScanSingleScreenState();
}

class _ScanSingleScreenState extends State<ScanSingleScreen> {
  final ImagePicker _picker = ImagePicker();
  XFile? _selectedImage;
  bool _isProcessing = false;
  String _statusText = 'Analyzing sheet with OMR backend...';

  Future<void> _pickImage(ImageSource source) async {
    try {
      if (!kIsWeb && source == ImageSource.camera) {
        final status = await Permission.camera.request();
        if (status.isPermanentlyDenied) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: const Text('Camera permission permanently denied. Tap Settings to enable it.'),
              action: SnackBarAction(label: 'Settings', onPressed: () => openAppSettings()),
            ),
          );
          return;
        } else if (!status.isGranted) {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Camera permission is required to capture OMR sheets.')),
          );
          return;
        }
      }

      final XFile? picked = await _picker.pickImage(
        source: source,
        imageQuality: 92,
        maxWidth: 1800,
        maxHeight: 1800,
      );

      if (picked != null) {
        setState(() => _selectedImage = picked);
      }
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not access ${source == ImageSource.camera ? "camera" : "gallery"}: $e')),
      );
    }
  }

  Future<void> _gradeSheet() async {
    if (_selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please capture or select an OMR sheet first')),
      );
      return;
    }

    setState(() {
      _isProcessing = true;
      _statusText = 'Connecting to OMR backend...';
    });

    try {
      final backendOnline = await ApiService.checkHealth();
      if (!backendOnline) {
        if (!mounted) return;
        setState(() => _isProcessing = false);
        showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Row(
              children: [
                Icon(Icons.wifi_off_rounded, color: AppColors.danger),
                SizedBox(width: 8),
                Text('Backend Offline'),
              ],
            ),
            content: Text(
              'Could not connect to the backend server at:\n${ApiService.baseUrl}\n\nPlease ensure your server and ngrok tunnel are running.',
              style: const TextStyle(fontSize: 13),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: const Text('OK'),
              ),
            ],
          ),
        );
        return;
      }

      setState(() => _statusText = 'Grading sheet with OpenCV ensemble engine...');
      final ScannedSheet? result = await ApiService.gradeSheet(
        imageFile: _selectedImage!,
        exam: widget.exam,
        sessionId: widget.sessionId,
      );

      if (result == null) {
        if (!mounted) return;
        setState(() => _isProcessing = false);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Could not detect bubble grid. Ensure the OMR sheet is well-lit and not blurry.'),
            backgroundColor: AppColors.danger,
            duration: Duration(seconds: 4),
          ),
        );
        return;
      }

      if (!mounted) return;

      widget.appState.addScanResult(result);
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(sheet: result, exam: widget.exam),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Processing error: $e'),
          action: SnackBarAction(label: 'Retry', onPressed: _gradeSheet),
        ),
      );
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _useDemoMode() {
    final demoSheet = widget.appState.generateSimulatedScan(widget.exam);
    widget.appState.addScanResult(demoSheet);
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(
        builder: (_) => ResultScreen(sheet: demoSheet, exam: widget.exam),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(title: const Text('Scan OMR Sheet')),
      body: Stack(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                // Image preview area
                Expanded(
                  child: Container(
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.grey[100],
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: AppColors.border, width: 2),
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(14),
                      child: _selectedImage != null
                          ? _buildImagePreview()
                          : Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.document_scanner_outlined,
                                      color: AppColors.textMuted, size: 64),
                                  const SizedBox(height: 12),
                                  const Text('Capture or select an OMR sheet',
                                      style: TextStyle(
                                          color: AppColors.textMuted, fontSize: 14)),
                                  const SizedBox(height: 8),
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                    decoration: BoxDecoration(
                                      color: AppColors.accentBg,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Text('⚡ OpenCV Backend Engine v6.0',
                                        style: TextStyle(
                                            color: AppColors.accentText, fontSize: 11, fontWeight: FontWeight.bold)),
                                  ),
                                ],
                              ),
                            ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),

                // Camera & Gallery buttons
                Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: _isProcessing
                              ? null
                              : () => _pickImage(ImageSource.camera),
                          icon: const Icon(Icons.camera_alt, size: 22),
                          label: const Text('Camera', style: TextStyle(fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: SizedBox(
                        height: 50,
                        child: ElevatedButton.icon(
                          onPressed: _isProcessing
                              ? null
                              : () => _pickImage(ImageSource.gallery),
                          icon: const Icon(Icons.photo_library_outlined, size: 22),
                          label: const Text('Gallery', style: TextStyle(fontWeight: FontWeight.bold)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),

                // Grade button
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton.icon(
                    onPressed: (_isProcessing || _selectedImage == null)
                        ? null
                        : _gradeSheet,
                    icon: const Icon(Icons.grading, size: 22),
                    label: const Text('Grade Sheet on Backend',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: _selectedImage != null
                          ? AppColors.primary
                          : AppColors.border,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                TextButton(
                  onPressed: _isProcessing ? null : _useDemoMode,
                  child: const Text('Use Demo Simulation (test results)',
                      style: TextStyle(color: AppColors.textMuted)),
                ),
              ],
            ),
          ),
          // Processing overlay
          if (_isProcessing)
            Container(
              color: Colors.black54,
              child: Center(
                child: Container(
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(color: AppColors.primary),
                      const SizedBox(height: 16),
                      Text(_statusText,
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                      const SizedBox(height: 6),
                      const Text('Scanning bubbles & calculating score...',
                          style: TextStyle(color: AppColors.textMuted, fontSize: 12)),
                    ],
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildImagePreview() {
    return FutureBuilder<Uint8List>(
      future: _selectedImage!.readAsBytes(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }
        return Image.memory(snapshot.data!, fit: BoxFit.contain);
      },
    );
  }
}
