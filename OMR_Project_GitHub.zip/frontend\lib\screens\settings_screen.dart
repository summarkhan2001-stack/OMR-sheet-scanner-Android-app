import 'package:flutter/material.dart';
import '../services/api_service.dart';
import '../services/app_state.dart';
import '../theme/app_theme.dart';

class SettingsScreen extends StatefulWidget {
  final AppState state;

  const SettingsScreen({super.key, required this.state});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TextEditingController _urlController = TextEditingController();
  bool _isTesting = false;
  String? _testStatus;
  bool _isOnline = false;

  @override
  void initState() {
    super.initState();
    _urlController.text = ApiService.baseUrl;
    _checkInitialStatus();
  }

  Future<void> _checkInitialStatus() async {
    final online = await ApiService.checkHealth();
    if (mounted) {
      setState(() {
        _isOnline = online;
      });
    }
  }

  Future<void> _testAndSaveServer() async {
    final newUrl = _urlController.text.trim();
    if (newUrl.isEmpty) return;

    setState(() {
      _isTesting = true;
      _testStatus = 'Testing connection...';
    });

    await ApiService.saveBaseUrl(newUrl);
    final online = await ApiService.checkHealth();

    if (mounted) {
      setState(() {
        _isTesting = false;
        _isOnline = online;
        _testStatus = online
            ? '✅ Connected to OpenCV Backend!'
            : '❌ Cannot connect. Make sure server is running.';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(online ? 'Server URL saved & connected!' : 'Connection failed!'),
          backgroundColor: online ? AppColors.success : AppColors.danger,
          duration: const Duration(seconds: 2),
        ),
      );
    }
  }

  void _manageExams() {
    showDialog(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            title: const Text('Saved Exams'),
            content: SizedBox(
              width: double.maxFinite,
              child: widget.state.exams.isEmpty
                  ? const Text('No exams saved')
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: widget.state.exams.length,
                      itemBuilder: (context, index) {
                        final exam = widget.state.exams[index];
                        return ListTile(
                          title: Text(exam.title,
                              style: const TextStyle(fontSize: 14)),
                          subtitle: Text(
                              '${exam.numQuestions} Qs · ${exam.choicesPerQuestion} choices',
                              style: const TextStyle(fontSize: 12)),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete_outline,
                                color: AppColors.danger),
                            onPressed: () {
                              widget.state.deleteExam(exam.id);
                              setDialogState(() {});
                              setState(() {});
                            },
                          ),
                        );
                      },
                    ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Close')),
            ],
          );
        },
      ),
    );
  }

  void _clearAllScans() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Clear All Scans?'),
        content: const Text(
            'This will remove all scanned results from the local database. This action cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.danger,
                foregroundColor: Colors.white),
            onPressed: () {
              widget.state.clearAllScans();
              Navigator.pop(context);
              setState(() {});
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('All scans cleared')),
              );
            },
            child: const Text('Clear All'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(title: const Text('Settings')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          children: [
            const _SectionTitle(title: 'OpenCV Backend Server'),

            // Server Status Card
            Container(
              margin: const EdgeInsets.only(bottom: 12),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _isOnline ? AppColors.successBg : AppColors.surface1,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _isOnline
                      ? AppColors.success.withValues(alpha: 0.4)
                      : AppColors.border,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        _isOnline ? Icons.cloud_done : Icons.cloud_off,
                        color: _isOnline ? AppColors.success : AppColors.textMuted,
                        size: 24,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _isOnline ? 'OpenCV Backend Online' : 'Backend Disconnected',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: _isOnline ? AppColors.success : AppColors.textPrimary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  TextField(
                    controller: _urlController,
                    decoration: InputDecoration(
                      labelText: 'Server URL (ngrok / Cloud / IP)',
                      labelStyle: const TextStyle(fontSize: 12),
                      hintText: 'https://xxxx.ngrok-free.app',
                      isDense: true,
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    style: const TextStyle(fontSize: 13),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isTesting ? null : _testAndSaveServer,
                          icon: _isTesting
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.check, size: 18),
                          label: Text(_isTesting ? 'Testing...' : 'Save & Test'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: AppColors.primary,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 10),
                          ),
                        ),
                      ),
                    ],
                  ),
                  if (_testStatus != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      _testStatus!,
                      style: TextStyle(
                        fontSize: 12,
                        color: _isOnline ? AppColors.success : AppColors.danger,
                      ),
                    ),
                  ],
                ],
              ),
            ),

            const _SectionTitle(title: 'Processing Engine'),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.offline_bolt,
                  size: 20, color: AppColors.success),
              title: Text('Dual-Engine Architecture',
                  style: TextStyle(fontSize: 14)),
              subtitle: Text('Primary: Cloud/ngrok OpenCV\nFallback: On-device native Dart',
                  style: TextStyle(
                      fontSize: 12, color: AppColors.textMuted)),
            ),
            const Divider(height: 1),
            const ListTile(
              contentPadding: EdgeInsets.zero,
              leading: Icon(Icons.camera_alt_outlined,
                  size: 20, color: AppColors.textSecondary),
              title: Text('Camera Driver',
                  style: TextStyle(fontSize: 14)),
              subtitle: Text('CameraX Viewfinder + Native Shutter Fallback',
                  style: TextStyle(
                      fontSize: 12, color: AppColors.textMuted)),
            ),
            const Divider(height: 1),

            const _SectionTitle(title: 'Exams & Data'),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.assignment_outlined,
                  size: 20, color: AppColors.textSecondary),
              title: const Text('Manage saved exams',
                  style: TextStyle(fontSize: 14)),
              subtitle: Text('${widget.state.exams.length} exams configured',
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textMuted)),
              trailing: const Icon(Icons.chevron_right,
                  color: AppColors.textMuted),
              onTap: _manageExams,
            ),
            const Divider(height: 1),
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const Icon(Icons.delete_sweep_outlined,
                  size: 20, color: AppColors.danger),
              title: const Text('Clear all scans',
                  style: TextStyle(fontSize: 14, color: AppColors.danger)),
              subtitle: Text(
                  '${widget.state.recentScans.length} scans in database',
                  style: const TextStyle(
                      fontSize: 12, color: AppColors.textMuted)),
              trailing: const Icon(Icons.chevron_right,
                  color: AppColors.textMuted),
              onTap: _clearAllScans,
            ),
            const Divider(height: 1),

            const _SectionTitle(title: 'About'),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('App Version',
                      style: TextStyle(fontSize: 14)),
                  Text('1.0.0 (Udayraj OpenCV Edition)',
                      style: TextStyle(
                          fontSize: 12, color: AppColors.textMuted)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;

  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 8),
      child: Text(
        title.toUpperCase(),
        style: const TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.bold,
          color: AppColors.textMuted,
          letterSpacing: 0.5,
        ),
      ),
    );
  }
}
