import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:image_picker/image_picker.dart';
import 'database_helper.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';

/// Connects directly to the Python OpenCV backend via ngrok live HTTPS URL.
class ApiService {
  static String baseUrl = _defaultUrl();
  static const String _baseUrlKey = 'api_base_url';

  static String _defaultUrl() {
    // Default backend server URL.
    // Use http://10.0.2.2:8000 for Android Emulator, http://localhost:8000 for desktop/web,
    // or enter your public ngrok / cloud server URL in the App Settings.
    return 'http://10.0.2.2:8000';
  }

  static String _cleanUrl(String raw) {
    var u = raw.trim();
    if (u.isEmpty) return _defaultUrl();
    if (!u.startsWith('http://') && !u.startsWith('https://')) {
      u = 'https://$u';
    }
    while (u.endsWith('/')) {
      u = u.substring(0, u.length - 1);
    }
    return u;
  }

  static Future<void> loadBaseUrl() async {
    final saved = await DatabaseHelper.getSetting(_baseUrlKey);
    if (saved != null && saved.isNotEmpty) {
      baseUrl = _cleanUrl(saved);
    } else {
      baseUrl = _defaultUrl();
    }
  }

  static Future<void> saveBaseUrl(String url) async {
    baseUrl = _cleanUrl(url);
    await DatabaseHelper.setSetting(_baseUrlKey, baseUrl);
  }

  static Future<bool> checkHealth() async {
    try {
      final response = await http
          .get(
            Uri.parse('$baseUrl/health'),
            headers: {'ngrok-skip-browser-warning': '1'},
          )
          .timeout(const Duration(seconds: 8));
      return response.statusCode == 200;
    } catch (e) {
      debugPrint('ApiService.checkHealth error: $e');
      return false;
    }
  }

  /// Grade a sheet using the Python OpenCV backend over live HTTPS tunnel.
  static Future<ScannedSheet?> gradeSheet({
    required XFile imageFile,
    required Exam exam,
    required String sessionId,
  }) async {
    try {
      final uri = Uri.parse('$baseUrl/grade');
      final request = http.MultipartRequest('POST', uri);

      // Add ngrok header to bypass warning page
      request.headers['ngrok-skip-browser-warning'] = '1';

      // Image bytes
      final Uint8List bytes = await imageFile.readAsBytes();
      final filename = imageFile.name.isNotEmpty ? imageFile.name : 'sheet.jpg';
      request.files.add(http.MultipartFile.fromBytes(
        'image', bytes, filename: filename,
      ));

      // Build answer key JSON: {"1":"A","2":"B",...}
      final Map<String, String> keyMap = {};
      if (exam.answerKey.isNotEmpty) {
        exam.answerKey.forEach((q, ans) => keyMap[q.toString()] = ans);
      } else {
        keyMap['all'] = 'A';
      }
      request.fields['answer_key']     = jsonEncode(keyMap);
      request.fields['num_questions']  = exam.numQuestions.toString();
      request.fields['num_choices']    = exam.choicesPerQuestion.toString();
      request.fields['session_id']     = sessionId;

      final streamed = await request.send().timeout(const Duration(seconds: 45));
      final response = await http.Response.fromStream(streamed);

      if (response.statusCode != 200) {
        debugPrint('OMR backend error ${response.statusCode}: ${response.body}');
        return null;
      }

      final body    = jsonDecode(response.body) as Map<String, dynamic>;
      final summary = body['summary'] as Map<String, dynamic>;
      final answers = body['answers']  as List<dynamic>;
      final marking = exam.markingScheme;

      // Build DetectedAnswer map
      final Map<int, DetectedAnswer> detectedAnswers = {};
      final List<ScanFlag> flags = [];
      double totalScore = 0.0;
      int correctCount = 0, wrongCount = 0, blankCount = 0;

      for (final a in answers) {
        final int qNo           = a['qno'] as int;
        final String? detected  = a['detected'] as String?;
        final bool isCorrect    = a['is_correct'] as bool? ?? false;
        final double confidence = (a['confidence'] as num?)?.toDouble() ?? 1.0;
        final bool isMulti      = a['is_multi'] as bool? ?? false;

        if (isMulti) {
          flags.add(ScanFlag(questionNo: qNo, reason: FlagReason.doubleMark));
        } else if (detected != null && confidence < 0.5) {
          flags.add(ScanFlag(questionNo: qNo, reason: FlagReason.lightMark));
        }

        if (detected == null) {
          blankCount++;
          totalScore += marking.blankMark;
        } else if (isCorrect) {
          correctCount++;
          totalScore += marking.correctMark;
        } else {
          wrongCount++;
          totalScore += marking.negativeMarking ? marking.wrongMark : 0.0;
        }

        detectedAnswers[qNo] = DetectedAnswer(
          questionNo:   qNo,
          markedChoice: detected,
          confidence:   double.parse(confidence.toStringAsFixed(2)),
          isCorrect:    isCorrect,
        );
      }

      final String? annotatedB64 = body['annotated_image_base64'] as String?;

      return ScannedSheet(
        id:                   'scan_${DateTime.now().millisecondsSinceEpoch}',
        sessionId:            sessionId,
        examId:               exam.id,
        rollNumber:           null,
        imageUri:             null,
        annotatedImageBase64: annotatedB64,
        detectedAnswers:      detectedAnswers,
        score:                double.parse(totalScore.toStringAsFixed(2)),
        totalQuestions:       summary['total'] as int,
        correctCount:         correctCount,
        wrongCount:           wrongCount,
        blankCount:           blankCount,
        flags:                flags,
        reviewed:             flags.isEmpty,
      );
    } catch (e, stack) {
      debugPrint('ApiService.gradeSheet error: $e\n$stack');
      return null;
    }
  }
}
