import 'package:flutter/material.dart';
import '../models/exam.dart';
import '../models/scan_result.dart';
import 'database_helper.dart';

class AppState extends ChangeNotifier {
  List<Exam> _exams = [];
  Exam? _selectedExam;
  List<ScannedSheet> _recentScans = [];
  bool _isOnboarded = false;
  bool _initialized = false;

  static const String _onboardedKey = 'is_onboarded';
  static const String _selectedExamIdKey = 'selected_exam_id';

  AppState();

  List<Exam> get exams => _exams;
  Exam? get selectedExam => _selectedExam;
  List<ScannedSheet> get recentScans => _recentScans;
  bool get isOnboarded => _isOnboarded;
  bool get initialized => _initialized;

  Future<void> init() async {
    final onboardedVal = await DatabaseHelper.getSetting(_onboardedKey);
    _isOnboarded = onboardedVal == 'true';

    // Load exams from SQLite
    try {
      _exams = await DatabaseHelper.getAllExams();
    } catch (e) {
      debugPrint('Error loading exams from SQLite: $e');
      _exams = [];
    }

    // First time: seed with sample data
    if (_exams.isEmpty) {
      await _initMockData();
    }

    // Load scan results from SQLite
    try {
      _recentScans = await DatabaseHelper.getAllScans();
    } catch (e) {
      debugPrint('Error loading scans from SQLite: $e');
      _recentScans = [];
    }

    // Restore selected exam
    final selectedId = await DatabaseHelper.getSetting(_selectedExamIdKey);
    if (selectedId != null) {
      _selectedExam = _exams.cast<Exam?>().firstWhere(
        (e) => e?.id == selectedId,
        orElse: () => null,
      );
    }
    _selectedExam ??= _exams.isNotEmpty ? _exams.first : null;

    _initialized = true;
    notifyListeners();
  }

  Future<void> completeOnboarding() async {
    _isOnboarded = true;
    await DatabaseHelper.setSetting(_onboardedKey, 'true');
    notifyListeners();
  }

  Future<void> selectExam(Exam? exam) async {
    _selectedExam = exam;
    if (exam != null) {
      await DatabaseHelper.setSetting(_selectedExamIdKey, exam.id);
    }
    notifyListeners();
  }

  Future<void> addExam(Exam exam) async {
    _exams.add(exam);
    _selectedExam = exam;
    await DatabaseHelper.insertExam(exam);
    notifyListeners();
  }

  Future<void> deleteExam(String examId) async {
    _exams.removeWhere((e) => e.id == examId);
    if (_selectedExam?.id == examId) {
      _selectedExam = _exams.isNotEmpty ? _exams.first : null;
    }
    _recentScans.removeWhere((s) => s.examId == examId);
    await DatabaseHelper.deleteExam(examId);
    notifyListeners();
  }

  Future<void> updateAnswerKey(String examId, Map<int, String> key) async {
    final index = _exams.indexWhere((e) => e.id == examId);
    if (index != -1) {
      _exams[index] = _exams[index].copyWith(answerKey: key);
      if (_selectedExam?.id == examId) {
        _selectedExam = _exams[index];
      }
      await DatabaseHelper.updateExam(_exams[index]);
      notifyListeners();
    }
  }

  Future<void> addScanResult(ScannedSheet sheet) async {
    _recentScans.insert(0, sheet);
    await DatabaseHelper.insertScan(sheet);
    notifyListeners();
  }

  Future<void> clearAllScans() async {
    _recentScans.clear();
    await DatabaseHelper.deleteAllScans();
    notifyListeners();
  }

  void updateScannedAnswer(String sheetId, int questionNo, String newChoice) {
    final index = _recentScans.indexWhere((s) => s.id == sheetId);
    if (index != -1) {
      final sheet = _recentScans[index];
      final answers = Map<int, DetectedAnswer>.from(sheet.detectedAnswers);
      final exam = _exams.cast<Exam?>().firstWhere(
        (e) => e?.id == sheet.examId,
        orElse: () => _selectedExam,
      );

      final correctChoice = exam?.answerKey[questionNo];
      final isNowCorrect = correctChoice == newChoice;

      answers[questionNo] = DetectedAnswer(
        questionNo: questionNo,
        markedChoice: newChoice,
        confidence: 1.0,
        isCorrect: isNowCorrect,
      );

      // Recalculate score & counts using marking scheme
      int correct = 0;
      int wrong = 0;
      int blank = 0;
      double score = 0;

      final markingScheme = exam?.markingScheme ?? const MarkingScheme();

      answers.forEach((qNo, ans) {
        if (ans.markedChoice == null || ans.markedChoice!.isEmpty) {
          blank++;
          score += markingScheme.blankMark;
        } else if (ans.isCorrect) {
          correct++;
          score += markingScheme.correctMark;
        } else {
          wrong++;
          score += markingScheme.negativeMarking ? markingScheme.wrongMark : 0;
        }
      });

      final updatedFlags = sheet.flags.where((f) => f.questionNo != questionNo).toList();

      final updatedSheet = sheet.copyWith(
        detectedAnswers: answers,
        score: score,
        correctCount: correct,
        wrongCount: wrong,
        blankCount: blank,
        flags: updatedFlags,
        reviewed: updatedFlags.isEmpty,
      );

      _recentScans[index] = updatedSheet;
      DatabaseHelper.updateScan(updatedSheet);
      notifyListeners();
    }
  }

  ScannedSheet generateSimulatedScan(Exam exam, {String? rollNo, bool withFlags = false}) {
    final totalQ = exam.numQuestions;
    final Map<int, DetectedAnswer> answers = {};
    int correct = 0;
    int wrong = 0;
    int blank = 0;
    final List<ScanFlag> flags = [];

    final choices = ['A', 'B', 'C', 'D', 'E'].sublist(0, exam.choicesPerQuestion);

    for (int i = 1; i <= totalQ; i++) {
      final keyChoice = exam.answerKey[i] ?? choices[i % choices.length];

      if (withFlags && (i == 17 || i == 29)) {
        if (i == 17) {
          answers[i] = DetectedAnswer(questionNo: 17, markedChoice: 'D', confidence: 0.6, isCorrect: false);
          wrong++;
          flags.add(ScanFlag(questionNo: 17, reason: FlagReason.lightMark));
        } else {
          answers[i] = DetectedAnswer(questionNo: 29, markedChoice: null, confidence: 0.9, isCorrect: false);
          blank++;
          flags.add(ScanFlag(questionNo: 29, reason: FlagReason.doubleMark));
        }
      } else {
        final isCorrect = (i % 7 != 0);
        String marked = keyChoice;
        if (!isCorrect) {
          marked = choices.firstWhere((c) => c != keyChoice);
          wrong++;
        } else {
          correct++;
        }
        answers[i] = DetectedAnswer(
          questionNo: i,
          markedChoice: marked,
          confidence: 0.98,
          isCorrect: isCorrect,
        );
      }
    }

    final newSheet = ScannedSheet(
      id: 'scan_${DateTime.now().millisecondsSinceEpoch}',
      sessionId: 'session_1',
      examId: exam.id,
      rollNumber: rollNo ?? '22-CS-${100 + _recentScans.length}',
      detectedAnswers: answers,
      score: correct * exam.markingScheme.correctMark + wrong * (exam.markingScheme.negativeMarking ? exam.markingScheme.wrongMark : 0),
      totalQuestions: totalQ,
      correctCount: correct,
      wrongCount: wrong,
      blankCount: blank,
      flags: flags,
      reviewed: flags.isEmpty,
    );

    return newSheet;
  }

  Future<void> _initMockData() async {
    final Map<int, String> midtermKey = {};
    final choices = ['A', 'B', 'C', 'D'];
    for (int i = 1; i <= 40; i++) {
      midtermKey[i] = choices[(i * 3 + 1) % 4];
    }

    final midtermExam = Exam(
      id: 'exam_midterm_cs301',
      title: 'Midterm — CS-301',
      numQuestions: 40,
      choicesPerQuestion: 4,
      hasRollNumber: true,
      rollNumberDigits: 5,
      answerKey: midtermKey,
    );

    final finalExamNoKey = Exam(
      id: 'exam_final_math101',
      title: 'Final Exam — MATH-101',
      numQuestions: 50,
      choicesPerQuestion: 4,
      hasRollNumber: true,
      answerKey: {},
    );

    _exams = [midtermExam, finalExamNoKey];
    _selectedExam = midtermExam;

    // Save to SQLite
    await DatabaseHelper.insertExam(midtermExam);
    await DatabaseHelper.insertExam(finalExamNoKey);

    // Seed sample scans and save to SQLite
    final scan1 = generateSimulatedScan(midtermExam, rollNo: '22-CS-114', withFlags: false);
    final scan2 = generateSimulatedScan(midtermExam, rollNo: '22-CS-098', withFlags: true);
    final scan3 = generateSimulatedScan(midtermExam, rollNo: '22-CS-071', withFlags: false);
    final scan4 = generateSimulatedScan(midtermExam, rollNo: '22-CS-102', withFlags: false);

    _recentScans = [scan1, scan2, scan3, scan4];

    for (final scan in _recentScans) {
      await DatabaseHelper.insertScan(scan);
    }
  }
}
