import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart' as sql;
import '../models/exam.dart';
import '../models/scan_result.dart';

/// Offline SQLite Database Helper with automatic fault-tolerant fallback.
/// On Android/iOS/Desktop, uses real SQLite via `sqflite`.
/// If SQLite ever fails to open or on Web, falls back to `shared_preferences`.
class DatabaseHelper {
  static sql.Database? _db;
  static bool _sqliteFailed = false;
  static SharedPreferences? _prefs;

  static const String _dbName = 'omr_scanner_v2.db';
  static const int _dbVersion = 1;

  // Fallback keys
  static const String _examsKey = 'omr_exams_v1';
  static const String _scansKey = 'omr_scans_v1';

  static Future<SharedPreferences> get _preferences async {
    _prefs ??= await SharedPreferences.getInstance();
    return _prefs!;
  }

  static Future<sql.Database?> get _database async {
    if (kIsWeb || _sqliteFailed) return null;
    if (_db != null) return _db!;
    try {
      _db = await _initDatabase();
      return _db;
    } catch (e) {
      debugPrint('SQLite initialization failed, falling back to SharedPreferences: $e');
      _sqliteFailed = true;
      return null;
    }
  }

  static Future<sql.Database> _initDatabase() async {
    final dbFolder = await sql.getDatabasesPath();
    final dbPath = p.join(dbFolder, _dbName);

    return await sql.openDatabase(
      dbPath,
      version: _dbVersion,
      onCreate: (db, version) async {
        // Table: exams
        await db.execute('''
          CREATE TABLE IF NOT EXISTS exams (
            id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            num_questions INTEGER NOT NULL,
            choices_per_question INTEGER NOT NULL,
            has_roll_number INTEGER NOT NULL,
            roll_number_digits INTEGER NOT NULL,
            marking_scheme TEXT NOT NULL,
            answer_key TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');

        // Table: scanned_sheets
        await db.execute('''
          CREATE TABLE IF NOT EXISTS scanned_sheets (
            id TEXT PRIMARY KEY,
            session_id TEXT NOT NULL,
            exam_id TEXT NOT NULL,
            roll_number TEXT,
            image_uri TEXT,
            detected_answers TEXT NOT NULL,
            score REAL NOT NULL,
            total_questions INTEGER NOT NULL,
            correct_count INTEGER NOT NULL,
            wrong_count INTEGER NOT NULL,
            blank_count INTEGER NOT NULL,
            flags TEXT NOT NULL,
            reviewed INTEGER NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');

        // Table: app settings
        await db.execute('''
          CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
          )
        ''');
      },
    );
  }

  // ==================== EXAMS ====================

  static Future<void> insertExam(Exam exam) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      final exams = await getAllExams();
      final idx = exams.indexWhere((e) => e.id == exam.id);
      if (idx != -1) {
        exams[idx] = exam;
      } else {
        exams.add(exam);
      }
      await prefs.setString(_examsKey, jsonEncode(exams.map((e) => e.toJson()).toList()));
      return;
    }

    try {
      await db.insert(
        'exams',
        {
          'id': exam.id,
          'title': exam.title,
          'num_questions': exam.numQuestions,
          'choices_per_question': exam.choicesPerQuestion,
          'has_roll_number': exam.hasRollNumber ? 1 : 0,
          'roll_number_digits': exam.rollNumberDigits,
          'marking_scheme': jsonEncode(exam.markingScheme.toJson()),
          'answer_key': jsonEncode(exam.answerKey.map((k, v) => MapEntry(k.toString(), v))),
          'created_at': exam.createdAt.toIso8601String(),
        },
        conflictAlgorithm: sql.ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('insertExam sqlite error: $e');
    }
  }

  static Future<List<Exam>> getAllExams() async {
    final db = await _database;
    if (db == null) {
      try {
        final prefs = await _preferences;
        final raw = prefs.getString(_examsKey);
        if (raw == null || raw.isEmpty) return [];
        final list = jsonDecode(raw) as List<dynamic>;
        return list.map((j) => Exam.fromJson(j as Map<String, dynamic>)).toList();
      } catch (e) {
        debugPrint('getAllExams fallback error: $e');
        return [];
      }
    }

    try {
      final maps = await db.query('exams', orderBy: 'created_at DESC');
      return maps.map((row) {
        final rawScheme = jsonDecode(row['marking_scheme'] as String);
        final rawKey = jsonDecode(row['answer_key'] as String) as Map<String, dynamic>;
        final answerKey = rawKey.map((k, v) => MapEntry(int.parse(k), v as String));

        return Exam(
          id: row['id'] as String,
          title: row['title'] as String,
          numQuestions: row['num_questions'] as int,
          choicesPerQuestion: row['choices_per_question'] as int,
          hasRollNumber: (row['has_roll_number'] as int) == 1,
          rollNumberDigits: row['roll_number_digits'] as int,
          markingScheme: MarkingScheme.fromJson(rawScheme),
          answerKey: answerKey,
          createdAt: DateTime.parse(row['created_at'] as String),
        );
      }).toList();
    } catch (e) {
      debugPrint('getAllExams sqlite error: $e');
      return [];
    }
  }

  static Future<void> updateExam(Exam exam) async {
    await insertExam(exam);
  }

  static Future<void> deleteExam(String examId) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      final exams = await getAllExams();
      exams.removeWhere((e) => e.id == examId);
      await prefs.setString(_examsKey, jsonEncode(exams.map((e) => e.toJson()).toList()));
      final scans = await getAllScans();
      final remaining = scans.where((s) => s.examId != examId).toList();
      await prefs.setString(_scansKey, jsonEncode(remaining.map((s) => s.toJson()).toList()));
      return;
    }

    try {
      await db.delete('exams', where: 'id = ?', whereArgs: [examId]);
      await db.delete('scanned_sheets', where: 'exam_id = ?', whereArgs: [examId]);
    } catch (e) {
      debugPrint('deleteExam sqlite error: $e');
    }
  }

  // ==================== SCANNED SHEETS ====================

  static Future<void> insertScan(ScannedSheet sheet) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      final scans = await getAllScans();
      final idx = scans.indexWhere((s) => s.id == sheet.id);
      if (idx != -1) {
        scans[idx] = sheet;
      } else {
        scans.insert(0, sheet);
      }
      await prefs.setString(_scansKey, jsonEncode(scans.map((s) => s.toJson()).toList()));
      return;
    }

    try {
      await db.insert(
        'scanned_sheets',
        {
          'id': sheet.id,
          'session_id': sheet.sessionId,
          'exam_id': sheet.examId,
          'roll_number': sheet.rollNumber,
          'image_uri': sheet.imageUri,
          'detected_answers': jsonEncode(
            sheet.detectedAnswers.map((k, v) => MapEntry(k.toString(), v.toJson())),
          ),
          'score': sheet.score,
          'total_questions': sheet.totalQuestions,
          'correct_count': sheet.correctCount,
          'wrong_count': sheet.wrongCount,
          'blank_count': sheet.blankCount,
          'flags': jsonEncode(sheet.flags.map((f) => f.toJson()).toList()),
          'reviewed': sheet.reviewed ? 1 : 0,
          'created_at': sheet.createdAt.toIso8601String(),
        },
        conflictAlgorithm: sql.ConflictAlgorithm.replace,
      );
    } catch (e) {
      debugPrint('insertScan sqlite error: $e');
    }
  }

  static Future<List<ScannedSheet>> getAllScans() async {
    final db = await _database;
    if (db == null) {
      try {
        final prefs = await _preferences;
        final raw = prefs.getString(_scansKey);
        if (raw == null || raw.isEmpty) return [];
        final list = jsonDecode(raw) as List<dynamic>;
        return list.map((j) => ScannedSheet.fromJson(j as Map<String, dynamic>)).toList();
      } catch (e) {
        debugPrint('getAllScans fallback error: $e');
        return [];
      }
    }

    try {
      final maps = await db.query('scanned_sheets', orderBy: 'created_at DESC');
      return maps.map((row) {
        final rawAnswers = jsonDecode(row['detected_answers'] as String) as Map<String, dynamic>;
        final answers = rawAnswers.map(
          (k, v) => MapEntry(int.parse(k), DetectedAnswer.fromJson(v as Map<String, dynamic>)),
        );
        final rawFlags = jsonDecode(row['flags'] as String) as List<dynamic>;
        final flags = rawFlags.map((f) => ScanFlag.fromJson(f as Map<String, dynamic>)).toList();

        return ScannedSheet(
          id: row['id'] as String,
          sessionId: row['session_id'] as String,
          examId: row['exam_id'] as String,
          rollNumber: row['roll_number'] as String?,
          imageUri: row['image_uri'] as String?,
          detectedAnswers: answers,
          score: (row['score'] as num).toDouble(),
          totalQuestions: row['total_questions'] as int,
          correctCount: row['correct_count'] as int,
          wrongCount: row['wrong_count'] as int,
          blankCount: row['blank_count'] as int,
          flags: flags,
          reviewed: (row['reviewed'] as int) == 1,
          createdAt: DateTime.parse(row['created_at'] as String),
        );
      }).toList();
    } catch (e) {
      debugPrint('getAllScans sqlite error: $e');
      return [];
    }
  }

  static Future<void> updateScan(ScannedSheet sheet) async {
    await insertScan(sheet);
  }

  static Future<void> deleteScan(String scanId) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      final scans = await getAllScans();
      scans.removeWhere((s) => s.id == scanId);
      await prefs.setString(_scansKey, jsonEncode(scans.map((s) => s.toJson()).toList()));
      return;
    }

    try {
      await db.delete('scanned_sheets', where: 'id = ?', whereArgs: [scanId]);
    } catch (e) {
      debugPrint('deleteScan sqlite error: $e');
    }
  }

  static Future<void> deleteAllScans() async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      await prefs.remove(_scansKey);
      return;
    }

    try {
      await db.delete('scanned_sheets');
    } catch (e) {
      debugPrint('deleteAllScans sqlite error: $e');
    }
  }

  // ==================== SETTINGS ====================

  static Future<void> setSetting(String key, String value) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      await prefs.setString('omr_setting_$key', value);
      return;
    }

    try {
      await db.insert(
        'settings',
        {'key': key, 'value': value},
        conflictAlgorithm: sql.ConflictAlgorithm.replace,
      );
    } catch (e) {
      final prefs = await _preferences;
      await prefs.setString('omr_setting_$key', value);
    }
  }

  static Future<String?> getSetting(String key) async {
    final db = await _database;
    if (db == null) {
      final prefs = await _preferences;
      return prefs.getString('omr_setting_$key');
    }

    try {
      final maps = await db.query(
        'settings',
        columns: ['value'],
        where: 'key = ?',
        whereArgs: [key],
        limit: 1,
      );
      if (maps.isNotEmpty) {
        return maps.first['value'] as String?;
      }
      return null;
    } catch (e) {
      final prefs = await _preferences;
      return prefs.getString('omr_setting_$key');
    }
  }
}
