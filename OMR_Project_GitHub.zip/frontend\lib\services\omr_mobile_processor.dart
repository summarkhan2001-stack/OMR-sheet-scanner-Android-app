import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;
import '../models/exam.dart';
import '../models/scan_result.dart';

/// On-Device OMR Processing Engine v3.0 — Fully Offline
///
/// Uses the EXACT same algorithm as the Python/OpenCV backend that
/// successfully detected all 100 bubbles:
///   1. Otsu adaptive thresholding (not fixed global threshold)
///   2. Horizontal projection → finds bubble row Y positions
///   3. Vertical projection → finds bubble column X positions
///   4. Circular brightness sampling with paper-relative normalisation
///   5. Per-row relative decision: darkest bubble = marked answer
///
/// Works with ANY standard OMR sheet layout (auto-detects grid).
class OmrMobileProcessor {
  static const List<String> _choices4 = ['A', 'B', 'C', 'D'];
  static const List<String> _choices5 = ['A', 'B', 'C', 'D', 'E'];

  static Future<ScannedSheet?> processSheetOnDevice({
    required Uint8List imageBytes,
    required Exam exam,
    required String sessionId,
  }) async {
    return compute(_runOmrPipeline, _OmrInput(
      imageBytes: imageBytes,
      examJson: exam.toJson(),
      sessionId: sessionId,
    ));
  }

  static ScannedSheet? _runOmrPipeline(_OmrInput input) {
    try {
      final exam = Exam.fromJson(input.examJson);
      final raw = img.decodeImage(input.imageBytes);
      if (raw == null) return null;

      // ── 1. Normalise to 1000px wide ─────────────────────────────────────
      const int targetW = 1000;
      final img.Image src = raw.width != targetW
          ? img.copyResize(raw, width: targetW, interpolation: img.Interpolation.linear)
          : raw;
      final img.Image gray = img.grayscale(src);
      final int W = gray.width;
      final int H = gray.height;

      // ── 2. Build pixel brightness array (fast access) ───────────────────
      final List<int> pix = List<int>.filled(W * H, 0);
      for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
          pix[y * W + x] = gray.getPixel(x, y).r.toInt();
        }
      }

      // ── 3. Otsu threshold → binary map (dark=true) ──────────────────────
      final int otsu = _otsuThreshold(pix);
      // Dark pixels are anything below otsu (they belong to ink/filled bubbles)
      final List<bool> dark = pix.map((v) => v < otsu).toList();

      // ── 4. Paper brightness baseline (from corners) ──────────────────────
      final double paperBright = _cornerBrightness(pix, W, H);

      // ── 5. Horizontal projection → find Y centres of bubble rows ─────────
      // Count dark pixels in each row. Bubble rows have many dark pixels
      // (from the circles themselves). Header rows have fewer.
      final List<int> rowDark = List<int>.filled(H, 0);
      for (int y = 0; y < H; y++) {
        for (int x = 0; x < W; x++) {
          if (dark[y * W + x]) rowDark[y]++;
        }
      }

      // Smooth the row projection (5-pixel box blur)
      final List<double> rowSmooth = _smooth1d(rowDark.map((v) => v.toDouble()).toList(), 5);

      // Find peaks in the row projection = bubble row centres
      // Skip top 25% (header) and bottom 5% (footer)
      final int skipTop    = (H * 0.25).toInt();
      final int skipBottom = (H * 0.95).toInt();
      final List<int> rowCenters = _findPeaks(rowSmooth, skipTop, skipBottom,
          minPeakHeight: W * 0.04,   // at least 4% of width dark per row
          minPeakDist: H ~/ 60);     // min ~60 rows apart

      if (rowCenters.isEmpty) {
        debugPrint('OMR v3: No bubble rows found');
        return null;
      }

      // ── 6. Vertical projection → find X centres of bubble columns ─────────
      // For each row center, scan the horizontal band for vertical dark runs
      final int bandH = max(4, (rowCenters.length > 1
          ? (rowCenters[1] - rowCenters[0]) ~/ 3
          : H ~/ 40));

      // Use the middle row for column detection (most reliable)
      final int midRow = rowCenters[rowCenters.length ~/ 2];
      final List<int> colDark = List<int>.filled(W, 0);
      for (int y = max(0, midRow - bandH); y < min(H, midRow + bandH); y++) {
        for (int x = 0; x < W; x++) {
          if (dark[y * W + x]) colDark[x]++;
        }
      }

      final List<double> colSmooth = _smooth1d(colDark.map((v) => v.toDouble()).toList(), 4);

      // Find column X peaks = individual bubble X centres
      final List<int> colCenters = _findPeaks(colSmooth, W ~/ 20, W - W ~/ 20,
          minPeakHeight: bandH * 0.15,
          minPeakDist: W ~/ 80);

      if (colCenters.isEmpty) {
        debugPrint('OMR v3: No bubble columns found');
        return null;
      }

      debugPrint('OMR v3: ${rowCenters.length} rows, ${colCenters.length} cols detected');

      // ── 7. Determine layout ──────────────────────────────────────────────
      final int numQ       = exam.numQuestions;
      final int numChoices = exam.choicesPerQuestion;
      final List<String> labels = numChoices == 5 ? _choices5 : _choices4;

      // Group column centers into OMR columns (each has numChoices bubbles)
      // Cluster nearby X values together
      final List<List<int>> colGroups = _clusterValues(colCenters, W ~/ 20);

      // Each cluster = one OMR column's worth of choices
      // Filter to only clusters that have roughly numChoices entries
      final List<List<int>> bubbleCols = colGroups
          .where((g) => g.length >= numChoices - 1 && g.length <= numChoices + 1)
          .toList();

      if (bubbleCols.isEmpty) {
        // Fallback: treat all column centers as choices cycling
        debugPrint('OMR v3: Cluster grouping failed, using all ${colCenters.length} col centers');
      }

      // ── 8. Estimate bubble radius ────────────────────────────────────────
      final int radius = max(3, (H / max(1, rowCenters.length) * 0.28).toInt());

      // ── 9. Grade each question ───────────────────────────────────────────
      final Map<int, DetectedAnswer> detectedAnswers = {};
      final List<ScanFlag> flags = [];
      int correctCount = 0, wrongCount = 0, blankCount = 0;
      double totalScore = 0.0;
      final marking = exam.markingScheme;

      // Determine which X centers to use for each choice in each OMR column
      List<List<int>> effectiveBubbleCols;
      int numOmrCols;
      int qPerCol;

      if (bubbleCols.length >= 2) {
        effectiveBubbleCols = bubbleCols;
        numOmrCols = bubbleCols.length;
        qPerCol    = (numQ / numOmrCols).ceil();
      } else {
        // Distribute colCenters evenly: assume numChoices per OMR col
        final int totalCols = colCenters.length;
        numOmrCols = max(1, totalCols ~/ numChoices);
        qPerCol    = (numQ / numOmrCols).ceil();
        effectiveBubbleCols = [];
        for (int c = 0; c < numOmrCols; c++) {
          final start = c * numChoices;
          final end   = min(start + numChoices, totalCols);
          if (start < totalCols) {
            effectiveBubbleCols.add(colCenters.sublist(start, end));
          }
        }
      }

      for (int qIndex = 0; qIndex < numQ; qIndex++) {
        final int qNo      = qIndex + 1;
        final int colIdx   = qIndex ~/ qPerCol;
        final int rowIdx   = qIndex  % qPerCol;

        if (colIdx >= effectiveBubbleCols.length || rowIdx >= rowCenters.length) {
          // Out of detected grid range
          blankCount++;
          detectedAnswers[qNo] = DetectedAnswer(
            questionNo: qNo, markedChoice: null,
            confidence: 1.0, isCorrect: false,
          );
          continue;
        }

        final List<int> choiceXs = effectiveBubbleCols[colIdx];
        final int cy = rowCenters[rowIdx];

        // Sample brightness of each choice bubble
        final Map<String, double> brightness = {};
        for (int ci = 0; ci < numChoices && ci < choiceXs.length; ci++) {
          final int cx = choiceXs[ci];
          brightness[labels[ci]] = _sampleCircleBrightness(pix, cx, cy, radius, W, H);
        }

        if (brightness.isEmpty) {
          blankCount++;
          detectedAnswers[qNo] = DetectedAnswer(
            questionNo: qNo, markedChoice: null,
            confidence: 1.0, isCorrect: false,
          );
          continue;
        }

        // ── Decision: same logic as Python backend ───────────────────────
        // Darkest bubble = lowest brightness
        String darkestChoice = brightness.keys.first;
        double minBright     = brightness.values.first;
        for (final entry in brightness.entries) {
          if (entry.value < minBright) {
            minBright     = entry.value;
            darkestChoice = entry.key;
          }
        }

        // Filled bubbles have brightness < 140 (at paperBright ~240)
        // Scale threshold relative to paper brightness
        final double darkThreshold = paperBright * 0.58; // ~140 when paper=240

        String? detected;
        double  confidence = 1.0;

        if (minBright < darkThreshold) {
          detected   = darkestChoice;
          confidence = ((darkThreshold - minBright) / darkThreshold).clamp(0.0, 1.0);

          // Flag lightly filled bubbles
          if (minBright > darkThreshold * 0.70) {
            flags.add(ScanFlag(questionNo: qNo, reason: FlagReason.lightMark));
          }

          // Check for double marks
          int darkCount = 0;
          for (final b in brightness.values) {
            if (b < darkThreshold) darkCount++;
          }
          if (darkCount > 1) {
            flags.add(ScanFlag(questionNo: qNo, reason: FlagReason.doubleMark));
          }
        }
        // else: blank

        final String? correctChoice = exam.answerKey[qNo];
        final bool isCorrect = detected != null && correctChoice != null && detected == correctChoice;

        if (detected == null) {
          blankCount++;
          totalScore += marking.blankMark;
        } else if (isCorrect) {
          correctCount++;
          totalScore += marking.correctMark;
        } else {
          wrongCount++;
          totalScore += marking.negativeMarking ? marking.wrongMark : 0.0;
        }

        detectedAnswers[qNo] = DetectedAnswer(
          questionNo:   qNo,
          markedChoice: detected,
          confidence:   double.parse(confidence.toStringAsFixed(2)),
          isCorrect:    isCorrect,
        );
      }

      debugPrint('OMR v3: correct=$correctCount wrong=$wrongCount blank=$blankCount');

      return ScannedSheet(
        id:              'scan_${DateTime.now().millisecondsSinceEpoch}',
        sessionId:       input.sessionId,
        examId:          exam.id,
        rollNumber:      null,
        imageUri:        null,
        detectedAnswers: detectedAnswers,
        score:           double.parse(totalScore.toStringAsFixed(2)),
        totalQuestions:  numQ,
        correctCount:    correctCount,
        wrongCount:      wrongCount,
        blankCount:      blankCount,
        flags:           flags,
        reviewed:        flags.isEmpty,
      );
    } catch (e, stack) {
      debugPrint('OMR v3 error: $e\n$stack');
      return null;
    }
  }

  // ── Helper: Otsu's threshold ─────────────────────────────────────────────
  static int _otsuThreshold(List<int> pixels) {
    final List<int> hist = List<int>.filled(256, 0);
    for (final p in pixels) {
      hist[p.clamp(0, 255)]++;
    }
    final int total = pixels.length;
    double sum = 0;
    for (int i = 0; i < 256; i++) {
      sum += i * hist[i];
    }

    double sumB = 0, wB = 0, max = 0;
    int threshold = 128;
    for (int t = 0; t < 256; t++) {
      wB += hist[t];
      if (wB == 0) continue;
      final double wF = total - wB;
      if (wF == 0) break;
      sumB += t * hist[t];
      final double mB = sumB / wB;
      final double mF = (sum - sumB) / wF;
      final double between = wB * wF * (mB - mF) * (mB - mF);
      if (between > max) {
        max = between;
        threshold = t;
      }
    }
    return threshold;
  }

  // ── Helper: corner brightness (paper white baseline) ────────────────────
  static double _cornerBrightness(List<int> pix, int W, int H) {
    const int patch = 30;
    int sum = 0, n = 0;
    for (final corner in [[0, 0], [W - patch, 0], [0, H - patch], [W - patch, H - patch]]) {
      final int x0 = corner[0].clamp(0, W - patch);
      final int y0 = corner[1].clamp(0, H - patch);
      for (int y = y0; y < y0 + patch; y += 3) {
        for (int x = x0; x < x0 + patch; x += 3) {
          sum += pix[y * W + x];
          n++;
        }
      }
    }
    return n > 0 ? (sum / n).clamp(180.0, 255.0) : 220.0;
  }

  // ── Helper: 1D box smooth ────────────────────────────────────────────────
  static List<double> _smooth1d(List<double> data, int window) {
    final int n = data.length;
    final List<double> out = List<double>.filled(n, 0);
    final int half = window ~/ 2;
    for (int i = 0; i < n; i++) {
      double s = 0; int c = 0;
      for (int j = max(0, i - half); j <= min(n - 1, i + half); j++) {
        s += data[j]; c++;
      }
      out[i] = c > 0 ? s / c : 0;
    }
    return out;
  }

  // ── Helper: find peaks in 1D signal ─────────────────────────────────────
  static List<int> _findPeaks(List<double> signal, int start, int end,
      {required double minPeakHeight, required int minPeakDist}) {
    final List<int> peaks = [];
    int lastPeak = -minPeakDist * 2;
    for (int i = start + 1; i < end - 1; i++) {
      if (signal[i] >= minPeakHeight &&
          signal[i] >= signal[i - 1] &&
          signal[i] >= signal[i + 1] &&
          i - lastPeak >= minPeakDist) {
        peaks.add(i);
        lastPeak = i;
      }
    }
    return peaks;
  }

  // ── Helper: cluster nearby integers ─────────────────────────────────────
  static List<List<int>> _clusterValues(List<int> values, int maxGap) {
    if (values.isEmpty) return [];
    final List<List<int>> clusters = [];
    List<int> cur = [values.first];
    for (int i = 1; i < values.length; i++) {
      if (values[i] - values[i - 1] <= maxGap) {
        cur.add(values[i]);
      } else {
        clusters.add(cur);
        cur = [values[i]];
      }
    }
    clusters.add(cur);
    return clusters;
  }

  // ── Helper: mean brightness in circular region ───────────────────────────
  static double _sampleCircleBrightness(
      List<int> pix, int cx, int cy, int radius, int W, int H) {
    double sum = 0; int n = 0;
    final int r2 = radius * radius;
    for (int dy = -radius; dy <= radius; dy++) {
      for (int dx = -radius; dx <= radius; dx++) {
        if (dx * dx + dy * dy <= r2) {
          final int px = (cx + dx).clamp(0, W - 1);
          final int py = (cy + dy).clamp(0, H - 1);
          sum += pix[py * W + px];
          n++;
        }
      }
    }
    return n > 0 ? sum / n : 255.0;
  }
}

class _OmrInput {
  final Uint8List imageBytes;
  final Map<String, dynamic> examJson;
  final String sessionId;
  _OmrInput({required this.imageBytes, required this.examJson, required this.sessionId});
}
