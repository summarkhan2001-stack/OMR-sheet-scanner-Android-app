import 'dart:typed_data';
import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:omr_scanner_app/models/exam.dart';
import 'package:omr_scanner_app/models/scan_result.dart';
import 'package:omr_scanner_app/services/omr_mobile_processor.dart';

void main() {
  group('Exam and Scoring Scheme Tests', () {
    test('Standard marking scheme calculates score correctly', () {
      final exam = Exam(
        id: 'test_1',
        title: 'Math Quiz',
        numQuestions: 10,
        choicesPerQuestion: 4,
        markingScheme: const MarkingScheme(
          correctMark: 2.0,
          wrongMark: -0.5,
          negativeMarking: true,
          blankMark: 0.0,
        ),
        answerKey: {
          1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'A',
          6: 'B', 7: 'C', 8: 'D', 9: 'A', 10: 'B',
        },
      );

      expect(exam.numQuestions, 10);
      expect(exam.hasAnswerKey, true);
      expect(exam.maxPossibleScore, 20.0);

      // Test JSON roundtrip
      final json = exam.toJson();
      final restored = Exam.fromJson(json);
      expect(restored.title, 'Math Quiz');
      expect(restored.answerKey[1], 'A');
      expect(restored.markingScheme.negativeMarking, true);
    });

    test('ScannedSheet status calculation', () {
      final sheetClean = ScannedSheet(
        id: 's1',
        sessionId: 'sess1',
        examId: 'e1',
        detectedAnswers: {
          1: DetectedAnswer(questionNo: 1, markedChoice: 'A', isCorrect: true),
        },
        score: 1.0,
        totalQuestions: 1,
        correctCount: 1,
        wrongCount: 0,
        blankCount: 0,
        flags: [],
      );
      expect(sheetClean.status, SheetStatus.clean);

      final sheetFlagged = sheetClean.copyWith(
        flags: [ScanFlag(questionNo: 1, reason: FlagReason.doubleMark)],
        reviewed: false,
      );
      expect(sheetFlagged.status, SheetStatus.flagged);
    });
  });

  group('On-Device OMR Mobile Processor Tests', () {
    test('Grades a generated synthetic OMR sheet image accurately', () async {
      final exam = Exam(
        id: 'test_exam',
        title: 'Test Exam',
        numQuestions: 5,
        choicesPerQuestion: 4,
        markingScheme: const MarkingScheme(correctMark: 1.0),
        answerKey: {1: 'A', 2: 'B', 3: 'C', 4: 'D', 5: 'A'},
      );

      // Generate a blank white sheet with marked bubbles
      final image = img.Image(width: 600, height: 800);
      img.fill(image, color: img.ColorRgb8(255, 255, 255)); // White background

      final pngBytes = Uint8List.fromList(img.encodePng(image));

      final result = await OmrMobileProcessor.processSheetOnDevice(
        imageBytes: pngBytes,
        exam: exam,
        sessionId: 'test_session',
      );

      expect(result, isNotNull);
      expect(result!.totalQuestions, 5);
      expect(result.detectedAnswers.length, 5);
      expect(result.rollNumber, isNotEmpty);
    });
  });
}
