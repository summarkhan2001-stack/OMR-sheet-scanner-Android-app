import 'package:flutter_test/flutter_test.dart';
import 'package:omr_scanner_app/main.dart';

void main() {
  testWidgets('App renders onboarding screen test', (WidgetTester tester) async {
    await tester.pumpWidget(const OmrApp());
    expect(find.text('Snap a sheet, get a score'), findsOneWidget);
  });
}
